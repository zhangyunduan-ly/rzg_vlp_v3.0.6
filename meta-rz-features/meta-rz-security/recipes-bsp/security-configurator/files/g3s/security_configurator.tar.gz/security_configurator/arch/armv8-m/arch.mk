
# compile options
CPU			:= -march=armv8-m.base -mtune=cortex-m33 -mthumb
CFLAGS		:= -mgeneral-regs-only -mfloat-abi=soft -Wstrict-aliasing -ffunction-sections -fdata-sections \
			   -ffreestanding -fno-common -std=gnu99 -O3  -fno-plt -fno-pic -fno-stack-protector -Werror -DTHUMB

ifeq ($(DEBUG), 1)
CFLAGS		+= -Og -g
endif

# assembler options
ASFLAGS		:= -x assembler-with-cpp -DASSEMBLY $(CFLAGS)

# linker options
LDFLAGS		:= -nostdlib -gc-sections
LIBRARY		:= lib/libr_secure_ip_3_1.a.1.0.0

CROSS_COMPILE ?= arm-none-eabi-
