
# If "y", write function of HUK for RSIP is enabled.
# Note: When this software is launched for the first time on the target device,
#       HUK write process is automatically executed.
CFG_OTP_RSIPHUK_PROV = y

# If y, the write value is set to "Enable Secure Boot".
CFG_OTP_SECBT_EN = y

# This is the mode in which the debugger is connected.
# If none, the write data is set to "Normal Connection".
# If auth, the write data is set to "Authentication Connection".
# If reject, the write data is set to "Connection Rejection".
CFG_OTP_JAUTH_MODE = none
# This is the type of Authentication Connection.
# If idauth, the write data is set to "ID Authentication".
# If secip, the write data is set to "Security IP Authentication".
CFG_OTP_JAUTH_TYPE = secip

# The OTP user area has an area with a one-time read function.
# That area is 128 bytes in size and is divided into 64 bytes.
# OTR activation can be set for each of these divided areas.
# if y, the write data is set to "Enables One Time Read".
CFG_OTP_OTR_EN_0 = n
CFG_OTP_OTR_EN_1 = n

# This is specified to disable each boot device when secure boot is enabled.
# if y, the write data is set to "Disable Secure Boot".
CFG_OTP_SB_DIS_SD = n
CFG_OTP_SB_DIS_EMMC18 = n
CFG_OTP_SB_DIS_EMMC33 = n
CFG_OTP_SB_DIS_SPI18 = n
CFG_OTP_SB_DIS_SPI33 = n
CFG_OTP_SB_DIS_SCIF = n

# This is specified to disable transition to failsafe mode when secure boot fails.
# if y, the write data is set to "Disable failsafe".
CFG_OTP_FAILSAFE_DIS = n

# This is specified to enable the anti-rollback feature on MaskROM.
# if y, the write data is set to "Enable Anti-Rollback".
CFG_OTP_ANTI_RB_EN = n

# This is write protection for the authentication ID area.
# if y, the write data is set to "Enable protection".
CFG_OTP_WP_AUTH_ID = n
CFG_OTP_RP_AUTH_ID = n

# This is write protection for the function settings area.
# if y, the write data is set to "Enable protection".
CFG_OTP_WP_FUNC = n

# This is write protection for the blocking settings area.
# if y, the write data is set to "Enable protection".
CFG_OTP_WP_RAC_DIS = n
CFG_OTP_WP_TAC_DIS = n

# This is specified to enable access blocking settings.
# if y, the write data is set to "Access Block".
CFG_OTP_RAC_DIS = n
CFG_OTP_TAC_DIS = n

# This is wrapped data of the key used to wrap ENC_USER_KEY and ENC_USER_KUK.
CFG_WRAPPED_UFPK_FILE  = ./install/wrapped-ufpk.bin
CFG_UFPK_ENC_IV0_FILE  = ./install/ufpk_init_vec.bin

# This is the hash of the root of trust public key for secure boot.
CFG_ROT_PK_HASH_FILE   =
# This is the wrapped data of the password for the JTAG authentication connection.
CFG_AUTH_DATA_FILE     =
# This is the wrapped data of the key used for secure boot image decryption.
CFG_ENC_USER_KEY0_FILE =
CFG_ENC_USER_KEY1_FILE =
CFG_ENC_USER_KEY2_FILE =
CFG_ENC_USER_KEY3_FILE =

# This is the wrapped data of the key update key used to install the key for the base cryptographic function.
CFG_ENC_USER_KUK_FILE  =
