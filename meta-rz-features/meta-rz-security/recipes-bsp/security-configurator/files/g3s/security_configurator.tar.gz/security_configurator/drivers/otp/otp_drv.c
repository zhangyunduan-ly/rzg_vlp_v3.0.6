/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpd_rv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "drivers/otp_drv.h"
#include "otp_map.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_API_READ    (ROM_API_OTP_BASE + 0x0000)
#define OTP_API_WRITE   (ROM_API_OTP_BASE + 0x0020)

#define OTP_SUCCESS     (0x5A5A5A5Au)
#define OTP_ERR_OPEN    (0x42424242u)
#define OTP_ERR_READ    (0x84848484u)
#define OTP_ERR_WRITE   (0x5A3C5A3Cu)
#define OTP_ERR_PARAM   (0xA5C35A3Cu)

/**********************************************************************************************************************
 Local Typedef definitions
 *********************************************************************************************************************/
typedef uint32_t (*fp_otp_func_t)(const uint32_t offset, const uint32_t size, uint8_t *const data);

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: get_otp_offset
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t get_otp_offset(const e_otp_symbol_t symbol, uint32_t size)
{
    int32_t offset = -1;

    uint32_t map_ofs = 0;
    uint32_t map_len = 0;

    switch (symbol)
    {
        case OTP_SYM_AES128:
            map_ofs = OTPAESKEY;
            map_len = OTPAESKEY128_SIZE;
            break;
        case OTP_SYM_AES256:
            map_ofs = OTPAESKEY;
            map_len = OTPAESKEY256_SIZE;
            break;
        case OTP_SYM_AUTHID:
            map_ofs = OTPAUTHID;
            map_len = OTPAUTHID_SIZE;
            break;
        case OTP_SYM_SECBTEN:
            map_ofs = OTPSECBTEN;
            map_len = OTPSECBTEN_SIZE;
            break;
        case OTP_SYM_JAM:
            map_ofs = OTPJAM;
            map_len = OTPJAM_SIZE;
            break;
        case OTP_SYM_OTREN:
            map_ofs = OTPOTREN;
            map_len = OTPOTREN_SIZE;
            break;
        case OTP_SYM_SECBTMODE:
            map_ofs = OTPSECBTMODE;
            map_len = OTPSECBTMODE_SIZE;
            break;
        case OTP_SYM_ARB:
            map_ofs = OTPARB;
            map_len = OTPARB_SIZE;
            break;
        case OTP_SYM_ACC:
            map_ofs = OTPACC;
            map_len = OTPACC_SIZE;
        break;
        case OTP_SYM_LIFECYC_P:
            map_ofs = OTPLIFECYC_P;
            map_len = OTPLIFECYC_P_SIZE;
            break;
        case OTP_SYM_ACDIS:
            map_ofs = OTPACDIS;
            map_len = OTPACDIS_SIZE;
            break;
        case OTP_SYM_TACDIS:
            map_ofs = OTPTACDIS;
            map_len = OTPTACDIS_SIZE;
            break;
        case OTP_SYM_RSIPHUK:
            map_ofs = OTPRSIPHUK;
            map_len = OTPRSIPHUK_SIZE;
            break;
        case OTP_SYM_SECBTOPTION0:
            map_ofs = SECBTOPTION0;
            map_len = SECBTOPTION0_SIZE;
            break;
        case OTP_SYM_ROTPKHASH:
            map_ofs = ROTPKHASH;
            map_len = ROTPKHASH_SIZE;
            break;
        case OTP_SYM_DECRYPTKEY0:
            map_ofs = DECRYPTKEY0;
            map_len = DECRYPTKEY0_SIZE;
            break;
        case OTP_SYM_DECRYPTKEY1:
            map_ofs = DECRYPTKEY1;
            map_len = DECRYPTKEY1_SIZE;
            break;
        case OTP_SYM_DECRYPTKEY2:
            map_ofs = DECRYPTKEY2;
            map_len = DECRYPTKEY2_SIZE;
            break;
        case OTP_SYM_DECRYPTKEY3:
            map_ofs = DECRYPTKEY3;
            map_len = DECRYPTKEY3_SIZE;
            break;
        case OTP_SYM_KEYUPDATEKEY:
            map_ofs = KEYUPDATEKEY;
            map_len = KEYUPDATEKEY_SIZE;
            break;
        default:
            ; /* Do Nothing */
            break;
    }

    if ((size << 2) == map_len)
    {
        offset = (int32_t) map_ofs;
    }

    return offset;
}
/**********************************************************************************************************************
 * End of function get_otp_offset
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otp_load
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t otp_load(const e_otp_symbol_t symbol, uint32_t *data, uint32_t size)
{
    int32_t ret_val = -1;

    int32_t offset = get_otp_offset (symbol, size);

    if (0 < offset)
    {
        uint32_t err = ((fp_otp_func_t) EXT_FUNC(OTP_API_READ)) (offset, size << 2, (uint8_t*) data);
        if (OTP_SUCCESS == err)
        {
            ret_val = 0;
        }
    }

    return ret_val;
}
/**********************************************************************************************************************
 * End of function otp_load
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otp_save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t otp_save(const e_otp_symbol_t symbol, const uint32_t *data, uint32_t size)
{
    int32_t ret_val = -1;

    int32_t offset = get_otp_offset (symbol, size);

    if (0 < offset)
    {
        uint32_t err = ((fp_otp_func_t) EXT_FUNC(OTP_API_WRITE)) (offset, size << 2, (uint8_t*) data);
        if (OTP_SUCCESS == err)
        {
            ret_val = 0;
        }
    }

    return ret_val;
}
/**********************************************************************************************************************
 * End of function otp_save
 *********************************************************************************************************************/
