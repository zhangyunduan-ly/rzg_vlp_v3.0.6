/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : message.c
 * Version      : 1.0
 * Description  : Show welcome message
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "version.h"
#include "drivers/sys_drv.h"
#include "message.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define RZG3S_DEVID     (0x085E0447)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_msg_rzg3s
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
static void show_msg_rzg3s(void)
{
    put_str (" Product Code : RZ/G3S", 1);
    return;
}
/**********************************************************************************************************************
 * End of function show_msg_rzg3s
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_welcome_msg
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
void show_welcome_msg(void)
{
    uint32_t device_id = sys_get_device_id ();

    put_str ("", 1);
    put_str (" Security Configurator : " VERSION " " DATE, 1);

    switch (device_id)
    {
        case RZG3S_DEVID:
            show_msg_rzg3s ();
        break;

        default:
            put_str ("", 1);
            put_str (" error: Unknown device ID.", 1);
            ASSERT(0);
        break;
    }
    put_str ("", 1);

    return;
}
/**********************************************************************************************************************
 * End of function show_welcome_msg
 *********************************************************************************************************************/
