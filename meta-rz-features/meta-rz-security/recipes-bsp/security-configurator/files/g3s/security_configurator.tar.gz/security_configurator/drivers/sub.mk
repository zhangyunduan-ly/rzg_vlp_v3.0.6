
SOURCES		+=	./drivers/cpg/cpg_drv.c 	\
				./drivers/ostm/ostm_drv.c	\
				./drivers/otp/otp_drv.c		\
				./drivers/pfc/pfc_drv.c		\
				./drivers/scif/scif_drv.c	\
				./drivers/syc/syc_drv.c		\
				./drivers/sys/sys_drv.c		\
				./drivers/sce/sce_drv.c		\
				./drivers/dev_drv.c			\
				./drivers/timer.c

MKFILE		+=	./drivers/sub.mk
