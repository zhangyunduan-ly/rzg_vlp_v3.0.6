
SOURCES		+=	./cmd/cmd_show.c         	\
				./cmd/cmd_write.c        	\
				./cmd/cmd_update.c      	\
				./cmd/command.c

MKFILE		+=	./cmd/sub.mk
