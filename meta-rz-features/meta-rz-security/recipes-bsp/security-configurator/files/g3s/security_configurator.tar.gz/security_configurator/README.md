# README of the RZ/G3S Security Configurator

<Div Align="right">
Renesas Electronics Corporation

Jun.28,2024
</Div>

## 1. How to build the Security Configurator

This chapter is described how to build the Security Configurator.
Command is executed in the user's home directory (~/).
The environment for building the Security Configurator is in the "~/security_configurator" directory.

One of the following toolchains is required to build.
| Name                | Note                                                             |
|---------------------|------------------------------------------------------------------|
| Yocto SDK           | Yocto SDK built from Yocto environment for RZ/G3S                |
| GNU Toolchain       | GNU Toolchain for the A-profile Architecture: 10.2-2020.11       |
| GNU Toolchain       | GNU Toolchain for the Embedded processors: 10.3-2021.07          |

### 1.1. Prepare the compiler

Get cross compiler for GNU Toolchain or setup the Yocto SDK.

Yocto SDK:

```shell
source /opt/poky/3.1.5/environment-setup-aarch64-poky-linux
```

GNU Toolchain (A-profile Architecture):

```shell
cd ~/
wget https://developer.arm.com/-/media/Files/downloads/gnu-a/10.2-2020.11/binrel/gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf.tar.xz
tar xvf gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf.tar.xz
```

GNU Toolchain (Embedded processors):

```shell
cd ~/
wget https://developer.arm.com/-/media/Files/downloads/gnu-rm/10.3-2021.10/gcc-arm-none-eabi-10.3-2021.10-x86_64-linux.tar.bz2
tar jxvf gcc-arm-none-eabi-10.3-2021.10-x86_64-linux.tar.bz2
```

### 1.2. Prepare the Keys

Store the wrapped keys generated when building the VLP in the folder.

```shell
cd ~/security_configurator
tar zxvf user_factory_prog-<board>.tar.gz -C ./install
```

Encrypt the user factory programming key using Renesas Key Wrap Service.

Rename the encrypted user factory  programming key to 'wrapped-ufpk.bin' and store it in the "~/security_configurator/install" directory.

'wrapped-ufpk.bin', stored by default in ./install directory, is an encrypted file of the user factory programming key provided as a sample.

### 1.3. Build the Security Configurator

S-record file will be built by the following command.

Yocto SDK:

```shell
make clean
make BOARD=RZG3S CORE=CA55
```

GNU Toolchain (A-profile Architecture):

```shell
make clean
CROSS_COMPILE=~/gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf/bin/aarch64-none-elf- make BOARD=RZG3S  CORE=CA55
```

GNU Toolchain (Embedded processors):

```shell
make clean
CROSS_COMPILE=~/gcc-arm-none-eabi-10.3-2021.07/bin/arm-none-eabi- make BOARD=RZG3S CORE=CM33
```

## 2. Revision history

Describe the revision history of the Security Configurator.

### [2023-11-30] v1.00

- First release.

### [2024-03-14] v1.10

- Modify dependencies for libraries and binaries.

### [2024-06-28] v1.20

- Update RSIP library for RZ/G3S.
