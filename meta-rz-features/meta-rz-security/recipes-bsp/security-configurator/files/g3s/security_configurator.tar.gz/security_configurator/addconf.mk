
define add_define
ifeq ($(value $(1)),y)
    DEFINES += -D$(1)$(if $(value $(1)),=$(value $(1)),)
endif
endef

define dep_define
ifeq ($(value $(1)) $(value $(2)),y n)
$$(error If $(1) is set to y, then $(2) must also be set to y)
endif
endef

define add_filedef
ifneq ($(realpath $(value $(1))),)
    DEFINES += -D$(1)=$(value $(1))
endif
endef

define dep_filedef
ifeq ($(realpath $(value $(1))),)
ifeq ($(value $(2)),y)
$$(error If $(2) is set to y, then $(1) must be set to the correct file path.)
endif
endif
endef

# y or n
CFG_OTP_RSIPHUK_PROV ?= n
$(eval $(call add_define,CFG_OTP_RSIPHUK_PROV))

# y or n
CFG_OTP_SECBT_EN ?= n
$(eval $(call add_define,CFG_OTP_SECBT_EN))

# none or auth or reject
CFG_OTP_JAUTH_MODE ?= none
$(eval CFG_OTP_JAUTH_MODE_$(CFG_OTP_JAUTH_MODE)=y)
$(eval $(call add_define,CFG_OTP_JAUTH_MODE_$(CFG_OTP_JAUTH_MODE)))

# idauth or secip
CFG_OTP_JAUTH_TYPE ?= secip
$(eval CFG_OTP_JAUTH_TYPE_$(CFG_OTP_JAUTH_TYPE)=y)
$(eval $(call add_define,CFG_OTP_JAUTH_TYPE_$(CFG_OTP_JAUTH_TYPE)))

# y or n
CFG_OTP_OTR_EN_0 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_0))
CFG_OTP_OTR_EN_1 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_1))

# y or n
CFG_OTP_SB_DIS_SD ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SD))
CFG_OTP_SB_DIS_EMMC18 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_EMMC18))
CFG_OTP_SB_DIS_EMMC33 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_EMMC33))
CFG_OTP_SB_DIS_SPI18 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SPI18))
CFG_OTP_SB_DIS_SPI33 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SPI33))
CFG_OTP_SB_DIS_SCIF ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SCIF))

# y or n
CFG_OTP_FAILSAFE_DIS ?= n
$(eval $(call add_define,CFG_OTP_FAILSAFE_DIS))

# y or n
CFG_OTP_ANTI_RB_EN ?= n
$(eval $(call add_define,CFG_OTP_ANTI_RB_EN))

# y or n
CFG_OTP_WP_AUTH_ID ?= n
$(eval $(call add_define,CFG_OTP_WP_AUTH_ID))

# y or n
CFG_OTP_RP_AUTH_ID ?= n
$(eval $(call add_define,CFG_OTP_RP_AUTH_ID))

# y or n
CFG_OTP_WP_FUNC ?= n
$(eval $(call add_define,CFG_OTP_WP_FUNC))

# y or n
CFG_OTP_WP_RAC_DIS ?= n
CFG_OTP_WP_TAC_DIS ?= n
$(eval $(call add_define,CFG_OTP_WP_RAC_DIS))
$(eval $(call add_define,CFG_OTP_WP_TAC_DIS))

# y or n
CFG_OTP_RAC_DIS ?= n
$(eval $(call add_define,CFG_OTP_RAC_DIS))

# y or n
CFG_OTP_TAC_DIS ?= n
$(eval $(call add_define,CFG_OTP_TAC_DIS))

# filepath or empty
CFG_WRAPPED_UFPK_FILE ?=
$(eval $(call add_filedef,CFG_WRAPPED_UFPK_FILE))
$(eval $(call dep_filedef,CFG_WRAPPED_UFPK_FILE,CFG_OTP_RSIPHUK_PROV))

# filepath or empty
CFG_UFPK_ENC_IV0_FILE ?=
$(eval $(call add_filedef,CFG_UFPK_ENC_IV0_FILE))
$(eval $(call dep_filedef,CFG_UFPK_ENC_IV0_FILE,CFG_OTP_RSIPHUK_PROV))

# filepath or empty
CFG_ROT_PK_HASH_FILE ?=
$(eval $(call add_filedef,CFG_ROT_PK_HASH_FILE))

# filepath or empty
CFG_AUTH_DATA_FILE ?=
$(eval $(call add_filedef,CFG_AUTH_DATA_FILE))

# filepath or empty
CFG_ENC_USER_KEY0_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY0_FILE))

# filepath or empty
CFG_ENC_USER_KEY1_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY1_FILE))

# filepath or empty
CFG_ENC_USER_KEY2_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY2_FILE))

# filepath or empty
CFG_ENC_USER_KEY3_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY3_FILE))

# filepath or empty
CFG_ENC_USER_KUK_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KUK_FILE))

