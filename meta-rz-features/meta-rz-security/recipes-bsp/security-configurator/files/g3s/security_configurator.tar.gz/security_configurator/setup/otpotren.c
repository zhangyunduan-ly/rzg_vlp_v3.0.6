/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpotren.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "setup.h"
#include "drivers/otp_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_NAME    (OTP_SYM_OTREN)
#define OTP_SIZE    (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_rd_data[OTP_SIZE];
static uint32_t s_wr_data[OTP_SIZE];

static uint32_t s_otren_0[] =
{ 0x00000000, OTP_OTR_EN_0 };

static int8_t *sp_otren_0_sentence[ARRAY_SIZE(s_otren_0)] =
{ "Do not enable", "Enable" };

static uint32_t s_otren_1[] =
{ 0x00000000, OTP_OTR_EN_1 };

static int8_t *sp_otren_1_sentence[ARRAY_SIZE(s_otren_1)] =
{ "Do not enable", "Enable" };

static st_setup_options_t s_opts[] =
{
    {
        ARRAY_SIZE(s_otren_0), s_otren_0, sp_otren_0_sentence,
        "Select whether to enable One Time Read of 0-63 bytes in the user area"
    },
    {
        ARRAY_SIZE(s_otren_1), s_otren_1, sp_otren_1_sentence,
        "Select whether to enable One Time Read of 64-127 bytes in the user area"
    },
};

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    memset ((uint8_t*) s_rd_data, 0, sizeof(s_rd_data));
    memset ((uint8_t*) s_wr_data, 0, sizeof(s_wr_data));

#if defined(CFG_OTP_OTR_EN_0)
    s_wr_data[0] |= OTP_OTR_EN_0;
#endif
#if defined(CFG_OTP_OTR_EN_1)
    s_wr_data[0] |= OTP_OTR_EN_1;
#endif
    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t save(void)
{
    return (otp_save (OTP_NAME, s_wr_data, ARRAY_SIZE(s_wr_data)));
}
/**********************************************************************************************************************
 * End of function save
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t **data, uint32_t *size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = 0;

    if (0 == mode)
    {
        ret = otp_load (OTP_NAME, s_rd_data, ARRAY_SIZE(s_rd_data));

        if (SETUP_SUCCESS == ret)
        {
            *data = &s_rd_data[0];
            *size = ARRAY_SIZE(s_rd_data);
        }
    }
    else
    {
        *data = &s_wr_data[0];
        *size = ARRAY_SIZE(s_wr_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t *data, uint32_t size)
{
    uint32_t otren = 0;

    ASSERT(size == ARRAY_SIZE(s_opts));

    ASSERT(data[0] < ARRAY_SIZE(s_otren_0));
    otren |= s_otren_0[data[0]];

    ASSERT(data[1] < ARRAY_SIZE(s_otren_1));
    otren |= s_otren_1[data[1]];

    s_wr_data[0] = otren;

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t *info)
{
    info->sel.num_of_sels = ARRAY_SIZE(s_opts);

    info->sel.p_opts = s_opts;

    return SEL;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otpotren
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void otpotren(st_setup_exec_t *exec)
{
    exec->p_name = "OTPOTREN";
    exec->p_init = init;
    exec->p_save = save;
    exec->p_ref = ref;
    exec->p_set = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function otpotren
 *********************************************************************************************************************/
