
ASSEMBLY	+=	./arch/armv8-m/boot_mon.s 	\
				./arch/armv8-m/stack.s		\
				./arch/armv8-m/incbin.s

LD_TEMPLATE	+= ./arch/armv8-m/linker_script.s

MKFILE		+=	./arch/armv8-m/sub.mk
