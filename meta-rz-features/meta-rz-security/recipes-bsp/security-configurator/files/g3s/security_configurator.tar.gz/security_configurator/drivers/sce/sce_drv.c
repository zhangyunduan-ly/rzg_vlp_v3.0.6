/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : sce_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "incbin.h"
#include "rz_soc_def.h"
#include "r_rsip_err.h"
#include "r_rsip_addr.h"
#include "r_rsip_primitive.h"
#include "drivers/sce_drv.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
volatile uint32_t * gp_sce;

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

static uint32_t s_init_vector[4];
static uint32_t s_session_key[9];

static uint32_t s_shrd_key_idx[8];

/**********************************************************************************************************************
 * Function Name: sce_init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void sce_init(void)
{
    const uint32_t *p_shrd_key_pos;

    gp_sce = (uint32_t*) RSIP_BASE;

    ASSERT((sizeof(s_session_key)) == ((uintptr_t)g_sizeof_session_key));
    memcpy ((uint8_t*) s_session_key, (uint8_t*) g_session_key, (uintptr_t)g_sizeof_session_key);

    ASSERT(sizeof(s_init_vector) == (uintptr_t)g_sizeof_init_vector);
    memcpy ((uint8_t*) s_init_vector, (uint8_t*) g_init_vector, (uintptr_t)g_sizeof_init_vector);

    p_shrd_key_pos = (const uint32_t*) &S_FLASH[bswap32 (s_session_key[0]) * 8];
    memcpy ((uint8_t*) &s_shrd_key_idx[0], (uint8_t*) p_shrd_key_pos, (uint32_t) (sizeof(s_shrd_key_idx)));
}
/**********************************************************************************************************************
 * End of function sce_init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_huk
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1
 *********************************************************************************************************************/
int32_t sce_install_huk(uint32_t *huk)
{
    int32_t ret = -1;

    rsip_ret_t err = r_rsip_p30 (huk);
    switch (err)
    {
        case RSIP_RET_PASS:
            ret = 0;
        break;

        default: /* RSIP_RET_RESOURCE_CONFLICT */
            ret = -1;
        break;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_huk
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_password
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_install_password(const uint32_t *encauth, uint32_t *password)
{
    int32_t ret = -1;

    uint32_t auth_hash[SCE_AUTH_DATA_HASH_SIZE];
    uint32_t hash_type = 0x00000000;

    rsip_ret_t err = r_rsip_p15 (&s_session_key[0], &s_shrd_key_idx[0], &s_session_key[1],
        s_init_vector, (uint32_t*) encauth, &hash_type, auth_hash);

    switch (err)
    {
        case RSIP_RET_PASS:
            for (int32_t i = SCE_AUTH_DATA_HASH_SIZE; (i > 0); i--)
            {
                *password = bswap32 (auth_hash[i - 1]);
                password++;
            }
            ret = 0;
        break;

        case RSIP_RET_FAIL:
            ret = -2;
        break;

        default: /* RSIP_RET_RESOURCE_CONFLICT */
            ret = -1;
        break;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_password
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_aeskey_boot
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_install_aeskey_boot(const uint32_t *instkey, uint32_t *keyindex)
{
    int32_t ret = -1;

    rsip_ret_t err = r_rsip_p03 (&s_session_key[0], &s_shrd_key_idx[0], &s_session_key[1], s_init_vector,
        (uint32_t*) instkey, keyindex);

    switch (err)
    {
        case RSIP_RET_PASS:
            ret = 0;
        break;

        case RSIP_RET_FAIL:
            ret = -2;
        break;

        default: /* RSIP_RET_RESOURCE_CONFLICT */
            ret = -1;
        break;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_aeskey_boot
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_kuk
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_install_kuk(const uint32_t *instkey, uint32_t *keyindex)
{
    int32_t ret = -1;

    rsip_ret_t err = r_rsip_p1f (&s_session_key[0], &s_shrd_key_idx[0], &s_session_key[1],
        s_init_vector, (uint32_t*) instkey, keyindex);

    switch (err)
    {
        case RSIP_RET_PASS:
            ret = 0;
        break;

        case RSIP_RET_FAIL:
            ret = -2;
        break;

        default: /* RSIP_RET_RESOURCE_CONFLICT */
            ret = -1;
        break;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_kuk
 *********************************************************************************************************************/
