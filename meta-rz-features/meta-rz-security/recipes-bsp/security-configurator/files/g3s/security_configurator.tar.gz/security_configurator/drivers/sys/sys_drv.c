/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : sys_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "mmio.h"
#include "rz_soc_def.h"
#include "drivers/sys_drv.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define SYS_LSI_DEVID   (0xA04)
#define DEVID_MASK      (0x0FFFFFFFul)
#define INFO_MASK       (0xF0000000ul)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sys_reg_read
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static uint32_t sys_reg_read(uint32_t offset)
{
    return (mmio_read_32 (SYS_BASE + offset));
}
/**********************************************************************************************************************
 * End of function sys_reg_read
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sys_get_device_id
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
uint32_t sys_get_device_id(void)
{
    return (sys_reg_read (SYS_LSI_DEVID) & DEVID_MASK);
}
/**********************************************************************************************************************
 * End of function sys_get_device_id
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sys_get_device_info
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
uint32_t sys_get_device_info(void)
{
    return ((sys_reg_read (SYS_LSI_DEVID) & INFO_MASK) >> 28);
}
/**********************************************************************************************************************
 * End of function sys_get_device_info
 *********************************************************************************************************************/
