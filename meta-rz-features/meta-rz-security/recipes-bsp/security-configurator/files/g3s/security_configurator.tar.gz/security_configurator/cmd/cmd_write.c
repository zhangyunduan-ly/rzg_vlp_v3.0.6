/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cmd_write.c
 * Version      : 1.0
 * Description  : write to OTP
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "setup.h"
#include "command.h"

#include "command_private.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define REG_NAME_LEN    (16)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: is_empty
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t is_empty(uint32_t *mem, uint32_t size)
{
    while (0 < (size--))
    {
        if (0 != (*mem++ ))
        {
            return 0;
        }
    }
    return 1;
}
/**********************************************************************************************************************
 * End of function is_empty
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: is_writable_area
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int8_t* is_writable_area(const st_setup_exec_t *exec)
{
    int8_t *p_msg = 0;

    uint32_t size;

    uint32_t * p_data;

    int32_t err = exec->p_ref(0, &p_data, &size);

    switch (err)
    {
        case SETUP_SUCCESS:
            if (!is_empty(p_data, size))
            {
                p_msg = "Already Written";
            }
            break;

        case SETUP_PROT_AREA_ACCESS:
            break;

        default:
            p_msg = setup_errstr(err);
            break;
    }

    return p_msg;
}
/**********************************************************************************************************************
 * End of function is_writable_area
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: is_writable_data
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int8_t* is_writable_data(const st_setup_exec_t *exec)
{
    int8_t *p_msg = 0;

    uint32_t size;

    uint32_t * p_data;

    int32_t err = exec->p_ref(1, &p_data, &size);

    switch (err)
    {
        case SETUP_SUCCESS:
            if (is_empty(p_data, size))
            {
                p_msg = "No Write Data";
            }
            break;

        default:
            p_msg = setup_errstr(err);
            break;
    }

    return p_msg;
}
/**********************************************************************************************************************
 * End of function is_writable_data
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: check_write_skip
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t check_write_skip(const st_setup_exec_t * exec)
{
    int32_t  ret = 0;

    int8_t *p_msg = 0;

    p_msg = is_writable_area(exec);

    if (0 == p_msg)
    {
        p_msg = is_writable_data(exec);
    }

    if (0 != p_msg)
    {
        put_str("skip (", 0);
        put_str(p_msg, 0);
        put_str(")", 1);
        ret = -1;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function check_write_skip
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: print_reg_name
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void print_reg_name(int8_t *p_reg_name)
{
    int8_t name_buff[REG_NAME_LEN + 1];

    int32_t name_len = str_len(p_reg_name);

    ASSERT(REG_NAME_LEN > name_len);

    memset(name_buff, ' ', REG_NAME_LEN);

    memcpy(&name_buff[1], p_reg_name, name_len);

    name_buff[REG_NAME_LEN - 1] = ':';
    name_buff[REG_NAME_LEN]     = '\0';

    put_str(name_buff, 0);

    return;
}
/**********************************************************************************************************************
 * End of function print_reg_name
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cmd_write
 *********************************************************************************************************************/
int32_t cmd_write(void)
{
    put_str("", 1);
    put_str("<<<< Command to write setup data >>>>", 1);
    put_str("", 1);

    for (int32_t i = 0; (i < gp_setup->num); i++)
    {
        if (0 != gp_setup->exec[i].p_save)
        {
            print_reg_name(gp_setup->exec[i].p_name);

            if (0 == check_write_skip(&gp_setup->exec[i]))
            {
                int32_t err = gp_setup->exec[i].p_save();

                if (SETUP_SUCCESS == err)
                {
                    put_str("success", 1);
                }
                else
                {
                    put_str("error (", 0);
                    put_str(setup_errstr(err), 0);
                    put_str(")", 1);
                }
            }
        }
    }

    put_str("", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function cmd_write
 *********************************************************************************************************************/
