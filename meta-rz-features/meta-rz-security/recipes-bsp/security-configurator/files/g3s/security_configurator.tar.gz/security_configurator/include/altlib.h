/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : altlib.h
 * Version      : 1.0
 * Description  : Alternative to standard library
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>
#include <stdbool.h>

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef ALTLIB_H
#define ALTLIB_H

/* Number of elements present in an array */
#define ARRAY_SIZE(_array)  (sizeof(_array) / sizeof((_array)[0]))

#define INT_CODE            (0x03)  /* CTRL+C */
#define BS_CODE             (0x08)  /* BackSpace */
#define LF_CODE             (0x0a)  /* Line Feed */
#define CR_CODE             (0x0d)  /* Carriage Return */
#define ESC_CODE            (0x1b)  /* Escape */
#define SP_CODE             (0x20)  /* Space */
#define DEL_CODE            (0x7f)  /* Delete */

#if defined(THUMB)
/* In Thumb state, pointers to the function must have the least significant bit set. */
#define EXT_FUNC(ptr)   ((ptr) | 0x1)
#else
/* Otherwise, pointers to functions need not be set. */
#define EXT_FUNC(ptr)   ((ptr))
#endif

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
extern int32_t put_char(int8_t ch);
extern int32_t get_char(void);
extern int32_t put_str(const int8_t *str, int8_t rtn);
extern int32_t get_str(int8_t *str, uint32_t *len);
extern int32_t str_cmp(const int8_t *str1, const int8_t *str2);
extern int32_t strn_cmp(const int8_t *str1, const int8_t *str2, uint32_t len);
extern uint32_t str_len(const int8_t *str);
extern int32_t hex_to_ascii(uint32_t data, int8_t *str, int8_t pad);
extern int32_t ascii_to_hex(int8_t *str, uint32_t *data);
extern int32_t int_to_ascii(int32_t data, int8_t *str);
extern void to_upper(int8_t *str);
extern void* memcpy(uint8_t *dst, uint8_t *src, uint32_t len);
extern void* memset(uint8_t *mem, int8_t ch, uint32_t len);
extern uint32_t bswap32(uint32_t data);

#endif /* ALTLIB_H */
