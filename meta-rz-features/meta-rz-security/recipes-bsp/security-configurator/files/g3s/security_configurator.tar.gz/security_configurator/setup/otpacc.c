/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpacc.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "setup.h"
#include "drivers/otp_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_NAME    (OTP_SYM_ACC)
#define OTP_SIZE    (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_rd_data[OTP_SIZE];
static uint32_t s_wr_data[OTP_SIZE];

static uint32_t s_wpauthid[] =
{ 0, OTP_WP_AUTH_ID };

static int8_t *sp_wpauthid_sentence[ARRAY_SIZE(s_wpauthid)] =
{ "Do not protect", "Protect" };

static uint32_t s_rpauthid[] =
{ 0, OTP_RP_AUTH_ID };

static int8_t *sp_rpauthid_sentence[ARRAY_SIZE(s_rpauthid)] =
{ "Do not protect", "Protect" };

static uint32_t s_wpfunc[] =
{ 0, OTP_WP_FUNC };

static int8_t *sp_wpfunc_sentence[ARRAY_SIZE(s_wpfunc)] =
{ "Do not protect", "Protect" };

static uint32_t s_wpacdis[] =
{ 0, OTP_WP_ACDIS };

static int8_t *sp_wpacdis_sentence[ARRAY_SIZE(s_wpacdis)] =
{ "Do not protect", "Protect" };

static uint32_t s_wptacdis[] =
{ 0, OTP_WP_TACDIS };

static int8_t *sp_wptacdis_sentence[ARRAY_SIZE(s_wptacdis)] =
{ "Do not protect", "Protect" };

static st_setup_options_t s_opts[] =
{
    {
        ARRAY_SIZE(s_wpauthid), s_wpauthid, sp_wpauthid_sentence,
        "Select whether to protect the OTPAUTHID area from writing"
    },
    {
        ARRAY_SIZE(s_rpauthid), s_rpauthid, sp_rpauthid_sentence,
        "Select whether to protect the OTPAUTHID area from reading"
    },
    {
        ARRAY_SIZE(s_wpfunc), s_wpfunc, sp_wpfunc_sentence,
        "Select whether to protect the function setting area from writing"
    },
    {
        ARRAY_SIZE(s_wpacdis), s_wpacdis, sp_wpacdis_sentence,
        "Select whether to protect the OTPACDIS area from writing"
    },
    {
        ARRAY_SIZE(s_wptacdis), s_wptacdis, sp_wptacdis_sentence,
        "Select whether to protect the OTPTACDIS area from writing"
    }
};

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    memset ((uint8_t*) s_rd_data, 0, sizeof(s_rd_data));
    memset ((uint8_t*) s_wr_data, 0, sizeof(s_wr_data));

#if defined(CFG_OTP_WP_AUTH_ID)
    s_wr_data[0] |= OTP_WP_AUTH_ID;
#endif
#if defined(CFG_OTP_RP_AUTH_ID)
    s_wr_data[0] |= OTP_RP_AUTH_ID;
#endif
#if defined(CFG_OTP_WP_FUNC)
    s_wr_data[0] |= OTP_WP_FUNC;
#endif
#if defined(CFG_OTP_WP_RAC_DIS)
    s_wr_data[0] |= OTP_WP_ACDIS;
#endif
#if defined(CFG_OTP_WP_TAC_DIS)
    s_wr_data[0] |= OTP_WP_TACDIS;
#endif

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t save(void)
{
    return (otp_save (OTP_NAME, s_wr_data, ARRAY_SIZE(s_wr_data)));
}
/**********************************************************************************************************************
 * End of function save
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t **data, uint32_t *size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = 0;

    if (0 == mode)
    {
        ret = otp_load (OTP_NAME, s_rd_data, ARRAY_SIZE(s_rd_data));

        if (SETUP_SUCCESS == ret)
        {
            *data = &s_rd_data[0];
            *size = ARRAY_SIZE(s_rd_data);
        }
    }
    else
    {
        *data = &s_wr_data[0];
        *size = ARRAY_SIZE(s_wr_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t *data, uint32_t size)
{
    uint32_t otpacc = 0;

    ASSERT(size == ARRAY_SIZE(s_opts));

    ASSERT(data[0] < ARRAY_SIZE(s_wpauthid));
    otpacc |= s_wpauthid[data[0]];

    ASSERT(data[1] < ARRAY_SIZE(s_rpauthid));
    otpacc |= s_rpauthid[data[1]];

    ASSERT(data[2] < ARRAY_SIZE(s_wpfunc));
    otpacc |= s_wpfunc[data[2]];

    ASSERT(data[3] < ARRAY_SIZE(s_wpacdis));
    otpacc |= s_wpacdis[data[3]];

    ASSERT(data[4] < ARRAY_SIZE(s_wptacdis));
    otpacc |= s_wptacdis[data[4]];

    s_wr_data[0] = otpacc;

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t *info)
{
    info->sel.num_of_sels = ARRAY_SIZE(s_opts);

    info->sel.p_opts = s_opts;

    return SEL;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otpacc
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void otpacc(st_setup_exec_t *exec)
{
    exec->p_name = "OTPACC";
    exec->p_init = init;
    exec->p_save = save;
    exec->p_ref = ref;
    exec->p_set = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function otpacc
 *********************************************************************************************************************/
