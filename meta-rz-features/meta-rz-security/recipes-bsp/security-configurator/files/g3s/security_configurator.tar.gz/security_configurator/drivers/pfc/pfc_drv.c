/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : pfc_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "mmio.h"
#include "drivers/sys_drv.h"
#include "drivers/pfc_drv.h"

#include "pfc_regs.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static st_pfc_regs_t s_pfc_mux_scif_reg_tbl[PFC_MUX_SCIF_TBL_NUM] =
{
    /* P6(scif0) - Tx, Rx*/
    {
        { PFC_ON,   (uintptr_t)PFC_PMC22,   0x18 },                 /* PMC */
        { PFC_ON,   (uintptr_t)PFC_PFC22,   0x00000000 },           /* PFC */
        { PFC_ON,   (uintptr_t)PFC_IOLH22,  0x0000000303000000 },   /* IOLH */
        { PFC_ON,   (uintptr_t)PFC_PUPD22,  0x0000000000000000 },   /* PUPD */
        { PFC_OFF,  (uintptr_t)0,        0 },                    /* SR */
        { PFC_OFF,  (uintptr_t)0,        0 }                     /* IEN */
    }
};

static const st_pfc_regs_t * sp_pfc_boot_mode_tbls[] =
{ s_pfc_mux_scif_reg_tbl };

static const uint8_t s_pfc_boot_mode_tbl_len[] =
{ PFC_MUX_SCIF_TBL_NUM };

/**********************************************************************************************************************
 * Function Name: pfc_write_registers
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_write_registers(uint8_t tbl_size, st_pfc_regs_t *pfc_reg_tbl)
{
    int32_t cnt;

    for (cnt = 0; cnt < tbl_size; cnt++)
    {
        /* PMC */
        if (PFC_ON == pfc_reg_tbl[cnt].pmc.flg)
        {
            mmio_write_8 (pfc_reg_tbl[cnt].pmc.reg, pfc_reg_tbl[cnt].pmc.val);
        }

        /* PFC */
        if (PFC_ON == pfc_reg_tbl[cnt].pfc.flg)
        {
            mmio_write_32 (pfc_reg_tbl[cnt].pfc.reg, pfc_reg_tbl[cnt].pfc.val);
        }

        /* PUPD */
        if (PFC_ON == pfc_reg_tbl[cnt].pupd.flg)
        {
            mmio_write_64 (pfc_reg_tbl[cnt].pupd.reg, pfc_reg_tbl[cnt].pupd.val);
        }

        /* SR */
        if (PFC_ON == pfc_reg_tbl[cnt].sr.flg)
        {
            mmio_write_64 (pfc_reg_tbl[cnt].sr.reg, pfc_reg_tbl[cnt].sr.val);
        }

        /* IEN */
        if (PFC_ON == pfc_reg_tbl[cnt].ien.flg)
        {
            mmio_write_64 (pfc_reg_tbl[cnt].ien.reg, pfc_reg_tbl[cnt].ien.val);
        }
    }
}
/**********************************************************************************************************************
 * End of function pfc_write_registers
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_scif_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_scif_setup(void)
{
    /* multiplexer terminal switching */
    mmio_write_32 (PFC_PWPR, 0x0);
    mmio_write_32 (PFC_PWPR, PWPR_PFCWE);

    pfc_write_registers (PFC_MUX_SCIF_TBL_NUM, s_pfc_mux_scif_reg_tbl);

    mmio_write_32 (PFC_PWPR, 0x0);
    mmio_write_32 (PFC_PWPR, PWPR_B0WI);
}
/**********************************************************************************************************************
 * End of function pfc_scif_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_drive_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_drive_setup(void)
{
    for (int32_t i = 0; i < ARRAY_SIZE(sp_pfc_boot_mode_tbls); i++)
    {
        const st_pfc_regs_t *p_pins_tbl = sp_pfc_boot_mode_tbls[i];

        uint8_t tbl_len = s_pfc_boot_mode_tbl_len[i];

        int32_t cnt;

        for (cnt = 0; cnt < tbl_len; cnt++)
        {
            if (PFC_ON == p_pins_tbl[cnt].iolh.flg)
            {
                /* Write IOLH value from s_pfc_sd_reg_tbl[] masked with value in pin table */
                mmio_write_64 (p_pins_tbl[cnt].iolh.reg, p_pins_tbl[cnt].iolh.val);
            }
        }
    }
}
/**********************************************************************************************************************
 * End of function pfc_drive_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void pfc_setup(void)
{
    pfc_scif_setup ();
    pfc_drive_setup ();
}
/**********************************************************************************************************************
 * End of function pfc_setup
 *********************************************************************************************************************/
