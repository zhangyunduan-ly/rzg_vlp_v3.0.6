/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : incbin.s
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

#include "incbin.h"

#define _STRINGIFY(x) #x
#define STRINGIFY(x) _STRINGIFY(x)

    .section    .rodata
    .global     g_session_key
    .align      4
g_session_key:
#if defined(CFG_WRAPPED_UFPK_FILE)
    .incbin     STRINGIFY(CFG_WRAPPED_UFPK_FILE)
#endif
    .global     g_sizeof_session_key
    .set        g_sizeof_session_key, . - g_session_key

    .section    .rodata
    .global     g_init_vector
    .align      4
g_init_vector:
#if defined(CFG_UFPK_ENC_IV0_FILE)
    .incbin     STRINGIFY(CFG_UFPK_ENC_IV0_FILE)
#endif
    .global     g_sizeof_init_vector
    .set        g_sizeof_init_vector, . - g_init_vector

    .section    .rodata
    .global     g_rotpk_hash
    .align      4
g_rotpk_hash:
#if defined(CFG_ROT_PK_HASH_FILE)
    .incbin     STRINGIFY(CFG_ROT_PK_HASH_FILE)
#endif
    .global     g_sizeof_rotpk_hash
    .set        g_sizeof_rotpk_hash, . - g_rotpk_hash

    .section    .rodata
    .global     g_auth_data
    .align      4
g_auth_data:
#if defined(CFG_AUTH_DATA_FILE)
    .incbin     STRINGIFY(CFG_AUTH_DATA_FILE)
#endif
    .global     g_sizeof_auth_data
    .set        g_sizeof_auth_data, . - g_auth_data

    .section    .rodata
    .global     g_enc_inst_key0
    .align      4
g_enc_inst_key0:
#if defined(CFG_ENC_USER_KEY0_FILE)
    .incbin     STRINGIFY(CFG_ENC_USER_KEY0_FILE)
#endif
    .global     g_sizeof_enc_inst_key0
    .set        g_sizeof_enc_inst_key0, . - g_enc_inst_key0

    .section    .rodata
    .global     g_enc_inst_key1
    .align      4
g_enc_inst_key1:
#if defined(CFG_ENC_USER_KEY1_FILE)
    .incbin     STRINGIFY(CFG_ENC_USER_KEY1_FILE)
#endif
    .global     g_sizeof_enc_inst_key1
    .set        g_sizeof_enc_inst_key1, . - g_enc_inst_key1

    .section    .rodata
    .global     g_enc_inst_key2
    .align      4
g_enc_inst_key2:
#if defined(CFG_ENC_USER_KEY2_FILE)
    .incbin     STRINGIFY(CFG_ENC_USER_KEY2_FILE)
#endif
    .global     g_sizeof_enc_inst_key2
    .set        g_sizeof_enc_inst_key2, . - g_enc_inst_key2

    .section    .rodata
    .global     g_enc_inst_key3
    .align      4
g_enc_inst_key3:
#if defined(CFG_ENC_USER_KEY3_FILE)
    .incbin     STRINGIFY(CFG_ENC_USER_KEY3_FILE)
#endif
    .global     g_sizeof_enc_inst_key3
    .set        g_sizeof_enc_inst_key3, . - g_enc_inst_key3

    .section    .rodata
    .global     g_enc_inst_kuk
    .align      4
g_enc_inst_kuk:
#if defined(CFG_ENC_USER_KUK_FILE)
    .incbin     STRINGIFY(CFG_ENC_USER_KUK_FILE)
#endif
    .global     g_sizeof_enc_inst_kuk
    .set        g_sizeof_enc_inst_kuk, . - g_enc_inst_kuk
