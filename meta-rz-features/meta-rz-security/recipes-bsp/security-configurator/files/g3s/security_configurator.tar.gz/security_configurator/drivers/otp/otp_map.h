/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : otp_map.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "rz_soc_def.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#ifndef OTP_MAP_H
#define OTP_MAP_H

#define OTPAESKEY                   (0x0028 << 2)
#define OTPAUTHID                   (0x0064 << 2)
#define OTPSECBTEN                  (0x0068 << 2)
#define OTPJAM                      (0x0069 << 2)
#define OTPOTREN                    (0x006A << 2)
#define OTPSECBTMODE                (0x006B << 2)
#define OTPPOC                      (0x006C << 2)
#define OTPARB                      (0x006D << 2)
#define OTPACC                      (0x006E << 2)
#define OTPLIFECYC_P                (0x0070 << 2)
#define OTPACDIS                    (0x0072 << 2)
#define OTPTACDIS                   (0x0073 << 2)
#define OTPRSIPHUK                  (0x0074 << 2)
#define SECBTOPTION0                (0x00A1 << 2)
#define ROTPKHASH                   (0x00A8 << 2)
#define DECRYPTKEY0                 (0x00B0 << 2)
#define DECRYPTKEY1                 (0x00BC << 2)
#define DECRYPTKEY2                 (0x00C8 << 2)
#define DECRYPTKEY3                 (0x00D4 << 2)
#define KEYUPDATEKEY                (0x00E0 << 2)

#define OTPAESKEY128_SIZE           (48)
#define OTPAESKEY256_SIZE           (64)
#define OTPAUTHID_SIZE              (16)
#define OTPSECBTEN_SIZE             (4)
#define OTPJAM_SIZE                 (4)
#define OTPOTREN_SIZE               (4)
#define OTPSECBTMODE_SIZE           (4)
#define OTPPOC_SIZE                 (4)
#define OTPARB_SIZE                 (4)
#define OTPACC_SIZE                 (4)
#define OTPLIFECYC_P_SIZE           (4)
#define OTPACDIS_SIZE               (4)
#define OTPTACDIS_SIZE              (4)
#define OTPRSIPHUK_SIZE             (48)
#define SECBTOPTION0_SIZE           (4)
#define ROTPKHASH_SIZE              (32)
#define DECRYPTKEY0_SIZE            (48)
#define DECRYPTKEY1_SIZE            (48)
#define DECRYPTKEY2_SIZE            (48)
#define DECRYPTKEY3_SIZE            (48)
#define KEYUPDATEKEY_SIZE           (64)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* OTP_MAP_H */
