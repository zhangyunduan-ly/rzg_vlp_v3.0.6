/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : scif_regs.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "rz_soc_def.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef SCIF_REGS_H
#define SCIF_REGS_H

#define SCIF_SMR                (SCIF_BASE + 0x0000)
#define SCIF_BRR                (SCIF_BASE + 0x0002)
#define SCIF_MDDR               (SCIF_BASE + 0x0002)
#define SCIF_SCR                (SCIF_BASE + 0x0004)
#define SCIF_FTDR               (SCIF_BASE + 0x0006)
#define SCIF_FSR                (SCIF_BASE + 0x0008)
#define SCIF_FRDR               (SCIF_BASE + 0x000A)
#define SCIF_FCR                (SCIF_BASE + 0x000C)
#define SCIF_FDR                (SCIF_BASE + 0x000E)
#define SCIF_SPTR               (SCIF_BASE + 0x0010)
#define SCIF_LSR                (SCIF_BASE + 0x0012)
#define SCIF_SEMR               (SCIF_BASE + 0x0014)
#define SCIF_FTCR               (SCIF_BASE + 0x0016)

/*
 * Serial mode register bit mask definitions
 */
#define SCIF_SMR_CM_SYNCH       (0x00U)
#define SCIF_SMR_CM_CLOCK       (0x80U)
#define SCIF_SMR_CHR_8BIT       (0x00U)
#define SCIF_SMR_CHR_7BIT       (0x40U)
#define SCIF_SMR_PE_DIS         (0x00U)
#define SCIF_SMR_PE_EN          (0x20U)
#define SCIF_SMR_PM_EVEN        (0x00U)
#define SCIF_SMR_PM_ODD         (0x10U)
#define SCIF_SMR_STOP_1BIT      (0x00U)
#define SCIF_SMR_STOP_2BIT      (0x04U)
#define SCIF_SMR_CKS_PCLK       (0x00U)
#define SCIF_SMR_CKS_PCLK4      (0x01U)
#define SCIF_SMR_CKS_PCLK16     (0x02U)
#define SCIF_SMR_CKS_PCLK64     (0x03U)

/*
 * Serial control register bit mask definitions
 */
#define SCIF_SCR_TIE_EN         (0x0080U)
#define SCIF_SCR_TIE_DIS        (0x0000U)
#define SCIF_SCR_RIE_EN         (0x0040U)
#define SCIF_SCR_RIE_DIS        (0x0000U)
#define SCIF_SCR_TE_EN          (0x0020U)
#define SCIF_SCR_TE_DIS         (0x0000U)
#define SCIF_SCR_RE_EN          (0x0010U)
#define SCIF_SCR_RE_DIS         (0x0000U)
#define SCIF_SCR_REIE_EN        (0x0008U)
#define SCIF_SCR_REIE_DIS       (0x0000U)
#define SCIF_SCR_TEIE_EN        (0x0004U)
#define SCIF_SCR_TEIE_DIS       (0x0000U)
#define SCIF_SCR_CKE_SYNC_IN    (0x0000U)

/*
 * Serial control register bit mask definitions
 */
#define SCIF_FCR_RSTRG_15       (0x0000U)
#define SCIF_FCR_RTRG_1         (0x0000U)
#define SCIF_FCR_TTRG_8         (0x0000U)
#define SCIF_FCR_MCE_EN         (0x0008U)
#define SCIF_FCR_MCE_DIS        (0x0000U)
#define SCIF_FCR_TFRST_EN       (0x0004U)
#define SCIF_FCR_TFRST_DIS      (0x0000U)
#define SCIF_FCR_RFRST_EN       (0x0002U)
#define SCIF_FCR_RFRST_DIS      (0x0000U)
#define SCIF_FCR_LOOP_EN        (0x0001U)
#define SCIF_FCR_LOOP_DIS       (0x0000U)

/*
 * Serial status register bit mask definitions
 */
#define SCIF_FSR_ER             (0x0080U)
#define SCIF_FSR_TEND           (0x0040U)
#define SCIF_FSR_TDFE           (0x0020U)
#define SCIF_FSR_BRK            (0x0010U)
#define SCIF_FSR_RDF            (0x0002U)
#define SCIF_FSR_DR             (0x0001U)
#define SCIF_FSR_CLEAR          (0x0000U)

/*
 * Line status register bit mask definitions
 */
#define SCIF_LSR_ORER           (0x0001U)
#define SCIF_LSR_CLEAR          (0x0000U)

/*
 * Serial Extended mode register bit mask definitions
 */
#define SCIF_SEMR_BRME          (0x20U)
#define SCIF_SEMR_MDDRS         (0x10U)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif  /* SCIF_REGS_H */
