/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : scif_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "mmio.h"
#include "drivers/timer.h"
#include "drivers/scif_drv.h"
#include "scif_regs.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif_put_char
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t scif_put_char(int8_t outChar)
{
    while (!(0x0060U & mmio_read_16 (SCIF_FSR)))
    {
        ;
    }
    mmio_write_8 (SCIF_FTDR, outChar);

    /* TEND,TDFE clear */
    mmio_write_16 (SCIF_FSR, mmio_read_16 (SCIF_FSR) & (~0x0060u));

    return 0;
}
/**********************************************************************************************************************
 * End of function scif_put_char
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif_get_char
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t scif_get_char(int8_t *inChar)
{
    do
    {
        if (0x0091u & mmio_read_16 (SCIF_FSR))
        {
            mmio_write_16 (SCIF_FSR, mmio_read_16 (SCIF_FSR) & (~0x0091u));
        }
        if (0x0001u & mmio_read_16 (SCIF_LSR))
        {
            put_str ("ORER", 1);
            mmio_write_16 (SCIF_LSR, mmio_read_16 (SCIF_LSR) & (~0x0001u));
        }
    }
    while (!(0x0002u & mmio_read_16 (SCIF_FSR)));

    *inChar = mmio_read_8 (SCIF_FRDR);

    mmio_write_16 (SCIF_FSR, mmio_read_16 (SCIF_FSR) & (~0x0002u));

    return 0;
}
/**********************************************************************************************************************
 * End of function scif_get_char
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif_put_wait_end
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void scif_put_wait_end(void)
{
    while (1)
    {
        if (mmio_read_16 (SCIF_FSR) & SCIF_FSR_TEND)
        {
            break;
        }
    }
}
/**********************************************************************************************************************
 * End of function scif_put_wait_end
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif_init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void scif_init(void)
{
    /* dummy read */
    mmio_read_16 (SCIF_LSR);

    /* clear ORER bit */
    mmio_write_16 (SCIF_LSR, 0x0000u);

    /* clear all error bit */
    mmio_write_16 (SCIF_FSR, 0x0000u);

    /* clear SCR.TE & SCR.RE */
    mmio_write_16 (SCIF_SCR, 0x0000u);

    /* reset tx-fifo, reset rx-fifo. */
    mmio_write_16 (SCIF_FCR, 0x0006u);

    /* clear ER, TEND, TDFE, BRK, RDF, DR */
    mmio_write_16 (SCIF_FSR, 0x0000u);

    /* internal clock P1/1 */
    mmio_write_16 (SCIF_SCR, 0x0000u);

    /* 8bit data, no-parity, 1 stop, Po/1 */
    mmio_write_16 (SCIF_SMR, 0x0000u);
    mmio_write_8 (SCIF_SEMR, 0x00u);

    udelay (100);

    /* 115200bps */
    mmio_write_8 (SCIF_BRR, 0x1Au);
    mmio_write_8 (SCIF_SEMR, 0x10u);

    udelay (100);

    /* reset-off tx-fifo, rx-fifo. */
    mmio_write_16 (SCIF_FCR, 0x0000u);

    /* enable TE, RE */
    mmio_write_16 (SCIF_SCR, 0x0030u);

    udelay (100);
}
/**********************************************************************************************************************
 * End of function scif_init
 *********************************************************************************************************************/
