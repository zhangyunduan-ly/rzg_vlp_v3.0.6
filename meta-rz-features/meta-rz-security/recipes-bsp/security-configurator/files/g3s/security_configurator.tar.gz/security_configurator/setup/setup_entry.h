/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : setup_entry.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#ifndef SETUP_ENTRY_H
#define SETUP_ENTRY_H
/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
extern void otpauthid(st_setup_exec_t *exec);
extern void otpsecbten(st_setup_exec_t *exec);
extern void otpjam(st_setup_exec_t *exec);
extern void otpotren(st_setup_exec_t *exec);
extern void otpsecbtmode(st_setup_exec_t *exec);
extern void otparb(st_setup_exec_t *exec);
extern void otpacc(st_setup_exec_t *exec);
extern void otpacdis(st_setup_exec_t *exec);
extern void otptacdis(st_setup_exec_t *exec);
extern void otprsiphuk(st_setup_exec_t *exec);
extern void rotpkhash(st_setup_exec_t *exec);
extern void decryptkey0(st_setup_exec_t *exec);
extern void decryptkey1(st_setup_exec_t *exec);
extern void decryptkey2(st_setup_exec_t *exec);
extern void decryptkey3(st_setup_exec_t *exec);
extern void keyupdatekey(st_setup_exec_t *exec);

#endif /* SETUP_ENTRY_H */
