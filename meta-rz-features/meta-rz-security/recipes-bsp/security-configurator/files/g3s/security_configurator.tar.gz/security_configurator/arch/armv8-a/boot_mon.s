/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : boot_mon.s
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

    .align    4
    .global   start

start:

    /* Initialize register */
    ldr     x0, =0
    ldr     x1, =0
    ldr     x2, =0
    ldr     x3, =0
    ldr     x4, =0
    ldr     x5, =0
    ldr     x6, =0
    ldr     x7, =0
    ldr     x8, =0
    ldr     x9, =0
    ldr     x10, =0
    ldr     x11, =0
    ldr     x12, =0
    ldr     x13, =0
    ldr     x14, =0
    ldr     x15, =0
    ldr     x16, =0
    ldr     x17, =0
    ldr     x18, =0
    ldr     x19, =0
    ldr     x20, =0
    ldr     x21, =0
    ldr     x22, =0
    ldr     x23, =0
    ldr     x24, =0
    ldr     x25, =0
    ldr     x26, =0
    ldr     x27, =0
    ldr     x28, =0
    ldr     x29, =0
    ldr     x30, =0

    /* Set Stack Pointer */
    ldr     x0, =__STACKS_END__
    msr     sp_el0,x0
    msr     sp_el1,x0
    msr     sp_el2,x0
    mov     sp,x0
    msr     elr_el1,x0
    msr     elr_el2,x0
    msr     elr_el3,x0
    msr     spsr_el1,x0
    msr     spsr_el2,x0
    msr     spsr_el3,x0

    /* Enable cache */
    mrs     x0, sctlr_el3
    orr     x0, x0, #(0x1 << 12)
    orr     x0, x0, #(0x1 <<  1)
    orr     x0, x0, #(0x1 <<  3)
    msr     sctlr_el3, x0
    isb

    /* clear bss section */
    mov     w0, #0x0
    ldr     x1, =__BSS_START__
    ldr     x2, =__BSS_SIZE__
bss_loop:
    subs    x2, x2, #4
    bcc     bss_end
    str     w0, [x1, x2]
    b       bss_loop
bss_end:

    /* Jump to Main */
    bl      main

1:
    b       1b

    .end
