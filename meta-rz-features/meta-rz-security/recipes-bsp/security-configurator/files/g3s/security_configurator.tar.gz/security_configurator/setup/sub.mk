
SOURCES		+=	./setup/setup.c			\
				./setup/otpauthid.c		\
				./setup/otpsecbten.c	\
				./setup/otpjam.c		\
				./setup/otpotren.c		\
				./setup/otpsecbtmode.c	\
				./setup/otparb.c		\
				./setup/otpacc.c 		\
				./setup/otpacdis.c		\
				./setup/otptacdis.c		\
				./setup/otprsiphuk.c	\
				./setup/rotpkhash.c		\
				./setup/decryptkey0.c	\
				./setup/decryptkey1.c 	\
				./setup/decryptkey2.c 	\
				./setup/decryptkey3.c	\
				./setup/keyupdatekey.c

MKFILE		+=	./setup/sub.mk
			
