# source file
SOURCES		= ./common/main.c		\
			  ./common/altlib.c		\
			  ./common/console.c	\
			  ./common/debug.c		\
			  ./common/message.c

MKFILE		+=	./common/sub.mk
