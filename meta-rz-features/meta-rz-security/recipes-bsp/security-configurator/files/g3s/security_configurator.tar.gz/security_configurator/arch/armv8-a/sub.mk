
ASSEMBLY	+=	./arch/armv8-a/boot_mon.s 	\
				./arch/armv8-a/stack.s		\
				./arch/armv8-a/incbin.s

LD_TEMPLATE	+= ./arch/armv8-a/linker_script.s

MKFILE		+=	./arch/armv8-a/sub.mk
