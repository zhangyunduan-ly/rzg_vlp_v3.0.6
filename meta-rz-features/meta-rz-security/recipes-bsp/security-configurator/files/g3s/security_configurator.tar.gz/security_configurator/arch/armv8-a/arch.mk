
# compile options
CPU			:= -march=armv8-a
CFLAGS		:= -mgeneral-regs-only -mstrict-align -ffunction-sections -fdata-sections \
			   -ffreestanding -fno-builtin -fno-common -O3 -fno-plt -fno-pic -std=gnu99 \
			   -fno-stack-protector

ifeq ($(DEBUG), 1)
CFLAGS		+= -Og -g
endif

# assembler options
ASFLAGS		:= -x assembler-with-cpp -DASSEMBLY $(CFLAGS)

# linker options
LDFLAGS		:= -nostdlib --gc-sections
LIBRARY		:= lib/libr_secure_ip_3_0.a.1.0.0

CROSS_COMPILE ?= aarch64-none-elf-
