/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : rz_soc_def.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>
#include <stdbool.h>

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef RZ_SOC_DEF_H
#define RZ_SOC_DEF_H

#if defined(CA55)
#define RZG3S_OTP_API_BASE              (0x00003000)
#define RZG3S_BOOT_INFO_BASE            (0x000A0000)
#define RZG3S_SCIF_0_BASE               (0x1004B800)
#define RZG3S_XSPI_BASE                 (0x10060000)
#define RZG3S_OCTA_BASE                 (0x10080000)
#define RZG3S_SYC_BASE                  (0x11000000)
#define RZG3S_CPG_BASE                  (0x11010000)
#define RZG3S_SYS_BASE                  (0x11020000)
#define RZG3S_GPIO_BASE                 (0x11030000)
#define RZG3S_RSIP_BASE                 (0x11850000)
#define RZG3S_OTP_BASE                  (0x11860000)
#define RZG3S_OSTM0_BASE                (0x12801000)
#define RZG3S_SPIROM_BASE               (0x20000000)

#define RZG3S_SYC_INCK_HZ               (24000000)
#define RZG3S_UART_INCK_HZ              (100000000)
#define RZG3S_UART_BARDRATE             (115200)
#define RZG3S_OSTM_INCK_HZ              (100000000)
#elif defined(CM33)
#define RZG3S_OTP_API_BASE              (0x00000080)
#define RZG3S_BOOT_INFO_BASE            (0x20020000)
#define RZG3S_SCIF_0_BASE               (0x4004B800)
#define RZG3S_XSPI_BASE                 (0x40060000)
#define RZG3S_OCTA_BASE                 (0x40080000)
#define RZG3S_SYC_BASE                  (0x41000000)
#define RZG3S_CPG_BASE                  (0x41010000)
#define RZG3S_SYS_BASE                  (0x41020000)
#define RZG3S_GPIO_BASE                 (0x41030000)
#define RZG3S_RSIP_BASE                 (0x41850000)
#define RZG3S_OTP_BASE                  (0x41860000)
#define RZG3S_OSTM0_BASE                (0x42801000)
#define RZG3S_SPIROM_BASE               (0x80000000)

#define RZG3S_SYC_INCK_HZ               (24000000)
#define RZG3S_UART_INCK_HZ              (100000000)
#define RZG3S_UART_BARDRATE             (115200)
#define RZG3S_OSTM_INCK_HZ              (100000000)
#endif

/* Definitions used in common code */

#define SYC_BASE                        (RZG3S_SYC_BASE)
#define SYS_BASE                        (RZG3S_SYS_BASE)
#define PFC_BASE                        (RZG3S_GPIO_BASE)
#define CPG_BASE                        (RZG3S_CPG_BASE)
#define SCIF_BASE                       (RZG3S_SCIF_0_BASE)
#define OSTM_BASE                       (RZG3S_OSTM0_BASE)
#define RSIP_BASE                       (RZG3S_RSIP_BASE)
#define OTP_BASE                        (RZG3S_OTP_BASE)

#define SYS_BASE_DEVID                  (SYS_LSI_DEVID)
#define ROM_API_OTP_BASE                (RZG3S_OTP_API_BASE)

#define UART_INCK_HZ                    (RZG3S_UART_INCK_HZ)
#define OSTM_INCK_HZ                    (RZG3S_OSTM_INCK_HZ)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* RZ_SOC_DEF_H */
