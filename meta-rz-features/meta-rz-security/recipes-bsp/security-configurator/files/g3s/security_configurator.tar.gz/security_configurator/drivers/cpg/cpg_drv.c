/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cpg_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "mmio.h"
#include "altlib.h"
#include "cpg_regs.h"
#include "drivers/cpg_drv.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define CPG_T_CLK                       (0)
#define CPG_T_RST                       (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/
typedef struct
{
    uintptr_t reg;
    uintptr_t mon;
    uint32_t val;
    uint32_t type;
} st_cpg_setup_data_t;

typedef struct
{
    uintptr_t reg;
    uint32_t val;
} st_cpg_reg_setting_t;

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

static const st_cpg_reg_setting_t s_cpg_early_div_tbl[] =
{
    { (uintptr_t)CPG_PL1_DDIV, 0x00010000 },  // 2'b00:1/1
};

static const st_cpg_setup_data_t s_cpg_early_clkrst_tbl[] =
{
    { (uintptr_t)CPG_CLKON_SYC, (uintptr_t)CPG_CLKMON_SYC, 0x00010001, CPG_T_CLK },
    { (uintptr_t)CPG_RST_SYC,   (uintptr_t)CPG_RSTMON_SYC, 0x00010001, CPG_T_RST },
};

static const st_cpg_setup_data_t s_cpg_static_clock_tbl[] =
{ };

static const st_cpg_reg_setting_t s_cpg_static_select_tbl[] =
{ };

static const st_cpg_reg_setting_t s_cpg_dynamic_select_tbl[] =
{ };

static const st_cpg_reg_setting_t s_cpg_dynamic_division_tbl[] =
{
    { (uintptr_t)CPG_PL2_DDIV, 0x00110000 },
    { (uintptr_t)CPG_PL3_DDIV, 0x01110000 },
};

static const st_cpg_setup_data_t s_cpg_iso_clock_tbl[] =
{ };

static const st_cpg_setup_data_t s_cpg_iso_reset_tbl[] =
{ };

static const st_cpg_setup_data_t s_cpg_awo_clock_tbl[] =
{
    /* GTM(OSTM) */
    { (uintptr_t)CPG_CLKON_GTM,  (uintptr_t)CPG_CLKMON_GTM,  0x00FF0001, CPG_T_CLK },
    /* SCIF */
    { (uintptr_t)CPG_CLKON_SCIF, (uintptr_t)CPG_CLKMON_SCIF, 0x003F0001, CPG_T_CLK },
};

static const st_cpg_setup_data_t s_cpg_awo_reset_tbl[] =
{
    /* GTM(OSTM) */
    { (uintptr_t)CPG_RST_GTM,  (uintptr_t)CPG_RSTMON_GTM,  0x00FF0001, CPG_T_RST },
    /* SCIF */
    { (uintptr_t)CPG_RST_SCIF, (uintptr_t)CPG_RSTMON_SCIF, 0x003F0001, CPG_T_RST },
};

/**********************************************************************************************************************
 * Function Name: cpg_sel_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_sel_setup(const st_cpg_reg_setting_t *tbl, const uint32_t size)
{
    int32_t cnt;

    while (mmio_read_32 (CPG_CLKSELSTATUS) != 0)
    {
        ;
    }

    for (cnt = 0; cnt < size; cnt++, tbl++)
    {
        mmio_write_32 (tbl->reg, tbl->val);
    }

    /* Wait for completion of settings */
    while (mmio_read_32 (CPG_CLKSELSTATUS) != 0)
    {
        ;
    }
}
/**********************************************************************************************************************
 * End of function cpg_sel_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_setup(const st_cpg_reg_setting_t *tbl, const uint32_t size)
{
    int32_t cnt;

    while (mmio_read_32 (CPG_CLKDIVSTATUS) != 0)
    {
        ;
    }

    for (cnt = 0; cnt < size; cnt++, tbl++)
    {
        mmio_write_32 (tbl->reg, tbl->val);
    }

    /* Wait for completion of settings */
    while (mmio_read_32 (CPG_CLKDIVSTATUS) != 0)
    {
        ;
    }
}
/**********************************************************************************************************************
 * End of function cpg_div_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_clkrst_stop
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_clkrst_stop(const st_cpg_setup_data_t *tbl, const uint32_t size)
{
    int32_t cnt;
    uint32_t mask;
    uint32_t cmp;

    for (cnt = 0; cnt < size; cnt++, tbl++)
    {
        mmio_write_32 (tbl->reg, tbl->val & 0xFFFF0000);

        mask = (tbl->val >> 16) & 0xFFFF;
        cmp = 0;
        if (CPG_T_RST == tbl->type)
        {
            cmp = ~(cmp);
        }
        while ((mmio_read_32 (tbl->mon) & mask) != (cmp & mask))
        {
            ;
        }
    }
}
/**********************************************************************************************************************
 * End of function cpg_clkrst_stop
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_clkrst_start
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_clkrst_start(const st_cpg_setup_data_t *tbl, const uint32_t size)
{
    int32_t cnt;
    uint32_t mask;
    uint32_t cmp;

    for (cnt = 0; cnt < size; cnt++, tbl++)
    {
        mmio_write_32 (tbl->reg, tbl->val);

        mask = (tbl->val >> 16) & 0xFFFF;
        cmp = tbl->val & 0xFFFF;
        if (CPG_T_RST == tbl->type)
        {
            cmp = ~(cmp);
        }
        while ((mmio_read_32 (tbl->mon) & mask) != (cmp & mask))
        {
            ;
        }
    }
}
/**********************************************************************************************************************
 * End of function cpg_clkrst_start
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_sel_static_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_sel_static_setup(void)
{
    cpg_clkrst_stop (s_cpg_static_clock_tbl, ARRAY_SIZE(s_cpg_static_clock_tbl));
    cpg_sel_setup (s_cpg_static_select_tbl, ARRAY_SIZE(s_cpg_static_select_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_div_sel_static_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_sel_dynamic_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_sel_dynamic_setup(void)
{
    cpg_sel_setup (s_cpg_dynamic_select_tbl, ARRAY_SIZE(s_cpg_dynamic_select_tbl));
    cpg_div_setup (s_cpg_dynamic_division_tbl, ARRAY_SIZE(s_cpg_dynamic_division_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_div_sel_dynamic_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_clock_on_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_clock_on_setup(void)
{
    cpg_clkrst_start (s_cpg_iso_clock_tbl, ARRAY_SIZE(s_cpg_iso_clock_tbl));
    cpg_clkrst_start (s_cpg_awo_clock_tbl, ARRAY_SIZE(s_cpg_awo_clock_tbl));

    cpg_clkrst_start (s_cpg_iso_reset_tbl, ARRAY_SIZE(s_cpg_iso_reset_tbl));
    cpg_clkrst_start (s_cpg_awo_reset_tbl, ARRAY_SIZE(s_cpg_awo_reset_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_clock_on_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_early_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_early_setup(void)
{
    cpg_div_setup (s_cpg_early_div_tbl, ARRAY_SIZE(s_cpg_early_div_tbl));
    cpg_clkrst_start (s_cpg_early_clkrst_tbl, ARRAY_SIZE(s_cpg_early_clkrst_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_early_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_setup(void)
{
    cpg_div_sel_static_setup ();
    cpg_clock_on_setup ();
    cpg_div_sel_dynamic_setup ();
}
/**********************************************************************************************************************
 * End of function cpg_setup
 *********************************************************************************************************************/
