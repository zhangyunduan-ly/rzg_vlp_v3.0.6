/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : keyupdatekey.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "altlib.h"
#include "debug.h"
#include "incbin.h"
#include "setup.h"
#include "drivers/sce_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define TMP_ENC_KUK_SIZE  (12)
#define WRAPPED_KUK_SIZE  (16)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_inst_data[WRAPPED_KUK_SIZE];

/**********************************************************************************************************************
 * Function Name: print_kuk
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void print_kuk(uint32_t *data, uint32_t size)
{
    put_str ("", 1);
    put_str ("Wrapped KUK : ", 0);

    for (int32_t i = 0; i < size; i++)
    {
        int8_t str[9];
        hex_to_ascii (bswap32 (data[i]), str, 1);
        put_str (str, 0);
    }
    put_str ("", 1);

    return;
}
/**********************************************************************************************************************
 * End of function print_kuk
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    int32_t err;

    memset ((uint8_t*) s_inst_data, 0, sizeof(s_inst_data));

#if defined(CFG_ENC_USER_KUK_FILE)
    ASSERT(0 < (uint32_t)g_sizeof_enc_inst_kuk);

    err = sce_install_kuk(g_enc_inst_kuk, s_inst_data);
    switch (err)
    {
        case 0:
            print_kuk(s_inst_data, ARRAY_SIZE(s_inst_data));
            break;

        case -2:
            put_str(" error: Failed to re-encrypt CFG_ENC_USER_KUK_FILE. The install data is cleared.", 1);
            memset((uint8_t *)s_inst_data, 0, sizeof(s_inst_data));
            break;

        default: /* -1 */
            put_str(" assert: Resource conflict occurs in SCE.", 1);
            ASSERT(0);
            break;
    }
#endif
    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t **data, uint32_t *size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = 0;

    if (0 == mode)
    {
        *data = &s_inst_data[0];
        *size = ARRAY_SIZE(s_inst_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t *data, uint32_t size)
{
    int32_t err = sce_install_kuk (data, s_inst_data);

    switch (err)
    {
        case 0:
            print_kuk(s_inst_data, ARRAY_SIZE(s_inst_data));
        break;

        case -2:
            put_str (" error: Failed to re-encrypt the key update key.", 1);
            put_str ("        The install data is cleared.", 1);
            memset ((uint8_t*) s_inst_data, 0, sizeof(s_inst_data));
        break;

        default: /* -1 */
            put_str (" assert: Resource conflict occurs in SCE.", 1);
            ASSERT(0);
        break;
    }

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t *info)
{
    info->bin.size = TMP_ENC_KUK_SIZE;

    info->bin.p_sentence = "Require the Encrypted Key Update Key (48 bytes)";

    return BIN;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: keyupdatekey
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void keyupdatekey(st_setup_exec_t *exec)
{
    exec->p_name = "KEYUPDATEKEY";
    exec->p_init = init;
    exec->p_save = 0;
    exec->p_ref = ref;
    exec->p_set = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function keyupdatekey
 *********************************************************************************************************************/
