/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021-2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : linker_script.s
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

MEMORY {
	CERT (rwxa): ORIGIN = 0x000A1E00, LENGTH = 0x00000200
	RAM  (rwxa): ORIGIN = 0x000A3000, LENGTH = 0x0001D000
}

SECTIONS
{
	.cert : {
		. = 0x00000000;
		LONG(__LOAD_SIZE__)
		FILL(0xFF)
		. = 0x00000010;
		LONG(__LOAD_ADDR__)
		FILL(0xFF)
		. = 0x00000020;
		LONG(__DEST_ADDR__)
		FILL(0xFF)
		. = 0x000001FC;
		LONG(0xAA55FFFF)
	} > CERT

	.text : {
		__RO_START__ = .;
		*(.text .text.*)
		*(.rodata .rodata.*)
		. = NEXT(64);
		__RO_END__ = .;
	} > RAM

	.data : {
		__DATA_START__ = .;
		 *(.data .data.*)
		. = NEXT(64);
		__DATA_END__ = .;
	} > RAM

	__DATA_SIZE__ = SIZEOF(.data);

	__LOAD_ADDR__ = 0x00000200;
	__LOAD_SIZE__ = __DATA_END__ - __RO_START__;
	__DEST_ADDR__ = __RO_START__;

	.bss : {
		__BSS_START__ = .;
		 *(.bss .bss.*)
		 *(COMMON)
		 . = NEXT(64);
		__BSS_END__ = .;
	} > RAM

	stacks (NOLOAD) : ALIGN(64) {
		__STACKS_START__ = .;
		KEEP(*(writer_stack))
		__STACKS_END__ = .;
	} > RAM

	__BSS_SIZE__ = SIZEOF(.bss);
}
