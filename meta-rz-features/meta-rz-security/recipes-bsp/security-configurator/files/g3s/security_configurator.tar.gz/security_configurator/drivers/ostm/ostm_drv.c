/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : ostm_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "mmio.h"
#include "drivers/ostm_drv.h"

#include "ostm_regs.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OSTM_1MS_COUNT ((OSTM_INCK_HZ / 1000) + 1)       /* Counter value per 1ms */
#define OSTM_1US_OCUNT ((OSTM_INCK_HZ / 1000000) + 1)    /* Counter value per 1us */

#define OSTM_NOTIMEOUT (0)
#define OSTM_TIMEOUT   (1)
#define TIMEOUT_VALUE  (0)

/**********************************************************************************************************************
 Local Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ostm_start
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void ostm_start(uint32_t count)
{
    /* Timer stop */
    mmio_write_8 (OSTM_REG_TT, OSTM_TT);

    /* OSTM control register setting */
    mmio_write_8 (OSTM_REG_CTL, 0x0); /* Interval timer mode(down count),
     * Disables interrupt at counter operation start */
    /* OSTM compare register setting */
    mmio_write_32 (OSTM_REG_CMP, count);

    /* Timer start */
    mmio_write_8 (OSTM_REG_TS, OSTM_TS);

    /* Make sure the timer is working */
    while (0 == (mmio_read_8 (OSTM_REG_TE) & OSTM_TE))
    {
        ; /* Continue to Loop until enable */
    }

    /* Set TIMEOUT_VALUE to "OSTM compare register", during timer operation */
    mmio_write_32 (OSTM_REG_CMP, TIMEOUT_VALUE);
}
/**********************************************************************************************************************
 * End of function ostm_start
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ostm_is_timeout
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ostm_is_timeout(void)
{
    if (TIMEOUT_VALUE >= mmio_read_32 (OSTM_REG_CNT))
    {
        return OSTM_TIMEOUT;
    }
    else
    {
        return OSTM_NOTIMEOUT;
    }
}
/**********************************************************************************************************************
 * End of function ostm_is_timeout
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ostm_stop
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void ostm_stop(void)
{
    /* Timer stop */
    mmio_write_8 (OSTM_REG_TT, OSTM_TT);

    /* Make sure the timer is stopped */
    while (0 != (mmio_read_8 (OSTM_REG_TE) & OSTM_TE))
    {
        ; /* Continue to Loop until enable */
    }

    /* OSTM control register initialize */
    mmio_write_8 (OSTM_REG_CTL, 0x00);

    /* OSTM compare register initialize */
    mmio_write_32 (OSTM_REG_CMP, 0x00000000);
}
/**********************************************************************************************************************
 * End of function ostm_stop
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ostm_wait_ms
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void ostm_wait_ms(uint32_t x_ms)
{
    ostm_start (OSTM_1MS_COUNT * x_ms);
    while (OSTM_TIMEOUT != ostm_is_timeout ())
    {
        ; /* No operation */
    }
    ostm_stop ();
}
/**********************************************************************************************************************
 * End of function ostm_wait_ms
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ostm_wait_us
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void ostm_wait_us(uint32_t x_us)
{
    ostm_start (OSTM_1US_OCUNT * x_us);
    while (OSTM_TIMEOUT != ostm_is_timeout ())
    {
        ; /* No operation */
    }
    ostm_stop ();
}
/**********************************************************************************************************************
 * End of function ostm_wait_us
 *********************************************************************************************************************/
