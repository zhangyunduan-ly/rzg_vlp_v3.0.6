/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : devinit.c
 * Version      : 1.0
 * Description  : device initialization
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/devinit.h"
#include "include/rzg2l_def.h"
#include "include/drivers/cpg.h"
#include "include/drivers/pfc.h"
#include "include/drivers/cpudrv.h"
#include "include/drivers/syc.h"
#include "include/drivers/sysc.h"
#include "include/drivers/scif_init.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init_rzg2l
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
static void init_rzg2l(void)
{
    /* early setup Clock and Reset */
    cpg_early_setup();

    /* initialize SYC */
    syc_init(RZG2L_SYC_INCK_HZ);

    /* setup PFC */
    pfc_setup();

    /* setup Clock and Reset */
    cpg_setup();

    scif_init();

    udelay(100);
}
/**********************************************************************************************************************
 * End of function init_rzg2l
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: dev_init
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
void dev_init(void)
{
    init_rzg2l();
    return;
}
/**********************************************************************************************************************
 * End of function dev_init
 *********************************************************************************************************************/
