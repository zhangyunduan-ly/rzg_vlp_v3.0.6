
/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : setup.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/setup.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
const st_setup_t * gp_setup;

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static st_setup_t s_setup;

/**********************************************************************************************************************
 * Function Name: call_entry
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void call_entry(void (* p_entry)(st_setup_exec_t * exec))
{
    ASSERT(s_setup.num < ARRAY_SIZE(s_setup.exec));

    p_entry(&s_setup.exec[s_setup.num]);

    s_setup.num++;

    return;
}
/**********************************************************************************************************************
 * End of function call_entry
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: entry_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void entry_setup(void)
{
    memset((uint8_t *)&s_setup, 0, sizeof(s_setup));

    call_entry(otpsecid);
    call_entry(otpauthid);
    call_entry(otpsecbten);
    call_entry(otpjam);
    call_entry(otpotren);
    call_entry(otpsecbtmode);
    call_entry(otpwpauthid);
    call_entry(otpwpfunc);
    call_entry(otpacdis);
    call_entry(otptacdis);
    call_entry(secbtoption0);
    call_entry(secbtoption1);
    call_entry(rotpkhash);
    call_entry(decryptkey0);
    call_entry(decryptkey1);
    call_entry(decryptkey2);
    call_entry(decryptkey3);
    call_entry(keyupdatekey);

    return;
}
/**********************************************************************************************************************
 * End of function entry_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: setup_init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t setup_init(void)
{
    int32_t ret = SETUP_SUCCESS;

    entry_setup();

    gp_setup = &s_setup;

    for (int32_t i = 0; ((i < gp_setup->num) && (SETUP_SUCCESS == ret)); i++)
    {
        if (NULL != gp_setup->exec[i].p_init)
        {
            ret = gp_setup->exec[i].p_init();
        }
    }
    return ret;
}
/**********************************************************************************************************************
 * End of function setup_init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: setup_errstr
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
char_t* setup_errstr(int32_t errno)
{
    switch (errno)
    {
        case SETUP_SUCCESS:
            return "Success";
        case SETUP_PARAMETER_ERROR:
            return "Parameter Error";
        case SETUP_PROT_AREA_ACCESS:
            return "Protection Area";
        case SETUP_SINGLE_ERR_CORRECT:
            return "Single Error Correction";
        case SETUP_DOUBLE_ERR_DETECT:
            return "Double Error Detection";
        case SETUP_MISMATCH_WR_DATA:
            return "Mismatch of Write Data";
        case SETUP_ALREADY_WRITTEN:
            return "Already Written";
        case SETUP_REBOOT_REQUIRED:
            return "System Reboot Required";
        default:
            return "Unknown Error Code";
    }
}
/**********************************************************************************************************************
 * End of function setup_errstr
 *********************************************************************************************************************/
