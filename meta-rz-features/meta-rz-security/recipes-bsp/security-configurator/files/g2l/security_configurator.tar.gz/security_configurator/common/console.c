/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : console.c
 * Version      : 1.0
 * Description  : command line console
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/message.h"
#include "include/command.h"
#include "include/setup.h"
#include "include/drivers/sysc.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/
#define CMD_MAX_ARG_LENGTH  (64)

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static char_t s_arg_buff[CMD_MAX_ARG_LENGTH];

/**********************************************************************************************************************
 * Function Name: exec_cmd
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t exec_cmd(int8_t *str, const st_command_table_t *cmd_tbl)
{
    int32_t cmd_num;

    to_upper(str);

    for (cmd_num = 0; (cmd_num < cmd_tbl->number_of_commands); cmd_num++)
    {
        if (0 == str_cmp(str, cmd_tbl->p_command_list[cmd_num].p_command))
        {
            return (cmd_tbl->p_command_list[cmd_num].p_function());
        }
    }

    put_str("", 1);
    put_str(" Command '", 0);
    put_str(str, 0);
    put_str("' not found.", 1);
    put_str("", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function exec_cmd
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: console
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void console(void)
{
    const st_command_table_t * p_cmd_tbl = get_command_table();

    show_welcome_msg();

    if (setup_init() == SETUP_SUCCESS)
    {
        int32_t err = 0;

        do
        {
            size_t len = sizeof(s_arg_buff);

            put_str(">", 0);

            get_str(s_arg_buff, &len);

            if ((0 < len) && (INT_CODE != s_arg_buff[0]))
            {
                err = exec_cmd(s_arg_buff, p_cmd_tbl);
            }
        } while (0 <= err);
    }

    return;
}
/**********************************************************************************************************************
 * End of function console
 *********************************************************************************************************************/
