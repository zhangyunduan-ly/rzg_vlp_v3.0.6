/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : rzg2l_def.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

#ifndef RZG2L_DEF_H
#define RZG2L_DEF_H
/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#define RZG2L_SRAM_BASE             (0x00010000)
#define RZG2L_DEVICE_BASE           (0x10000000)
#define RZG2L_SCIF0_BASE            (0x1004B800)
#define RZG2L_SPIMULT_BASE          (0x10060000)
#define RZG2L_SPIMULT_WBUF_BASE     (0x10070000)
#define RZG2L_SYC_BASE              (0x11000000)
#define RZG2L_CPG_BASE              (0x11010000)
#define RZG2L_SYSC_BASE             (0x11020000)
#define RZG2L_GPIO_BASE             (0x11030000)
#define RZG2L_TZC_SPI_BASE          (0x11060000)
#define RZG2L_TZC_DDR_BASE          (0x11070000)
#define RZG2L_DDR_PHY_BASE          (0x11400000)
#define RZG2L_DDR_MEMC_BASE         (0x11410000)
#define RZG2L_GIC_BASE              (0x11900000)
#define RZG2L_SD0_BASE              (0x11C00000)
#define RZG2L_WDT_BASE              (0x12800800)
#define RZG2L_SPIROM_BASE           (0x20000000)
#define RZG2L_DDR1_BASE             (0x40000000)
#define RZG2L_DDR2_BASE             (0x80000000)
#define RZG2L_DDR3_BASE             (0x100000000)

#define RZG2L_GICD_BASE             (RZG2L_GIC_BASE)
#define RZG2L_GICR_BASE             (RZG2L_GIC_BASE + 0x00040000)

#define RZG2L_SRAM_SIZE             (0x00030000 - RZG2L_SRAM_BASE)
#define RZG2L_DEVICE_SIZE           (0x15000000 - RZG2L_DEVICE_BASE)
#define RZG2L_SPIROM_SIZE           (0x30000000 - RZG2L_SPIROM_BASE)
#define RZG2L_DDR1_SIZE             (RZG2L_DDR2_BASE - RZG2L_DDR1_BASE)
#define RZG2L_DDR2_SIZE             (RZG2L_DDR3_BASE - RZG2L_DDR2_BASE)

#define RZG2L_SPIROM_FIP_BASE       (RZG2L_SPIROM_BASE + 0x0001D200)
#define RZG2L_SPIROM_FIP_SIZE       (0x30000000 - RZG2L_SPIROM_FIP_BASE)

#define RZG2L_SYC_INCK_HZ           (24000000)
#define RZG2L_UART_INCK_HZ          (100000000)
#define RZG2L_UART_BARDRATE         (115200)

/* Boot Info base address */
#define RZG2L_BOOTINFO_BASE         (RZG2L_SRAM_BASE)

/* Base address where parameters to BL31 are stored */
#define PARAMS_BASE                 (RZG2L_SRAM_BASE + 0x0001F000)
#define PARAMS_SIZE                 (0x1000)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* RZG2L_DEF_H */
