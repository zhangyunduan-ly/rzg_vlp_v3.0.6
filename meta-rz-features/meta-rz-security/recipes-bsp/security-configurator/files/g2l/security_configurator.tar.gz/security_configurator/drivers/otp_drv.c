/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpd_rv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/drivers/otp_drv.h"

#include "otp/otp_sys.h"
#include "otp/otp_iodefine.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_MAP_BASE    (0x11861000)
#define OTP_MAP_AREA    (0x800)
#define OTP_REG_SIZE    (0x4)

/**********************************************************************************************************************
 Local Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: get_otp_offset
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int64_t get_otp_offset(const e_otp_symbol_t symbol, uint32_t size)
{
    int64_t offset = -1;

    uint32_t map_len  = 0;
    uint64_t map_addr = 0;

    switch (symbol)
    {
        case OTP_SYM_AUTHID:
            map_len  = sizeof(OTP.OTPAUTHID);
            map_addr = (uint64_t) &OTP.OTPAUTHID;
            break;
        case OTP_SYM_SECBTEN:
            map_len  = sizeof(OTP.OTPSECBTEN);
            map_addr = (uint64_t) &OTP.OTPSECBTEN;
            break;
        case OTP_SYM_JAM:
            map_len  = sizeof(OTP.OTPJAM);
            map_addr = (uint64_t) &OTP.OTPJAM;
            break;
        case OTP_SYM_OTREN:
            map_len  = sizeof(OTP.OTPOTREN);
            map_addr = (uint64_t) &OTP.OTPOTREN;
            break;
        case OTP_SYM_SECBTMODE:
            map_len  = sizeof(OTP.OTPSECBTMODE);
            map_addr = (uint64_t) &OTP.OTPSECBTMODE;
            break;
        case OTP_SYM_WPAUTHID:
            map_len  = sizeof(OTP.OTPWPAUTHID);
            map_addr = (uint64_t) &OTP.OTPWPAUTHID;
            break;
        case OTP_SYM_WPFUNC:
            map_len  = sizeof(OTP.OTPWPFUNC);
            map_addr = (uint64_t) &OTP.OTPWPFUNC;
            break;
        case OTP_SYM_ACDIS:
            map_len  = sizeof(OTP.OTPACDIS);
            map_addr = (uint64_t) &OTP.OTPACDIS;
            break;
        case OTP_SYM_TACDIS:
            map_len  = sizeof(OTP.OTPTACDIS);
            map_addr = (uint64_t) &OTP.OTPTACDIS;
            break;
        case OTP_SYM_SECBTOPTION0:
            map_len  = sizeof(OTP.SECBTOPTION0);
            map_addr = (uint64_t) &OTP.SECBTOPTION0;
            break;
        case OTP_SYM_SECBTOPTION1:
            map_len  = sizeof(OTP.SECBTOPTION1);
            map_addr = (uint64_t) &OTP.SECBTOPTION1;
            break;
        case OTP_SYM_ROTPKHASH:
            map_len  = sizeof(OTP.ROTPKHASH);
            map_addr = (uint64_t) &OTP.ROTPKHASH;
            break;
        case OTP_SYM_DECRYPTKEY0:
            map_len  = sizeof(OTP.DECRYPTKEY0);
            map_addr = (uint64_t) &OTP.DECRYPTKEY0;
            break;
        case OTP_SYM_DECRYPTKEY1:
            map_len  = sizeof(OTP.DECRYPTKEY1);
            map_addr = (uint64_t) &OTP.DECRYPTKEY1;
            break;
        case OTP_SYM_DECRYPTKEY2:
            map_len  = sizeof(OTP.DECRYPTKEY2);
            map_addr = (uint64_t) &OTP.DECRYPTKEY2;
            break;
        case OTP_SYM_DECRYPTKEY3:
            map_len  = sizeof(OTP.DECRYPTKEY3);
            map_addr = (uint64_t) &OTP.DECRYPTKEY3;
            break;
        default:
            break;
    }

    if ((size * OTP_REG_SIZE) == map_len)
    {
        offset = map_addr - OTP_MAP_BASE;
    }

    return offset;
}
/**********************************************************************************************************************
 * End of function get_otp_offset
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otp_load
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2 or -3 or -4
 *********************************************************************************************************************/
int32_t otp_load(const e_otp_symbol_t symbol, uint32_t * data, uint32_t size)
{
    int32_t ret_val;

    int64_t offset = get_otp_offset(symbol, size);

    ret_val = otp_open ();

    if (0 == ret_val)
    {
        for (int32_t i = 0; ((i < size) && (0 == ret_val)); i++)
        {
            ret_val = otp_read (offset + (i * OTP_REG_SIZE), &data[i]);
        }

        otp_close ();
    }

    return ret_val;
}
/**********************************************************************************************************************
 * End of function otp_load
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otp_save
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2 or -3 or -4 or -5
 *********************************************************************************************************************/
int32_t otp_save(const e_otp_symbol_t symbol, const uint32_t * data, uint32_t size)
{
    int32_t ret_val;

    int64_t offset = get_otp_offset(symbol, size);

    ret_val = otp_open ();

    if (0 == ret_val)
    {
        for (int32_t i = 0; ((i < size) && (0 == ret_val)); i++)
        {
            ret_val = otp_write (offset + (i * OTP_REG_SIZE), data[i]);
        }

        otp_close ();
    }

    return ret_val;
}
/**********************************************************************************************************************
 * End of function otp_save
 *********************************************************************************************************************/
