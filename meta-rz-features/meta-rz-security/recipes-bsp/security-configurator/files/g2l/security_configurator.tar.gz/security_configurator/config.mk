
# if "y", SEC ID write function is enabled.
# Note: When this software is launched for the first time on the target device,
#       SEC ID write process is automatically executed.
CFG_OTP_SEC_ID = y

# If y, the authentication ID write function is enabled.
CFG_OTP_AUTH_ID = y

# If y, the encryption key write function is enabled.
CFG_OTP_ENC_USER_KEY = y

# If y, the write value is set to "Enable Secure Boot".
CFG_OTP_SECBT_EN = y

# If none, the write data is set to "Normal Connection".
# If secip, the write data is set to "Authentication Connection".
# If reject, the write data is set to "Connection Rejection".
CFG_OTP_AUTH_MD = none

# The OTP user area has an area with a one-time read function.
# That area is 512 bytes in size and is divided into 64 bytes.
# OTR activation can be set for each of these divided areas.
# if y, the write data is set to "OTR Activation".
CFG_OTP_OTR_EN_0 = n
CFG_OTP_OTR_EN_1 = n
CFG_OTP_OTR_EN_2 = n
CFG_OTP_OTR_EN_3 = n
CFG_OTP_OTR_EN_4 = n
CFG_OTP_OTR_EN_5 = n
CFG_OTP_OTR_EN_6 = n
CFG_OTP_OTR_EN_7 = n

# This is specified to disable each boot device when secure boot is enabled.
# if y, the write data is set to "Disable Secure Boot".
CFG_OTP_SB_DIS_SD = n
CFG_OTP_SB_DIS_EMMC18 = n
CFG_OTP_SB_DIS_EMMC33 = n
CFG_OTP_SB_DIS_SPI18 = n
CFG_OTP_SB_DIS_SPI33 = n
CFG_OTP_SB_DIS_SCIF = n

# This is write protection for the authentication ID area.
# if y, the write data is set to "Enable write protection".
CFG_OTP_WP_AUTH_ID = n

# This is write protection for the function settings area.
# if y, the write data is set to "Enable write protection".
CFG_OTP_WP_FUNC = n

CFG_OTP_RAC_DIS = n
CFG_OTP_TAC_DIS = n

# This is a config to disable failsafe mode when secure boot fails.
# if y, the write data is set to "Disable failsafe".
CFG_OTP_FAIL_SAFE_DIS = n

CFG_WRAPPED_UFPK_FILE  = ./install/wrapped-ufpk.bin
CFG_UFPK_ENC_IV0_FILE  = ./install/ufpk_init_vec.bin

CFG_ROT_PK_HASH_FILE   = 
CFG_ENC_AUTH_DATA_FILE = 
CFG_ENC_USER_KEY0_FILE = 
CFG_ENC_USER_KEY1_FILE = 
CFG_ENC_USER_KEY2_FILE = 
CFG_ENC_USER_KEY3_FILE = 

CFG_ENC_USER_KUK_FILE =
