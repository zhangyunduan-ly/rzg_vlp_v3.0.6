/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cpudrv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/bit.h"
#include "include/drivers/cpg_regs.h"
#include "include/drivers/ostm_regs.h"
#include "include/drivers/cpudrv.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: power_on_tmu0
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void power_on_tmu0(void)
{
    uint32_t dataL;

    dataL =  (*(volatile uint32_t *)CPG_CLKON_OSTM);
    dataL |= 0x00010001U;

    (*(volatile uint32_t *)CPG_CLKON_OSTM) = dataL;

    do
    {
        dataL = (*(volatile uint32_t *)CPG_CLKMON_OSTM);
    }
    while ((dataL & BIT0) == 0U); /* wait until bit0=1 */

    dataL =  (*(volatile uint32_t *)CPG_RST_OSTM);
    dataL |= 0x00010001U;

    *((volatile uint32_t*)CPG_RST_OSTM) = dataL;
    do
    {
        dataL = (*(volatile uint32_t *)CPG_RSTMON_OSTM);
    }
    while ((dataL & BIT0) == 1U); /* wait until bit0=1 */
}
/**********************************************************************************************************************
 * End of function power_on_tmu0
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: start_tmu0_msec
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void start_tmu0_msec(uint32_t tenmSec)
{
    uint32_t dataL;

    power_on_tmu0();

    *((volatile uint8_t *)OSTM0CTL)  = 0x00U;        /* Interval Timer Mode */

    *((volatile uint32_t *)OSTM0CMP) = 100000U * tenmSec;    /* (100MHz)*100000=1000us */

    (*(volatile uint8_t *)OSTM0TS) |= BIT0;          /* TMU0 Start */

    do
    {
        dataL = (*(volatile uint8_t *)OSTM0CNT);
    }
    while (0x0U != dataL);

    (*(volatile uint8_t *)OSTM0TT) |= BIT0;          /* TMU0 Stop */
}
/**********************************************************************************************************************
 * End of function start_tmu0_msec
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: start_tmu0_usec
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void start_tmu0_usec(uint32_t tenuSec)
{
    uint32_t dataL;

    power_on_tmu0();

    *((volatile uint8_t *)OSTM0CTL)  = 0x00U;        /* Interval Timer Mode */

    *((volatile uint32_t *)OSTM0CMP) = 100U * tenuSec;   /* (100MHz)*100=1.0us */

    (*(volatile uint8_t *)OSTM0TS) |= BIT0;          /* TMU0 Start */

    do
    {
        dataL = (*(volatile uint8_t *)OSTM0CNT);
    }
    while (0x0U != dataL);

    (*(volatile uint8_t *)OSTM0TT) |= BIT0;          /* TMU0 Stop */
}
/**********************************************************************************************************************
 * End of function start_tmu0_usec
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: udelay
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void udelay(uint32_t count_us)
{
    start_tmu0_usec(count_us);
}
/**********************************************************************************************************************
 * End of function udelay
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: mdelay
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void mdelay(uint32_t count_us)
{
    start_tmu0_msec(count_us);
}
/**********************************************************************************************************************
 * End of function mdelay
 *********************************************************************************************************************/
