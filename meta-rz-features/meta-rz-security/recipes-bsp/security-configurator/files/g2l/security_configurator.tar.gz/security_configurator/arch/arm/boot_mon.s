/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : boot_mon.s
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/*
  W0-W30 : 32bit Register (W30=Link Register)
  X0-X30 : 64bit Register (X30=Link Register)
  WZR    : 32bit Zero Register
  XZR    : 64bit Zero Register
  WSP    : 32bit Stack Pointer
  SP     : 64bit Stack Pointer
*/

    .align    4

    .global start
start:

// Initialize register
    LDR     X0, =0
    LDR     X1, =0
    LDR     X2, =0
    LDR     X3, =0
    LDR     X4, =0
    LDR     X5, =0
    LDR     X6, =0
    LDR     X7, =0
    LDR     X8, =0
    LDR     X9, =0
    LDR     X10, =0
    LDR     X11, =0
    LDR     X12, =0
    LDR     X13, =0
    LDR     X14, =0
    LDR     X15, =0
    LDR     X16, =0
    LDR     X17, =0
    LDR     X18, =0
    LDR     X19, =0
    LDR     X20, =0
    LDR     X21, =0
    LDR     X22, =0
    LDR     X23, =0
    LDR     X24, =0
    LDR     X25, =0
    LDR     X26, =0
    LDR     X27, =0
    LDR     X28, =0
    LDR     X29, =0
    LDR     X30, =0

// Set Stack Pointer
    LDR     x0, =__STACKS_END__
    MSR     SP_EL0,x0
    MSR     SP_EL1,x0
    MSR     SP_EL2,x0
    MOV     sp,x0
    MSR     ELR_EL1,x0
    MSR     ELR_EL2,x0
    MSR     ELR_EL3,x0
    MSR     SPSR_EL1,x0
    MSR     SPSR_EL2,x0
    MSR     SPSR_EL3,x0

// Enable cache
    mrs     x0, sctlr_el3
    orr     x0, x0, #(0x1 << 12)
    orr     x0, x0, #(0x1 <<  1)
    orr     x0, x0, #(0x1 <<  3)
    msr     sctlr_el3, x0
    isb

    /* clear bss section */
    mov     W0, #0x0
    ldr     X1, =__BSS_START__
    ldr     X2, =__BSS_SIZE__
bss_loop:
    subs    X2, X2, #4
    bcc     bss_end
    str     W0, [X1, X2]
    b       bss_loop
bss_end:

// Jump to Main
    BL      main

1:
    B       1b

    .end
