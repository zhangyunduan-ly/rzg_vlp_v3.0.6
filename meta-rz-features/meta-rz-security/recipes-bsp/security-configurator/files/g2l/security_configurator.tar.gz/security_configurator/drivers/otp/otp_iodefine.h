/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020-2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otp_iodefine.h
 * Version      : 1.0
 * Description  : IO define header.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef OTP_IODEFINE_H
#define OTP_IODEFINE_H

#define OTP (*(volatile struct st_otp *) 0x11860000)

#ifdef RZG2UL
#define OTP_USER_AREA_OTR_SIZE (128 / sizeof(uint32_t))
#else
#define OTP_USER_AREA_OTR_SIZE (512 / sizeof(uint32_t))
#endif

#define	OTP_OTPPWR_PWR	(1 << 0)
#define	OTP_OTPPWR_ACCL	(1 << 4)
#define	OTP_OTPPWR_MASK	(0x00000011)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/
struct st_otp
{
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    PWR:1;
            uint32_t    :3;
            uint32_t    ACCL:1;
            uint32_t    :27;
        } BIT;
    } OTPPWR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    CMD_RDY:1;
            uint32_t    ERR_WR:2;
            uint32_t    ERR_WP:1;
            uint32_t    ERR_RP:1;
            uint32_t    :3;
            uint32_t    ERR_RDY_WR:1;
            uint32_t    ERR_RDY_RD:1;
            uint32_t    :22;
        } BIT;
    } OTPSTR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    STAWR:1;
            uint32_t    :31;
        } BIT;
    } OTPSTAWR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    ADRWR:9;
            uint32_t    :23;
        } BIT;
    } OTPADRWR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    DATAWR:32;
        } BIT;
    } OTPDATAWR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    ADRRD:9;
            uint32_t    :23;
        } BIT;
    } OTPADRRD;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    DATARD:32;
        } BIT;
    } OTPDATARD;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    OTPFLAG:1;
            uint32_t    :31;
        } BIT;
    } OTPFLAG;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SECINTEN:1;
            uint32_t    DEDINTEN:1;
            uint32_t    :30;
        } BIT;
    } OTPINTEN;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SECINTSTS:1;
            uint32_t    DEDINTSTS:1;
            uint32_t    :30;
        } BIT;
    } OTPINTSTS;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SECADDR:9;
            uint32_t    :23;
        } BIT;
    } OTPSECADDR;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    DEDADDR:9;
            uint32_t    :23;
        } BIT;
    } OTPDEDADDR;
    uint8_t         wk0[4304];
    uint8_t         wk1[4];
    uint8_t         wk2[4];
    uint8_t         wk3[4];
    uint8_t         wk4[4];
    uint8_t         wk5[4];
    uint8_t         wk6[4];
    uint8_t         wk7[4];
    uint8_t         wk8[4];
    uint8_t         wk9[4];
    uint8_t         wk10[4];
    uint8_t         wk11[4];
    uint8_t         wk12[4];
    uint8_t         wk13[4];
    uint8_t         wk14[4];
    uint8_t         wk15[4];
    uint8_t         wk16[4];
    uint8_t         wk17[4];
    uint8_t         wk18[4];
    uint8_t         wk19[4];
    uint8_t         wk20[4];
    uint8_t         wk21[4];
    uint8_t         wk22[4];
    uint8_t         wk23[4];
    uint8_t         wk24[4];
    uint8_t         wk25[4];
    uint8_t         wk26[4];
    uint8_t         wk27[4];
    uint8_t         wk28[4];
    uint8_t         wk29[4];
    uint8_t         wk30[4];
    uint8_t         wk31[4];
    uint8_t         wk32[4];
    uint8_t         wk33[16];
    union
    {
        uint32_t    WORD[4];
    } OTPAUTHID;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SECBTEN:1;
            uint32_t    :31;
        } BIT;
    } OTPSECBTEN;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    JAM:2;
            uint32_t    :30;
        } BIT;
    } OTPJAM;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    OTREN_0:1;
            uint32_t    OTREN_1:1;
            uint32_t    OTREN_2:1;
            uint32_t    OTREN_3:1;
            uint32_t    OTREN_4:1;
            uint32_t    OTREN_5:1;
            uint32_t    OTREN_6:1;
            uint32_t    OTREN_7:1;
            uint32_t    :24;
        } BIT;
    } OTPOTREN;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SECBT_SD:1;
            uint32_t    SECBT_EMMC18:1;
            uint32_t    SECBT_EMMC33:1;
            uint32_t    SECBT_SPI18:1;
            uint32_t    SECBT_SPI33:1;
            uint32_t    :27;
        } BIT;
    } OTPSECBTMODE;
    uint8_t         wk34[4];
    uint8_t         wk35[4];
    uint8_t         wk36[4];
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    WPAUTHID:1;
            uint32_t    :31;
        } BIT;
    } OTPWPAUTHID;
    uint8_t         wk37[4];
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    WPFUNC:1;
            uint32_t    :31;
        } BIT;
    } OTPWPFUNC;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    ACDIS:1;
            uint32_t    :31;
        } BIT;
    } OTPACDIS;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    TACDIS:1;
            uint32_t    :31;
        } BIT;
    } OTPTACDIS;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    :32;
        } BIT;
    } OTPTMP0;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    :32;
        } BIT;
    } OTPTMP1;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    :32;
        } BIT;
    } OTPTMP2;
    uint8_t         wk38[36];
    uint32_t        USERAREAOTR[OTP_USER_AREA_OTR_SIZE];
    uint8_t         wk40[4];
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    :16;
            uint32_t    ANTIRB:1;
            uint32_t    :7;
            uint32_t    WOTPON:1;
            uint32_t    :7;
        } BIT;
    } SECBTOPTION0;
    union
    {
        uint32_t    WORD;
        struct
        {
            uint32_t    SCIFDL:1;
            uint32_t    :15;
            uint32_t    FLSFDL:1;
            uint32_t    :15;
        } BIT;
    } SECBTOPTION1;
    uint8_t         wk41[20];
    union
    {
        uint32_t    WORD[8];
    } ROTPKHASH;
    union
    {
        uint32_t    WORD[12];
    } DECRYPTKEY0;
    union
    {
        uint32_t    WORD[12];
    } DECRYPTKEY1;
    union
    {
        uint32_t    WORD[12];
    } DECRYPTKEY2;
    union
    {
        uint32_t    WORD[12];
    } DECRYPTKEY3;
    union
    {
        uint32_t    WORD[32];
    } ANTI_RB_VER;
};

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* OTP_IODEFINE_H */
