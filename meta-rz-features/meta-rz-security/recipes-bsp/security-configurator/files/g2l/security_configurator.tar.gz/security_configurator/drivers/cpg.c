/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cpg.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/drivers/cpg_regs.h"
#include "include/drivers/cpg.h"
#include "include/drivers/cpudrv.h"
#include "include/drivers/mmio.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define CPG_OFF         (0)
#define CPG_ON          (1)

#define CPG_T_CLK       (0)
#define CPG_T_RST       (1)

#define CPG_PLL2_INDEX                  (0)
#define CPG_PLL3_INDEX                  (1)
#define CPG_PLL5_INDEX                  (2)

#define CPG_SEL_PLL1_ON_OFF             (0)
#define CPG_SEL_PLL2_1_ON_OFF           (1)
#define CPG_SEL_PLL2_2_ON_OFF           (2)
#define CPG_SEL_PLL3_1_ON_OFF           (3)
#define CPG_SEL_PLL3_2_ON_OFF           (4)
#define CPG_SEL_PLL3_3_ON_OFF           (5)
#define CPG_SEL_PLL5_1_ON_OFF           (6)
#define CPG_SEL_PLL5_3_ON_OFF           (7)
#define CPG_SEL_PLL5_4_ON_OFF           (8)
#define CPG_SEL_PLL6_1_ON_OFF           (9)
#define CPG_SEL_GPU1_1_ON_OFF           (10)
#define CPG_SEL_GPU1_2_ON_OFF           (11)
#define CPG_SEL_GPU2_ON_OFF             (12)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/
typedef struct {
    uintptr_t  reg;
    uintptr_t  mon;
    uint32_t   val;
    uint32_t   type;
} st_cpg_setup_data_t;

typedef struct {
    uintptr_t reg;
    uint32_t  val;
} st_cpg_reg_setting_t;

typedef struct {
    st_cpg_reg_setting_t     clk1_dat;
    st_cpg_reg_setting_t     clk2_dat;
    st_cpg_reg_setting_t     stby_dat;
} st_cpg_pll_setdata_146_t;

typedef struct {
    st_cpg_reg_setting_t     clk1_dat;
    st_cpg_reg_setting_t     clk2_dat;
    st_cpg_reg_setting_t     clk3_dat;
    st_cpg_reg_setting_t     clk4_dat;
    st_cpg_reg_setting_t     clk5_dat;
    st_cpg_reg_setting_t     stby_dat;
} st_cpg_pll_setdata_235_t;

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static st_cpg_pll_setdata_146_t s_cpg_pll4_setdata = {
#if (DDR4 == 1)
    { CPG_PLL4_CLK1, 0xFAE13203 },
    { CPG_PLL4_CLK2, 0x00081000 },
#else
    { CPG_PLL4_CLK1, 0xA66629C3 },
    { CPG_PLL4_CLK2, 0x00080D00 },
#endif
    { CPG_PLL4_STBY, 0x00010001 }
};

static st_cpg_pll_setdata_146_t s_cpg_pll6_setdata = {
    { CPG_PLL6_CLK1, 0x00003e83 },
    { CPG_PLL6_CLK2, 0x00082D02 },
    { CPG_PLL6_STBY, 0x00010001 }, /* SSC OFF */
};

static const st_cpg_setup_data_t s_early_setup_tbl[] = {
    {
        (uintptr_t)CPG_CLKON_SYC,
        (uintptr_t)CPG_CLKMON_SYC,
        0x00010001,
        CPG_T_CLK
    },
    {
        (uintptr_t)CPG_RST_SYC,
        (uintptr_t)CPG_RSTMON_SYC,
        0x00010001,
        CPG_T_RST
    }
};

static st_cpg_setup_data_t s_cpg_clk_on_tbl[] = {
    {       /* CM33 */
        (uintptr_t)CPG_CLKON_CM33,
        (uintptr_t)CPG_CLKMON_CM33,
        0x00030000,
        CPG_T_CLK
    },
    {       /* MHU */
        (uintptr_t)CPG_CLKON_MHU,
        (uintptr_t)CPG_CLKMON_MHU,
        0x00010000,
        CPG_T_CLK
    },
    {       /* DMAC */
        (uintptr_t)CPG_CLKON_DAMC_REG,
        (uintptr_t)CPG_CLKMON_DAMC_REG,
        0x00030003,
        CPG_T_CLK
    },
    {       /* OSTM */
        (uintptr_t)CPG_CLKON_OSTM,
        (uintptr_t)CPG_CLKMON_OSTM,
        0x00060000,
        CPG_T_CLK
    },
    {       /* MTU */
        (uintptr_t)CPG_CLKON_MTU,
        (uintptr_t)CPG_CLKMON_MTU,
        0x00010000,
        CPG_T_CLK
    },
    {       /* POE3 */
        (uintptr_t)CPG_CLKON_POE3,
        (uintptr_t)CPG_CLKMON_POE3,
        0x00010000,
        CPG_T_CLK
    },
#if !RZG2UL
    {       /* GPT */
        (uintptr_t)CPG_CLKON_GPT,
        (uintptr_t)CPG_CLKMON_GPT,
        0x00010000,
        CPG_T_CLK
    },
    {       /* POEG */
        (uintptr_t)CPG_CLKON_POEG,
        (uintptr_t)CPG_CLKMON_POEG,
        0x000F0000,
        CPG_T_CLK
    },
#endif
    {       /* WDT */
        (uintptr_t)CPG_CLKON_WDT,
        (uintptr_t)CPG_CLKMON_WDT,
#if RZG2UL
        0x00300000,
#else
        0x003C0000,
#endif
        CPG_T_CLK
    },
#if !DEBUG_RZG2L_FPGA
    {       /* DDR */
        (uintptr_t)CPG_CLKON_DDR,
        (uintptr_t)CPG_CLKMON_DDR,
        0x00030000,
        CPG_T_CLK
    },
#else
    {       /* DDR */
        (uintptr_t)CPG_CLKON_DDR,
        (uintptr_t)CPG_CLKMON_DDR,
        0x00030003,
        CPG_T_CLK
    },
#endif
    {       /* SPI_MULTI */
        (uintptr_t)CPG_CLKON_SPI_MULTI,
        (uintptr_t)CPG_CLKMON_SPI_MULTI,
        0x00030003,
        CPG_T_CLK
    },
    {       /* SDHI */
        (uintptr_t)CPG_CLKON_SDHI,
        (uintptr_t)CPG_CLKMON_SDHI,
        0x00ff00ff,
        CPG_T_CLK
    },
#if !RZG2UL
    {       /* GPU */
        (uintptr_t)CPG_CLKON_GPU,
        (uintptr_t)CPG_CLKMON_GPU,
        0x00070000,
        CPG_T_CLK
    },
#endif
    {       /* Image Scaling Unit */
        (uintptr_t)CPG_CLKON_ISU,
        (uintptr_t)CPG_CLKMON_ISU,
        0x00030000,
        CPG_T_CLK
    },
#if !RZG2UL
    {       /* H.264 codec */
        (uintptr_t)CPG_CLKON_H264,
        (uintptr_t)CPG_CLKMON_H264,
        0x00010001,
        CPG_T_CLK
    },
#endif
    {       /* Camera Data Receive Unit */
        (uintptr_t)CPG_CLKON_CRU,
        (uintptr_t)CPG_CLKMON_CRU,
        0x001f0000,
        CPG_T_CLK
    },
#if !RZG2UL
    {       /* MIPI-DSI */
        (uintptr_t)CPG_CLKON_MIPI_DSI,
        (uintptr_t)CPG_CLKMON_MIPI_DSI,
        0x003f0000,
        CPG_T_CLK
    },
#endif
    {       /* LCDC */
        (uintptr_t)CPG_CLKON_LCDC,
        (uintptr_t)CPG_CLKMON_LCDC,
        0x00030000,
        CPG_T_CLK
    },
    {       /* Serial Sound Interface */
        (uintptr_t)CPG_CLKON_SSI,
        (uintptr_t)CPG_CLKMON_SSI,
        0x00ff0000,
        CPG_T_CLK
    },
    {       /* Sampling Rate Converter */
        (uintptr_t)CPG_CLKON_SRC,
        (uintptr_t)CPG_CLKMON_SRC,
        0x00010000,
        CPG_T_CLK
    },
    {       /* USB2.0 */
        (uintptr_t)CPG_CLKON_USB,
        (uintptr_t)CPG_CLKMON_USB,
        0x000f0000,
        CPG_T_CLK
    },
    {       /* ETHER */
        (uintptr_t)CPG_CLKON_ETH,
        (uintptr_t)CPG_CLKMON_ETH,
        0x00030000,
        CPG_T_CLK
    },
    {       /* I2C */
        (uintptr_t)CPG_CLKON_I2C,
        (uintptr_t)CPG_CLKMON_I2C,
        0x000f0000,
        CPG_T_CLK
    },
    {       /* SCIF */
        (uintptr_t)CPG_CLKON_SCIF,
        (uintptr_t)CPG_CLKMON_SCIF,
        0x001f0001,
        CPG_T_CLK
    },
    {       /* SCI */
        (uintptr_t)CPG_CLKON_SCI,
        (uintptr_t)CPG_CLKMON_SCI,
        0x00030000,
        CPG_T_CLK
    },
    {       /* IrDA */
        (uintptr_t)CPG_CLKON_IRDA,
        (uintptr_t)CPG_CLKMON_IRDA,
        0x00010000,
        CPG_T_CLK
    },
    {       /* SPI */
        (uintptr_t)CPG_CLKON_RSPI,
        (uintptr_t)CPG_CLKMON_RSPI,
        0x00070000,
        CPG_T_CLK
    },
    {       /* CAN */
        (uintptr_t)CPG_CLKON_CANFD,
        (uintptr_t)CPG_CLKMON_CANFD,
        0x00010000,
        CPG_T_CLK
    },
    {       /* GPIO */
        (uintptr_t)CPG_CLKON_GPIO,
        (uintptr_t)CPG_CLKMON_GPIO,
        0x00010001,
        CPG_T_CLK
    },
    {       /* ADC */
        (uintptr_t)CPG_CLKON_ADC,
        (uintptr_t)CPG_CLKMON_ADC,
        0x00030000,
        CPG_T_CLK
    },
    {       /* Thermal Sensor Unit */
        (uintptr_t)CPG_CLKON_TSU,
        (uintptr_t)CPG_CLKMON_TSU,
        0x00010000,
        CPG_T_CLK
    }
};

static st_cpg_setup_data_t s_cpg_reset_tbl[] = {
    {       /* CM33 */
        (uintptr_t)CPG_RST_CM33,
        (uintptr_t)CPG_RSTMON_CM33,
        0x00070000,
        CPG_T_RST
    },
    {       /* MHU */
        (uintptr_t)CPG_RST_MHU,
        (uintptr_t)CPG_RSTMON_MHU,
        0x00010000,
        CPG_T_RST
    },
    {       /* DMAC */
        (uintptr_t)CPG_RST_DMAC,
        (uintptr_t)CPG_RSTMON_DMAC,
        0x00030003,
        CPG_T_RST
    },
    {       /* OSTM */
        (uintptr_t)CPG_RST_OSTM,
        (uintptr_t)CPG_RSTMON_OSTM,
        0x00060000,
        CPG_T_RST
    },
    {       /* MTU */
        (uintptr_t)CPG_RST_MTU,
        (uintptr_t)CPG_RSTMON_MTU,
        0x00010000,
        CPG_T_RST
    },
    {       /* POE3 */
        (uintptr_t)CPG_RST_POE3,
        (uintptr_t)CPG_RSTMON_POE3,
        0x00010000,
        CPG_T_RST
    },
#if !RZG2UL
    {       /* GPT */
        (uintptr_t)CPG_RST_GPT,
        (uintptr_t)CPG_RSTMON_GPT,
        0x00010000,
        CPG_T_RST
    },
    {       /* POEG */
        (uintptr_t)CPG_RST_POEG,
        (uintptr_t)CPG_RSTMON_POEG,
        0x000f0000,
        CPG_T_RST
    },
#endif
    {       /* WDT */
        (uintptr_t)CPG_RST_WDT,
        (uintptr_t)CPG_RSTMON_WDT,
#if RZG2UL
        0x00040000,
#else
        0x00060000,
#endif
        CPG_T_RST
    },
#if !DEBUG_RZG2L_FPGA
    {       /* DDR */
        (uintptr_t)CPG_RST_DDR,
        (uintptr_t)CPG_RSTMON_DDR,
        0x007F0000,
        CPG_T_RST
    },
#else
    {       /* DDR */
        (uintptr_t)CPG_RST_DDR,
        (uintptr_t)CPG_RSTMON_DDR,
        0x007F007F,
        CPG_T_RST
    },
#endif
    {       /* SPI_MULTI */
        (uintptr_t)CPG_RST_SPI,
        (uintptr_t)CPG_RSTMON_SPI,
        0x00010001,
        CPG_T_RST
    },
    {       /* SDHI */
        (uintptr_t)CPG_RST_SDHI,
        (uintptr_t)CPG_RSTMON_SDHI,
        0x00030003,
        CPG_T_RST
    },
#if !RZG2UL
    {       /* GPU */
        (uintptr_t)CPG_RST_GPU,
        (uintptr_t)CPG_RSTMON_GPU,
        0x00070000,
        CPG_T_RST
    },
#endif
    {       /* Image Scaling Unit */
        (uintptr_t)CPG_RST_ISU,
        (uintptr_t)CPG_RSTMON_ISU,
        0x00030000,
        CPG_T_RST
    },
#if !RZG2UL
    {       /* H.264 codec */
        (uintptr_t)CPG_RST_H264,
        (uintptr_t)CPG_RSTMON_H264,
        0x00030003,
        CPG_T_RST
    },
#endif
    {       /* Camera Data Receive Unit */
        (uintptr_t)CPG_RST_CRU,
        (uintptr_t)CPG_RSTMON_CRU,
        0x00070000,
        CPG_T_RST
    },
#if !RZG2UL
    {       /* MIPI-DSI */
        (uintptr_t)CPG_RST_MIPI_DSI,
        (uintptr_t)CPG_RSTMON_MIPI_DSI,
        0x00070000,
        CPG_T_RST
    },
#endif
    {       /* LCDC */
        (uintptr_t)CPG_RST_LCDC,
        (uintptr_t)CPG_RSTMON_LCDC,
        0x00010000,
        CPG_T_RST
    },
    {       /* Serial Sound Interface */
        (uintptr_t)CPG_RST_SSIF,
        (uintptr_t)CPG_RSTMON_SSIF,
        0x000f0000,
        CPG_T_RST
    },
    {       /* Sampling Rate Converter */
        (uintptr_t)CPG_RST_SRC,
        (uintptr_t)CPG_RSTMON_SRC,
        0x00010000,
        CPG_T_RST
    },
    {       /* USB2.0 */
        (uintptr_t)CPG_RST_USB,
        (uintptr_t)CPG_RSTMON_USB,
        0x000f0000,
        CPG_T_RST
    },
    {       /* ETHER */
        (uintptr_t)CPG_RST_ETH,
        (uintptr_t)CPG_RSTMON_ETH,
        0x00030000,
        CPG_T_RST
    },
    {       /* I2C */
        (uintptr_t)CPG_RST_I2C,
        (uintptr_t)CPG_RSTMON_I2C,
        0x000f0000,
        CPG_T_RST
    },
    {       /* SCIF */
        (uintptr_t)CPG_RST_SCIF,
        (uintptr_t)CPG_RSTMON_SCIF,
        0x001f0001,
        CPG_T_RST
    },
    {       /* SCI */
        (uintptr_t)CPG_RST_SCI,
        (uintptr_t)CPG_RSTMON_SCI,
        0x00030000,
        CPG_T_RST
    },
    {       /* IrDA */
        (uintptr_t)CPG_RST_IRDA,
        (uintptr_t)CPG_RSTMON_IRDA,
        0x00010000,
        CPG_T_RST
    },
    {       /* SPI */
        (uintptr_t)CPG_RST_RSPI,
        (uintptr_t)CPG_RSTMON_RSPI,
        0x00070000,
        CPG_T_RST
    },
    {       /* CAN */
        (uintptr_t)CPG_RST_CANFD,
        (uintptr_t)CPG_RSTMON_CANFD,
        0x00030000,
        CPG_T_RST
    },
    {       /* GPIO */
        (uintptr_t)CPG_RST_GPIO,
        (uintptr_t)CPG_RSTMON_GPIO,
        0x00070007,
        CPG_T_RST
    },
    {       /* ADC */
        (uintptr_t)CPG_RST_ADC,
        (uintptr_t)CPG_RSTMON_ADC,
        0x00030000,
        CPG_T_RST
    },
    {       /* Thermal Sensor Unit */
        (uintptr_t)CPG_RST_TSU,
        (uintptr_t)CPG_RSTMON_TSU,
        0x00010000,
        CPG_T_RST
    },
};

static st_cpg_reg_setting_t s_cpg_static_select_tbl[] = {
    { (uintptr_t)CPG_PL3A_DDIV,             0x01000100 },
    { (uintptr_t)CPG_PL3_SSEL,              0x01000000 },
};

static st_cpg_reg_setting_t s_cpg_dynamic_select_tbl[] = {
    { (uintptr_t)CPG_PL4_DSEL,              0x00010001 },
	{ (uintptr_t)CPG_PL2SDHI_DSEL,          0x00110022 },
};

static st_cpg_reg_setting_t s_cpg_sel_pll1_on_off[] = {
    {(uintptr_t)CPG_CLKON_CA55, 0x00010001 }
};

static st_cpg_reg_setting_t s_cpg_sel_pll2_1_on_off[] = {
    {(uintptr_t)CPG_CLKON_ADC,  0x00010001 },
    {(uintptr_t)CPG_CLKON_TSU,  0x00010001 },
    {(uintptr_t)CPG_CLKON_SDHI, 0x00770077 }
};

static st_cpg_reg_setting_t s_cpg_sel_pll2_2_on_off[] = {
    {(uintptr_t)CPG_CLKON_SDHI, 0x00770077 },
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00200020 },
#endif
};

static st_cpg_reg_setting_t s_cpg_sel_pll3_1_on_off[] = {
    {(uintptr_t)CPG_CLKON_AXI_ACPU_BUS, 0x000F000F },
    {(uintptr_t)CPG_CLKON_AXI_COM_BUS, 0x00030003 },
    {(uintptr_t)CPG_CLKON_AXI_DEFAULT_SLV, 0x00010001 },
    {(uintptr_t)CPG_CLKON_AXI_MCPU_BUS, 0x01930193 },
    {(uintptr_t)CPG_CLKON_AXI_TZCDDR, 0x001F001F },
    {(uintptr_t)CPG_CLKON_AXI_VIDEO_BUS, 0x00030003 },
    {(uintptr_t)CPG_CLKON_CA55, 0x001E001E },
    {(uintptr_t)CPG_CLKON_CM33, 0x00010001 },
    {(uintptr_t)CPG_CLKON_CRU, 0x000C000C },
    {(uintptr_t)CPG_CLKON_CST, 0x07FD07FD },
    {(uintptr_t)CPG_CLKON_DAMC_REG, 0x00030003 },
    {(uintptr_t)CPG_CLKON_DDR, 0x00030003 },
    {(uintptr_t)CPG_CLKON_ETH, 0x00030003 },
    {(uintptr_t)CPG_CLKON_GIC600, 0x00010001 },
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_GPU, 0x00070007 },
    {(uintptr_t)CPG_CLKON_H264, 0x00010001 },
#endif
    {(uintptr_t)CPG_CLKON_IA55, 0x00030003 },
    {(uintptr_t)CPG_CLKON_IM33, 0x00030003 },
    {(uintptr_t)CPG_CLKON_ISU, 0x00030003 },
    {(uintptr_t)CPG_CLKON_JAUTH, 0x00010001 },
    {(uintptr_t)CPG_CLKON_LCDC, 0x00010001 },
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x000C000C },
#endif
    {(uintptr_t)CPG_CLKON_OTP, 0x00020002 },
    {(uintptr_t)CPG_CLKON_PERI_COM, 0x00030003 },
    {(uintptr_t)CPG_CLKON_PERI_CPU, 0x000D000D },
    {(uintptr_t)CPG_CLKON_PERI_DDR, 0x00010001 },
    {(uintptr_t)CPG_CLKON_PERI_VIDEO, 0x00070007 },
    {(uintptr_t)CPG_CLKON_REG0_BUS, 0x00010001 },
    {(uintptr_t)CPG_CLKON_REG1_BUS, 0x00030003 },
    {(uintptr_t)CPG_CLKON_ROM, 0x00010001 },
    {(uintptr_t)CPG_CLKON_SDHI, 0x00880088 },
    {(uintptr_t)CPG_CLKON_SRAM_ACPU, 0x00010001 },
    {(uintptr_t)CPG_CLKON_SRAM_MCPU, 0x00010001 },
    {(uintptr_t)CPG_CLKON_SYSC, 0x00020002 },
    {(uintptr_t)CPG_CLKON_TSIPG, 0x00030003 },
    {(uintptr_t)CPG_CLKON_USB, 0x000F000F }
};

static st_cpg_reg_setting_t s_cpg_sel_pll3_2_on_off[] = {
    {(uintptr_t)CPG_CLKON_CRU, 0x00030003 },
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00020002 },
    {(uintptr_t)CPG_CLKON_GPU, 0x00010001 },
#endif
    {(uintptr_t)CPG_CLKON_SPI_MULTI, 0x00030003 },
    {(uintptr_t)CPG_CLKON_AXI_MCPU_BUS, 0x02080208 },
};

static st_cpg_reg_setting_t s_cpg_sel_pll3_3_on_off[] = {
    {(uintptr_t)CPG_CLKON_SPI_MULTI, 0x00030003 },
    {(uintptr_t)CPG_CLKON_AXI_MCPU_BUS, 0x02080208 },
};

static st_cpg_reg_setting_t s_cpg_sel_pll5_1_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00010001 },
#endif
    {(uintptr_t)CPG_CLKON_CRU, 0x00100010 },
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00100010 },
#endif
    {(uintptr_t)CPG_CLKON_LCDC, 0x00020002 }
};

static st_cpg_reg_setting_t s_cpg_sel_pll5_3_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00100010 },
#endif
    {(uintptr_t)CPG_CLKON_LCDC, 0x00020002 }
};

static st_cpg_reg_setting_t s_cpg_sel_pll5_4_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_MIPI_DSI, 0x00100010 },
#endif
    {(uintptr_t)CPG_CLKON_LCDC, 0x00020002 }
};

static st_cpg_reg_setting_t s_cpg_sel_pll6_1_on_off[] = {
    {(uintptr_t)CPG_CLKON_GPU, 0x00010001 }
};

static st_cpg_reg_setting_t s_cpg_sel_gpu1_1_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_GPU, 0x00010001 }
#endif
};

static st_cpg_reg_setting_t s_cpg_sel_gpu1_2_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_GPU, 0x00010001 }
#endif
};

static st_cpg_reg_setting_t s_cpg_sel_gpu2_on_off[] = {
#if !RZG2UL
    {(uintptr_t)CPG_CLKON_GPU, 0x00010001 }
#endif
};

/**********************************************************************************************************************
 * Function Name: cpg_ctrl_clkrst
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_ctrl_clkrst(st_cpg_setup_data_t const *array, uint32_t num)
{
    int32_t i;

    uint32_t mask;
    uint32_t cmp;

    for (i = 0; (i < num); i++, array++)
    {
        mmio_write_32(array->reg, array->val);

        mask = (array->val >> 16) & 0xFFFF;
        cmp  = array->val & 0xFFFF;

        if (CPG_T_RST == array->type)
        {
            cmp = ~(cmp);
        }

        while ((mmio_read_32(array->mon) & mask) != (cmp & mask))
        {
            ;
        }
    }
}
/**********************************************************************************************************************
 * End of function cpg_ctrl_clkrst
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_selector_on_off
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_selector_on_off(uint32_t sel, uint8_t flag)
{
    uint32_t cnt;
    uint32_t tbl_num;

    st_cpg_reg_setting_t * p_ptr;

    switch (sel)
    {
        case CPG_SEL_PLL1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll1_on_off);
            p_ptr   = &s_cpg_sel_pll1_on_off[0];
            break;
        case CPG_SEL_PLL2_1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll2_1_on_off);
            p_ptr   = &s_cpg_sel_pll2_1_on_off[0];
            break;
        case CPG_SEL_PLL2_2_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll2_2_on_off);
            p_ptr   = &s_cpg_sel_pll2_2_on_off[0];
            break;
        case CPG_SEL_PLL3_1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll3_1_on_off);
            p_ptr   = &s_cpg_sel_pll3_1_on_off[0];
            break;
        case CPG_SEL_PLL3_2_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll3_2_on_off);
            p_ptr   = &s_cpg_sel_pll3_2_on_off[0];
            break;
        case CPG_SEL_PLL3_3_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll3_3_on_off);
            p_ptr   = &s_cpg_sel_pll3_3_on_off[0];
            break;
        case CPG_SEL_PLL5_1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll5_1_on_off);
            p_ptr   = &s_cpg_sel_pll5_1_on_off[0];
            break;
        case CPG_SEL_PLL5_3_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll5_3_on_off);
            p_ptr   = &s_cpg_sel_pll5_3_on_off[0];
            break;
        case CPG_SEL_PLL5_4_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll5_4_on_off);
            p_ptr   = &s_cpg_sel_pll5_4_on_off[0];
            break;
        case CPG_SEL_PLL6_1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_pll6_1_on_off);
            p_ptr   = &s_cpg_sel_pll6_1_on_off[0];
            break;
        case CPG_SEL_GPU1_1_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_gpu1_1_on_off);
            p_ptr   = &s_cpg_sel_gpu1_1_on_off[0];
            break;
        case CPG_SEL_GPU1_2_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_gpu1_2_on_off);
            p_ptr   = &s_cpg_sel_gpu1_2_on_off[0];
            break;
        case CPG_SEL_GPU2_ON_OFF:
            tbl_num = ARRAY_SIZE(s_cpg_sel_gpu2_on_off);
            p_ptr   = &s_cpg_sel_gpu2_on_off[0];
            break;
        default:
            break;
    }

    for (cnt = 0; (cnt < tbl_num); cnt++)
    {
        if (CPG_ON == flag)
        {
            mmio_write_32(p_ptr[cnt].reg, (mmio_read_32(p_ptr[cnt].reg) | p_ptr[cnt].val));
        }
        else
        {
            mmio_write_32(p_ptr[cnt].reg, (mmio_read_32(p_ptr[cnt].reg) | (p_ptr[cnt].val & 0xFFFF0000)));
        }
    }

}
/**********************************************************************************************************************
 * End of function cpg_selector_on_off
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_pll_start_146
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_pll_start_146(st_cpg_pll_setdata_146_t *pdata)
{
    mmio_write_32(pdata->clk1_dat.reg, pdata->clk1_dat.val);
    mmio_write_32(pdata->clk2_dat.reg, pdata->clk2_dat.val);
    mmio_write_32(pdata->stby_dat.reg, pdata->stby_dat.val);
}
/**********************************************************************************************************************
 * End of function cpg_pll_start_146
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_pll_setup
 * Description  : It is assumed that the PLL has stopped by the time this function is executed.
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_pll_setup(void)
{
#if !DEBUG_RZG2L_FPGA
    uint32_t val = 0;

    /* PLL4 startup */
    /* PLL4 standby mode transition confirmation */
    do
    {
        val = mmio_read_32(CPG_PLL4_MON);
    }
    while ((val & (PLL4_MON_PLL4_RESETB | PLL4_MON_PLL4_LOCK)) != 0);

    /* PLL6 startup */
    /* PLL6 standby mode transition confirmation */
    do
    {
        val = mmio_read_32(CPG_PLL6_MON);
    }
    while ((val & (PLL6_MON_PLL6_RESETB | PLL6_MON_PLL6_LOCK)) != 0);
#endif

    /* Set PLL4 to normal mode */
    cpg_pll_start_146(&s_cpg_pll4_setdata);

    /* Set PLL6 to normal mode */
    cpg_pll_start_146(&s_cpg_pll6_setdata);

#if !DEBUG_RZG2L_FPGA
    /* PLL4 normal mode transition confirmation */
    do
    {
        val = mmio_read_32(CPG_PLL4_MON);
    }
    while ((val & (PLL4_MON_PLL4_RESETB | PLL4_MON_PLL4_LOCK)) == 0);

    /* PLL6 normal mode transition confirmation */
    do
    {
        val = mmio_read_32(CPG_PLL6_MON);
    }
    while ((val & (PLL6_MON_PLL6_RESETB | PLL6_MON_PLL6_LOCK)) == 0);
#endif
}
/**********************************************************************************************************************
 * End of function cpg_pll_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_sel_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_sel_setup(st_cpg_reg_setting_t *tbl, uint32_t size)
{
    int32_t cnt;

    for (cnt = 0; (cnt < size); cnt++, tbl++)
    {
        mmio_write_32(tbl->reg, tbl->val);
    }

#if !DEBUG_RZG2L_FPGA
    /* Wait for completion of settings */
    while (mmio_read_32(CPG_CLKSTATUS) != 0)
    {
        ;
    }
#endif
}
/**********************************************************************************************************************
 * End of function cpg_div_sel_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_sel_static_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_sel_static_setup(void)
{
    cpg_div_sel_setup(s_cpg_static_select_tbl, ARRAY_SIZE(s_cpg_static_select_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_div_sel_static_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_div_sel_dynamic_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_div_sel_dynamic_setup(void)
{
    cpg_div_sel_setup(s_cpg_dynamic_select_tbl, ARRAY_SIZE(s_cpg_dynamic_select_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_div_sel_dynamic_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_clk_on_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_clk_on_setup(void)
{
    cpg_ctrl_clkrst(&s_cpg_clk_on_tbl[0], ARRAY_SIZE(s_cpg_clk_on_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_clk_on_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_reset_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void cpg_reset_setup(void)
{
    cpg_ctrl_clkrst(&s_cpg_reset_tbl[0], ARRAY_SIZE(s_cpg_reset_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_reset_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_active_ddr
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_active_ddr(void (* disable_phy)(void))
{
    /* Assert the reset of DDRTOP */
    mmio_write_32(CPG_RST_DDR, 0x005F0000);
    mmio_write_32(CPG_OTHERFUNC2_REG, 0x00010000);
    while ((mmio_read_32(CPG_RSTMON_DDR) & 0x0000005F) != 0x0000005F)
    {
        ;
    }

    /* Start the clocks of DDRTOP */
    mmio_write_32(CPG_CLKON_DDR, 0x00030003);
    while ((mmio_read_32(CPG_CLKMON_DDR) & 0x00000003) != 0x00000003)
    {
        ;
    }

    udelay(1);

    /* De-assert rst_n */
    mmio_write_32(CPG_OTHERFUNC2_REG, 0x00010001);

    udelay(1);

    /* De-assert PRESETN */
    mmio_write_32(CPG_RST_DDR, 0x00020002);
    while ((mmio_read_32(CPG_RSTMON_DDR) & 0x00000002) != 0x00000000)
    {
        ;
    }

    udelay(1);

    disable_phy();

    /* De-assert axiY_ARESETn, regARESETn, reset_n */
    mmio_write_32(CPG_RST_DDR, 0x005D005D);
    while ((mmio_read_32(CPG_RSTMON_DDR) & 0x0000005D) != 0x00000000)
    {
        ;
    }

    udelay(1);
}
/**********************************************************************************************************************
 * End of function cpg_active_ddr
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_reset_ddr_mc
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_reset_ddr_mc(void)
{
    /* Assert rst_n, axiY_ARESETn, regARESETn */
    mmio_write_32(CPG_RST_DDR, 0x005C0000);
    mmio_write_32(CPG_OTHERFUNC2_REG, 0x00010000);
    while ((mmio_read_32(CPG_RSTMON_DDR) & 0x0000005C) != 0x0000005C)
    {
        ;
    }

    udelay(1);

    /* De-assert rst_n */
    mmio_write_32(CPG_OTHERFUNC2_REG, 0x00010001);

    udelay(1);

    /* De-assert axiY_ARESETn, regARESETn */
    mmio_write_32(CPG_RST_DDR, 0x005C005C);
    while ((mmio_read_32(CPG_RSTMON_DDR) & 0x0000005C) != 0x00000000)
    {
        ;
    }

    udelay(1);
}
/**********************************************************************************************************************
 * End of function cpg_reset_ddr_mc
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_early_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_early_setup(void)
{
    cpg_ctrl_clkrst(&s_early_setup_tbl[0], ARRAY_SIZE(s_early_setup_tbl));
}
/**********************************************************************************************************************
 * End of function cpg_early_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cpg_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void cpg_setup(void)
{
    cpg_selector_on_off(CPG_SEL_PLL3_3_ON_OFF, CPG_OFF);
    cpg_div_sel_static_setup();
    cpg_selector_on_off(CPG_SEL_PLL3_3_ON_OFF, CPG_ON);
    cpg_pll_setup();
    cpg_clk_on_setup();
    cpg_reset_setup();
    cpg_div_sel_dynamic_setup();
}
/**********************************************************************************************************************
 * End of function cpg_setup
 *********************************************************************************************************************/
