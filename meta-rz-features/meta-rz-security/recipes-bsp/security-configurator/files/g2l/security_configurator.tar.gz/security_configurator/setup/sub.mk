

SOURCES		+=	./setup/otpsecid.c		\
				./setup/otpauthid.c		\
				./setup/otpsecbten.c	\
				./setup/otpjam.c		\
				./setup/otpotren.c		\
				./setup/otpsecbtmode.c	\
				./setup/otpwpauthid.c	\
				./setup/otpwpfunc.c		\
				./setup/otpacdis.c 		\
				./setup/otptacdis.c		\
				./setup/secbtoption0.c	\
				./setup/secbtoption1.c	\
				./setup/rotpkhash.c		\
				./setup/decryptkey0.c 	\
				./setup/decryptkey1.c 	\
				./setup/decryptkey2.c 	\
				./setup/decryptkey3.c	\
				./setup/keyupdatekey.c	\
				./setup/setup.c

MKFILE		+=	./setup/sub.mk
