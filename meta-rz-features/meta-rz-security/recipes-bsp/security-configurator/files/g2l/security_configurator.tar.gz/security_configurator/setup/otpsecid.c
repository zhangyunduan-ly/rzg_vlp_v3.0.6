/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpsecid.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/setup.h"
#include "include/otp_defs.h"
#include "include/drivers/otp_drv.h"
#include "include/drivers/sce_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    int32_t ret = SETUP_SUCCESS;
#if defined(CFG_OTP_SEC_ID)
    int32_t err = sce_set_secid();
    switch (err)
    {
        case 0:
            put_str("--------------------------------------------------", 1);
            put_str(" NOTICE: Security ID has been written.            ", 1);
            put_str("         Turn off the power and reboot the system.", 1);
            put_str("--------------------------------------------------", 1);
            ret = SETUP_REBOOT_REQUIRED;
            break;

        case 1:
            ; /* Security ID was already written */
            break;

        default: /* -1 */
            put_str(" assert: Resource conflict or uninitialized.", 1);
            ASSERT(FALSE);
            break;
    }
#endif
    return ret;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otpsecid
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void otpsecid(st_setup_exec_t * exec)
{
    exec->p_name = "OTPSECID";
#if defined(CFG_OTP_SEC_ID)
    exec->p_init = init;
    exec->p_save = NULL;
    exec->p_ref  = NULL;
    exec->p_set  = NULL;
    exec->p_type = NULL;
#endif
    return;
}
/**********************************************************************************************************************
 * End of function otpsecid
 *********************************************************************************************************************/
