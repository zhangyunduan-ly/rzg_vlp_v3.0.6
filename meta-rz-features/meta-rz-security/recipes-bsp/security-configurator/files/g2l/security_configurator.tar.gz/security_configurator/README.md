# README of the RZ/G2L Security Configurator

<Div Align="right">
Renesas Electronics Corporation

Jun.3,2024
</Div>

## 1. How to build the Security Configurator

This chapter is described how to build the Security Configurator.
Command is executed in the user's home directory (~/).
The environment for building the Security Configurator is in the "~/security_configurator" directory.

One of the following toolchains is required to build.
| Name                | Note                                                             |
|---------------------|------------------------------------------------------------------|
| GNU Toolchain       | GNU Toolchain for the A-profile Architecture: 10.2-2020.11       |
| Yocto SDK           | Yocto SDK built from Yocto environment for RZ/G2 Group           |


### 1.1. Prepare the compiler

Get cross compiler for GNU Toolchain or setup the Yocto SDK.

GNU Toolchain:

```shell
cd ~/
wget https://developer.arm.com/-/media/Files/downloads/gnu-a/10.2-2020.11/binrel/gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf.tar.xz
tar xvf gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf.tar.xz
```

Yocto SDK:

```shell
source /opt/poky/3.1.5/environment-setup-aarch64-poky-linux
```

### 1.2. Prepare the Keys

Store the wrapped keys generated when building the VLP in the folder.

```shell
cd ~/security_configurator
tar zxvf user_factory_prog-smarc-rzg2l.tar.gz -C ./install
```

Encrypt the user factory  programming key using Renesas Key Wrap Service.

Rename the encrypted user factory  programming key to 'wrapped-ufpk.bin' and store it in the "~/security_configurator/install" directory.

'wrapped-ufpk.bin', stored by default in ./install directory, is an encrypted file of the user factory programming key provided as a sample.

### 1.3. Build the Security Configurator

S-record file will be built by the following command.

GNU Toolchain:

```shell
make clean
CROSS_COMPILE=~/gcc-arm-10.2-2020.11-x86_64-aarch64-none-elf/bin/aarch64-none-elf- make BOARD=RZG2L_SMARC
```

Yocto SDK:

```shell
make clean
make BOARD=RZG2L_SMARC
```
## 2. Revision history

Describe the revision history of the Security Configurator.

### [2021-10-01] v1.00

- First release.

### [2022-03-31] v1.10

- Add an instruction to re-encrypt Key Update Key to the update command.
- OTP driver supports RZ/G2UL device.

### [2022-07-30] v1.11

- Peripheral IP(CPG,PFC) supports RZ/G2UL device.
- Add BOARD to the argument of the build command.

### [2023-10-31] v2.00

- Change the display format of Key Update Key
- Add build options for optimization.

### [2024-03-14] v2.10

- Modify dependencies for libraries and binaries.

### [2024-06-03] v2.20

- Modify the One Time Read setting range for RZ/G2UL devices.
