/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cmd_udate.c
 * Version      : 1.0
 * Description  : Update data to be written to OTP
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/command.h"
#include "include/setup.h"

#include "command_private.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: receive_binary
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t receive_binary(uint32_t* addr, size_t* size, u_setup_typeinfo_t* info)
{
    uint8_t  * p_buffer = (uint8_t *)addr;

    uint32_t length = info->bin.size * (sizeof(addr[0]));

    ASSERT(info->bin.size < (*size));

    if (NULL != info->bin.p_sentence)
    {
        put_str(" ", 0);
        put_str(info->bin.p_sentence, 1);
    }

    put_str("", 1);
    put_str("    please send ! (binary): ", 0);

    for (int32_t i = 0; (i < length); i++)
    {
        p_buffer[i] = (uint8_t)get_char();

        if (0 == (i % (sizeof(addr[0]))))
        {
            put_char('.');
        }
    }

    *size = info->bin.size;

    put_str(" finish", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function receive_binary
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: select_options
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t select_options(uint32_t* addr, size_t* size, u_setup_typeinfo_t* info)
{
    int32_t cnt = 0;

    st_setup_options_t * p_opts = info->sel.p_opts;

    ASSERT(info->sel.num_of_sels < (*size));
    ASSERT(p_opts[cnt].num_of_opts + 'a' <= 'z');

    while (info->sel.num_of_sels > cnt)
    {
        char_t sel[2];
        size_t len = sizeof(sel);

        put_str("", 1);
        put_str(" ", 0);
        put_str(p_opts[cnt].p_sentence, 1);

        for (int32_t i = 0; (i < p_opts[cnt].num_of_opts); i++)
        {
            put_str("    ", 0);
            put_char('a'+ i);
            put_str(",  ", 0);
            put_str(p_opts[cnt].p_string_opts[i], 1);
        }

        put_str(" select > ", 0);
        get_str(sel, &len);

        if (INT_CODE == sel[0])
        {
            return -1;
        }

        if (('a' <= sel[0]) && (('a' + p_opts[cnt].num_of_opts) > sel[0]))
        {
            *addr = sel[0] - 'a';

            addr++;
            cnt++;
        }
        else
        {
            put_str(" error: Value out of range.", 1);
        }
        put_str("", 0);
    }

    *size = info->sel.num_of_sels;

    return 0;
}
/**********************************************************************************************************************
 * End of function select_options
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: get_setup_exe
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static const st_setup_exec_t * get_setup_exe(void)
{
    char_t buffer[16];

    const st_setup_exec_t * p_exec = NULL;

    do
    {
        put_str(" OTP Register Name: ", 0);

        size_t length = sizeof(buffer);

        get_str(buffer, &length);

        if (INT_CODE == buffer[0])
        {
            return NULL;
        }

        for (int32_t i = 0; (i < gp_setup->num); i++)
        {
            if (0 == str_cmp(buffer, gp_setup->exec[i].p_name))
            {
                p_exec = &gp_setup->exec[i];
            }
        }

        if (NULL == p_exec)
        {
            put_str("  error: Cannot find name '", 0);
            put_str(buffer, 0);
            put_str("'", 1);
        }
        put_str("", 1);

    } while (NULL == p_exec);

    return p_exec;
}
/**********************************************************************************************************************
 * End of function get_setup_exe
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cmd_update
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t cmd_update(void)
{
    const st_setup_exec_t * p_exec;

    put_str("", 1);
    put_str("<<<< Command to update setup data >>>>", 1);
    put_str("", 1);

    p_exec = get_setup_exe();

    if (NULL != p_exec)
    {
        int32_t err;

        u_setup_typeinfo_t info;

        e_setup_type_t type = p_exec->p_type(&info);

        size_t size = ARRAY_SIZE(g_command_work_buf);

        switch (type)
        {
            case BIN:
                err = receive_binary(g_command_work_buf, &size, &info);
                break;

            case SEL:
                err = select_options(g_command_work_buf, &size, &info);
                break;

            default:
                put_str(" error: Unknown setup type", 1);
                ASSERT(FALSE);
                break;
        }

        if (0 == err)
        {
            err = p_exec->p_set(g_command_work_buf, size);

            if (SETUP_SUCCESS != err)
            {
                put_str(" error: Failed to update '", 0);
                put_str(p_exec->p_name, 0);
                put_str("' (", 0);
                put_str(setup_errstr(err), 0);
                put_str(").", 1);
            }
            else
            {
                put_str("", 1);
                put_str(" Updated done.", 1);
            }
        }
    }

    put_str("", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function cmd_update
 *********************************************************************************************************************/
