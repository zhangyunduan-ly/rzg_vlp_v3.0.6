
SOURCES		+=	./drivers/cpudrv.c			\
				./drivers/devdrv.c 			\
				./drivers/scif0_drv.c 		\
				./drivers/scif_init.c 		\
				./drivers/cpg.c 			\
				./drivers/pfc.c 			\
				./drivers/syc.c 			\
				./drivers/sysc.c 			\
				./drivers/otp_drv.c			\
				./drivers/otp/otp_sys.c		\
				./drivers/sce_drv.c

MKFILE		+=	./drivers/sub.mk
