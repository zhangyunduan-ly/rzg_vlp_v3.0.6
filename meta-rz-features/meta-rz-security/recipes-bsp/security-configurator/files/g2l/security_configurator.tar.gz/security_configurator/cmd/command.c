/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : command.c
 * Version      : 1.0
 * Description  : The entry point of the main command handler
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/command.h"

#include "command_private.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
uint32_t g_command_work_buf[CMD_WORK_BUFFER_SIZE];

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static st_cmdfnass_t s_cmd_list[] =
        {
                { "H", cmd_help,   "    H,    print this help" },
                { "L", cmd_show,   "    L,    show OTP items" },
                { "U", cmd_update, "    U,    data update" },
                { "W", cmd_write,  "    W,    write to OTP" },
                { "Q", cmd_exit,   "    Q,    exit." },
        };

static const st_command_table_t s_cmd_tbl =
        {
                ARRAY_SIZE(s_cmd_list), s_cmd_list,
        };

/**********************************************************************************************************************
 * Function Name: cmd_help
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
int32_t cmd_help(void)
{
    put_str("", 1);
    put_str(" Command List:", 1);
    put_str("", 1);
    for (int32_t i = 0; (i < s_cmd_tbl.number_of_commands); i++)
    {
        put_str(s_cmd_tbl.p_command_list[i].p_command_description, 1);
    }
    put_str("", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function cmd_help
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cmd_exit
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
int32_t cmd_exit(void)
{
    put_str(" exit", 1);
    return -1;
}
/**********************************************************************************************************************
 * End of function cmd_exit
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: get_command_table
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
const st_command_table_t* get_command_table(void)
{
    return &s_cmd_tbl;
}
/**********************************************************************************************************************
 * End of function get_command_table
 *********************************************************************************************************************/
