/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : setup.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef SETUP_H
#define SETUP_H

#define EXEC_LIST_MAX   (30)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/
typedef enum
{
    SETUP_SUCCESS            =  0,
    SETUP_PARAMETER_ERROR    = -1,
    SETUP_PROT_AREA_ACCESS   = -2,
    SETUP_SINGLE_ERR_CORRECT = -3,
    SETUP_DOUBLE_ERR_DETECT  = -4,
    SETUP_MISMATCH_WR_DATA   = -5,
    SETUP_ALREADY_WRITTEN    = -6,
    SETUP_REBOOT_REQUIRED    = -7,
} e_setup_error_t;

typedef enum
{
    BIN = 1,
    SEL,
} e_setup_type_t;

typedef struct
{
    int32_t  num_of_opts;
    uint32_t * p_value_opts;
    char_t  ** p_string_opts;
    char_t   * p_sentence;
} st_setup_options_t;

typedef union
{
    struct
    {
        int32_t size;
        char_t  * p_sentence;
    } bin;

    struct
    {
        int32_t            num_of_sels;
        st_setup_options_t * p_opts;
    } sel;

} u_setup_typeinfo_t;

typedef struct
{
    char_t  * p_name;

    int32_t (* p_init)(void);

    int32_t (* p_save)(void);

    int32_t (* p_ref)(int8_t mode, uint32_t ** data, uint32_t * size);

    int32_t (* p_set)(uint32_t* data, uint32_t size);

    int32_t (* p_type)(u_setup_typeinfo_t* info);

} st_setup_exec_t;

typedef struct
{
    int32_t         num;
    st_setup_exec_t exec[EXEC_LIST_MAX];
}
st_setup_t;

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/
extern const st_setup_t * gp_setup;

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
extern int32_t setup_init (void);
extern char_t * setup_errstr (int32_t errno);

#endif /* SETUP_H */
