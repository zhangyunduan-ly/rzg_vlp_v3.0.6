/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : syc.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/rzg2l_def.h"
#include "include/drivers/mmio.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define SYC_BASE    (RZG2L_SYC_BASE)

#define CNTCR       (0x000)
#define CNTFID0     (0x020)

#define CNTCR_EN    (1 << 0)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: syc_reg_write
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void syc_reg_write(uint32_t offset, uint32_t val)
{
    mmio_write_32(SYC_BASE + offset, val);
}
/**********************************************************************************************************************
 * End of function syc_reg_write
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: syc_reg_read
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static uint32_t syc_reg_read(uint32_t offset)
{
    return (mmio_read_32(SYC_BASE + offset));
}
/**********************************************************************************************************************
 * End of function syc_reg_read
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: enable_counter
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void enable_counter(uint32_t enable)
{
    syc_reg_write(CNTCR, enable & CNTCR_EN);
}
/**********************************************************************************************************************
 * End of function enable_counter
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: syc_init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void syc_init(uint32_t freq)
{
    syc_reg_write(CNTFID0, freq);
    enable_counter(CNTCR_EN);
}
/**********************************************************************************************************************
 * End of function syc_init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: syc_get_freq
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
uint32_t syc_get_freq(void)
{
    return (syc_reg_read(CNTFID0));
}
/**********************************************************************************************************************
 * End of function syc_get_freq
 *********************************************************************************************************************/
