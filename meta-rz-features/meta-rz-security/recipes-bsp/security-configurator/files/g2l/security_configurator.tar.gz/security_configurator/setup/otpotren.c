/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpotren.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/setup.h"
#include "include/otp_defs.h"
#include "include/drivers/otp_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_NAME    (OTP_SYM_OTREN)
#define OTP_SIZE    (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_rd_data[OTP_SIZE];
static uint32_t s_wr_data[OTP_SIZE];

static uint32_t s_otren_0[] =
{
    0x00000000, OTP_OTR_EN_0
};
static char_t * sp_otren_0_sentence[ARRAY_SIZE(s_otren_0)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_1[] =
{
    0x00000000, OTP_OTR_EN_1
};
static char_t * sp_otren_1_sentence[ARRAY_SIZE(s_otren_1)] =
{
    "Do not enable", "Enable"
};

#ifndef RZG2UL
static uint32_t s_otren_2[] =
{
    0x00000000, OTP_OTR_EN_2
};
static char_t * sp_otren_2_sentence[ARRAY_SIZE(s_otren_2)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_3[] =
{
    0x00000000, OTP_OTR_EN_3
};
static char_t * sp_otren_3_sentence[ARRAY_SIZE(s_otren_3)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_4[] =
{
    0x00000000, OTP_OTR_EN_4
};
static char_t * sp_otren_4_sentence[ARRAY_SIZE(s_otren_4)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_5[] =
{
    0x00000000, OTP_OTR_EN_5
};
static char_t * sp_otren_5_sentence[ARRAY_SIZE(s_otren_5)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_6[] =
{
    0x00000000, OTP_OTR_EN_6
};
static char_t * sp_otren_6_sentence[ARRAY_SIZE(s_otren_6)] =
{
    "Do not enable", "Enable"
};

static uint32_t s_otren_7[] =
{
    0x00000000, OTP_OTR_EN_7
};
static char_t * sp_otren_7_sentence[ARRAY_SIZE(s_otren_7)] =
{
    "Do not enable", "Enable"
};
#endif /* RZG2UL */

static st_setup_options_t s_opts[] =
{
    { ARRAY_SIZE(s_otren_0), s_otren_0, sp_otren_0_sentence,
        "Select whether to enable One Time Read of 0-63 bytes in the user area" },
    { ARRAY_SIZE(s_otren_1), s_otren_1, sp_otren_1_sentence,
        "Select whether to enable One Time Read of 64-127 bytes in the user area" },
#ifndef RZG2UL
    { ARRAY_SIZE(s_otren_2), s_otren_2, sp_otren_2_sentence,
        "Select whether to enable One Time Read of 128-191 bytes in the user area" },
    { ARRAY_SIZE(s_otren_3), s_otren_3, sp_otren_3_sentence,
        "Select whether to enable One Time Read of 192-255 bytes in the user area" },
    { ARRAY_SIZE(s_otren_4), s_otren_4, sp_otren_4_sentence,
        "Select whether to enable One Time Read of 256-319 bytes in the user area" },
    { ARRAY_SIZE(s_otren_5), s_otren_5, sp_otren_5_sentence,
        "Select whether to enable One Time Read of 320-383 bytes in the user area" },
    { ARRAY_SIZE(s_otren_6), s_otren_6, sp_otren_6_sentence,
        "Select whether to enable One Time Read of 384-447 bytes in the user area" },
    { ARRAY_SIZE(s_otren_7), s_otren_7, sp_otren_7_sentence,
        "Select whether to enable One Time Read of 448-511 bytes in the user area" },
#endif /* RZG2UL */
};

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    memset((uint8_t *)s_rd_data, 0, sizeof(s_rd_data));
    memset((uint8_t *)s_wr_data, 0, sizeof(s_wr_data));

#if defined(CFG_OTP_OTR_EN_0)
    s_wr_data[0] |= OTP_OTR_EN_0;
#endif
#if defined(CFG_OTP_OTR_EN_1)
    s_wr_data[0] |= OTP_OTR_EN_1;
#endif
#ifndef RZG2UL
#if defined(CFG_OTP_OTR_EN_2)
    s_wr_data[0] |= OTP_OTR_EN_2;
#endif
#if defined(CFG_OTP_OTR_EN_3)
    s_wr_data[0] |= OTP_OTR_EN_3;
#endif
#if defined(CFG_OTP_OTR_EN_4)
    s_wr_data[0] |= OTP_OTR_EN_4;
#endif
#if defined(CFG_OTP_OTR_EN_5)
    s_wr_data[0] += OTP_OTR_EN_5;
#endif
#if defined(CFG_OTP_OTR_EN_6)
    s_wr_data[0] += OTP_OTR_EN_6;
#endif
#if defined(CFG_OTP_OTR_EN_7)
    s_wr_data[0] += OTP_OTR_EN_7;
#endif
#endif /* RZG2UL */
    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t save(void)
{
    return (otp_save(OTP_NAME, s_wr_data, ARRAY_SIZE(s_wr_data)));
}
/**********************************************************************************************************************
 * End of function save
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t** data, uint32_t* size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = NULL;

    if (0 == mode)
    {
        ret = otp_load(OTP_NAME, s_rd_data, ARRAY_SIZE(s_rd_data));

        if (SETUP_SUCCESS == ret)
        {
            *data = &s_rd_data[0];
            *size = ARRAY_SIZE(s_rd_data);
        }
    }
    else
    {
        *data = &s_wr_data[0];
        *size = ARRAY_SIZE(s_wr_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t* data, uint32_t size)
{
    uint32_t otren = 0;

    ASSERT(size == ARRAY_SIZE(s_opts));

    ASSERT(data[0] < ARRAY_SIZE(s_otren_0));
    otren |= s_otren_0[data[0]];

    ASSERT(data[1] < ARRAY_SIZE(s_otren_1));
    otren |= s_otren_1[data[1]];
#ifndef RZG2UL
    ASSERT(data[2] < ARRAY_SIZE(s_otren_2));
    otren |= s_otren_2[data[2]];

    ASSERT(data[3] < ARRAY_SIZE(s_otren_3));
    otren |= s_otren_3[data[3]];

    ASSERT(data[4] < ARRAY_SIZE(s_otren_4));
    otren |= s_otren_4[data[4]];

    ASSERT(data[5] < ARRAY_SIZE(s_otren_5));
    otren |= s_otren_5[data[5]];

    ASSERT(data[6] < ARRAY_SIZE(s_otren_6));
    otren |= s_otren_6[data[6]];

    ASSERT(data[7] < ARRAY_SIZE(s_otren_7));
    otren |= s_otren_7[data[7]];
#endif /* RZG2UL */
    s_wr_data[0] = otren;

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t* info)
{
    info->sel.num_of_sels = ARRAY_SIZE(s_opts);

    info->sel.p_opts = s_opts;

    return SEL;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otpotren
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void otpotren(st_setup_exec_t * exec)
{
    exec->p_name = "OTPOTREN";
    exec->p_init = init;
    exec->p_save = save;
    exec->p_ref  = ref;
    exec->p_set  = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function otpotren
 *********************************************************************************************************************/
