/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : pfc.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/drivers/pfc.h"
#include "include/drivers/pfc_regs.h"
#include "include/drivers/mmio.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

static st_pfc_regs_t s_pfc_mux_reg_tbl[PFC_MUX_TBL_NUM] = {
#if RZG2UL
    /* P0(sd0) & P0(sd1)    */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC10,  0x0F },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC10,  0x00001111 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH10, 0x0000000001010101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD10, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR10,   0x0000000001010101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
#else
    /* P18(sd0) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC22,  0x03 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC22,  0x00000011 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH22, 0x0000000000000101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD22, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR22,   0x0000000000000101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
    /* P19(sd1) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC23,  0x03 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC23,  0x00000011 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH23, 0x0000000000000101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD23, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR23,   0x0000000000000101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
#endif
#if RZG2UL
#if (DEVICE_TYPE == 1)
    /* P6(scif0) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC16,  0x18 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC16,  0x00066000 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH16, 0x0000000101000000 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD16, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR16,   0x0000000101000000 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
#else
    /* P13(scif0) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC1D,  0x03 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC1D,  0x00000011 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH1D, 0x0000000000000101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD1D, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR1D,   0x0000000000000101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
#endif
#else
    /* P38(scif0) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC36,  0x03 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC36,  0x00000011 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH36, 0x0000000000000101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD36, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR36,   0x0000000000000101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
    /* P39(scif0) */
    {
        { PFC_ON,  (uintptr_t)PFC_PMC37,  0x07 },                   /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC37,  0x00000111 },             /* PFC */
        { PFC_OFF, (uintptr_t)PFC_IOLH37, 0x0000000000010101 },     /* IOLH */
        { PFC_OFF, (uintptr_t)PFC_PUPD37, 0x0000000000000000 },     /* PUPD */
        { PFC_OFF, (uintptr_t)PFC_SR37,   0x0000000000010101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    }
#endif
};

static st_pfc_regs_t s_pfc_qspi_reg_tbl[PFC_QSPI_TBL_NUM] = {
    /* QSPI0 */
    {
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
        { PFC_ON,  (uintptr_t)PFC_IOLH0A, 0x0000020202020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD0A, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR0A,   0x0000010101010101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
    /* QSPI1 */
    {
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
        { PFC_ON,  (uintptr_t)PFC_IOLH0B, 0x0000020202020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD0B, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR0B,   0x0000010101010101 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    },
    /* QSPIn */
    {
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
        { PFC_ON,  (uintptr_t)PFC_IOLH0C, 0x0000000000020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD0C, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR0C,   0x0000000000010000 },     /* SR */
        { PFC_OFF, (uintptr_t)NULL,       0 }                       /* IEN */
    }
};

static st_pfc_regs_t s_pfc_sd_reg_tbl[PFC_SD_TBL_NUM] = {
    /* SD0_CLK */
    {
#if RZG2UL
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
#else
        { PFC_ON,  (uintptr_t)PFC_PMC22,  0x0003 },                 /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC22,  0x00000003 },             /* PFC */
#endif
        { PFC_ON,  (uintptr_t)PFC_IOLH06, 0x0000000000020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD06, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR06,   0x0000000000010101 },     /* SR */
        { PFC_ON,  (uintptr_t)PFC_IEN06,  0x0000000000000100 }      /* IEN */
    },
    /* SD0_DATA */
    {
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
        { PFC_ON,  (uintptr_t)PFC_IOLH07, 0x0202020202020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD07, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR07,   0x0101010101010101 },     /* SR */
        { PFC_ON,  (uintptr_t)PFC_IEN07,  0x0101010101010101 }      /* IEN */
    },
    /* SD1_CLK */
    {
#if RZG2UL
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
#else
        { PFC_ON,  (uintptr_t)PFC_PMC23,  0x0003 },                 /* PMC */
        { PFC_ON,  (uintptr_t)PFC_PFC23,  0x00000003 },             /* PFC */
#endif
        { PFC_ON,  (uintptr_t)PFC_IOLH08, 0x0000000000000202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD08, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR08,   0x0000000000000101 },     /* SR */
        { PFC_ON,  (uintptr_t)PFC_IEN08,  0x0000000000000100 }      /* IEN */
    },
    /* SD1_DATA */
    {
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PMC */
        { PFC_OFF, (uintptr_t)NULL,       0 },                      /* PFC */
        { PFC_ON,  (uintptr_t)PFC_IOLH09, 0x0000000002020202 },     /* IOLH */
        { PFC_ON,  (uintptr_t)PFC_PUPD09, 0x0000000000000000 },     /* PUPD */
        { PFC_ON,  (uintptr_t)PFC_SR09,   0x0000000001010101 },     /* SR */
        { PFC_ON,  (uintptr_t)PFC_IEN09,  0x0000000001010101 }      /* IEN */
    }
};

/**********************************************************************************************************************
 * Function Name: pfc_mux_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_mux_setup(void)
{
    int32_t cnt;

    /* multiplexer terminal switching */
    mmio_write_32(PFC_PWPR, 0x0);
    mmio_write_32(PFC_PWPR, PWPR_PFCWE);

    for (cnt = 0; (cnt < PFC_MUX_TBL_NUM); cnt++)
    {
        /* PMC */
        if (PFC_ON == s_pfc_mux_reg_tbl[cnt].pmc.flg)
        {
            mmio_write_8(s_pfc_mux_reg_tbl[cnt].pmc.reg, s_pfc_mux_reg_tbl[cnt].pmc.val);
        }

        /* PFC */
        if (PFC_ON == s_pfc_mux_reg_tbl[cnt].pfc.flg)
        {
            mmio_write_32(s_pfc_mux_reg_tbl[cnt].pfc.reg, s_pfc_mux_reg_tbl[cnt].pfc.val);
        }

        /* IOLH */
        if (PFC_ON == s_pfc_mux_reg_tbl[cnt].iolh.flg)
        {
            mmio_write_64(s_pfc_mux_reg_tbl[cnt].iolh.reg, s_pfc_mux_reg_tbl[cnt].iolh.val);
        }

        /* PUPD */
        if (PFC_ON == s_pfc_mux_reg_tbl[cnt].pupd.flg)
        {
            mmio_write_64(s_pfc_mux_reg_tbl[cnt].pupd.reg, s_pfc_mux_reg_tbl[cnt].pupd.val);
        }

        /* SR */
        if (PFC_ON == s_pfc_mux_reg_tbl[cnt].sr.flg)
        {
            mmio_write_64(s_pfc_mux_reg_tbl[cnt].sr.reg, s_pfc_mux_reg_tbl[cnt].sr.val);
        }
    }

    mmio_write_32(PFC_PWPR, 0x0);
    mmio_write_32(PFC_PWPR, PWPR_B0Wl);
}
/**********************************************************************************************************************
 * End of function pfc_mux_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_qspi_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_qspi_setup(void)
{
    int32_t cnt;

#if (QSPI_IO_1_8V == 1)
    mmio_write_32(PFC_QSPI, 1);
#else
    mmio_write_32(PFC_QSPI, 0);
#endif

    for (cnt = 0; (cnt < PFC_QSPI_TBL_NUM); cnt++)
    {
        /* IOLH */
        if (PFC_ON == s_pfc_qspi_reg_tbl[cnt].iolh.flg)
        {
            mmio_write_64(s_pfc_qspi_reg_tbl[cnt].iolh.reg, s_pfc_qspi_reg_tbl[cnt].iolh.val);
        }

        /* PUPD */
        if (PFC_ON == s_pfc_qspi_reg_tbl[cnt].pupd.flg)
        {
            mmio_write_64(s_pfc_qspi_reg_tbl[cnt].pupd.reg, s_pfc_qspi_reg_tbl[cnt].pupd.val);
        }

        /* SR */
        if (PFC_ON == s_pfc_qspi_reg_tbl[cnt].sr.flg)
        {
            mmio_write_64(s_pfc_qspi_reg_tbl[cnt].sr.reg, s_pfc_qspi_reg_tbl[cnt].sr.val);
        }
    }
}
/**********************************************************************************************************************
 * End of function pfc_qspi_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_sd_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void pfc_sd_setup(void)
{
    int32_t cnt;

    /* Since SDx is 3.3V, the initial value will be set. */
#if (EMMC_IO_1_8V == 1)
    mmio_write_32(PFC_SD_ch0, 1);
#else
    mmio_write_32(PFC_SD_ch0, 0);
#endif
    mmio_write_32(PFC_SD_ch1, 0);

    for (cnt = 0; (cnt < PFC_SD_TBL_NUM); cnt++)
    {
        /* PMC */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].pmc.flg)
        {
            mmio_write_8(s_pfc_sd_reg_tbl[cnt].pmc.reg, s_pfc_sd_reg_tbl[cnt].pmc.val);
        }

        /* PFC */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].pfc.flg)
        {
            mmio_write_32(s_pfc_sd_reg_tbl[cnt].pfc.reg, s_pfc_sd_reg_tbl[cnt].pfc.val);
        }

        /* IOLH */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].iolh.flg)
        {
            mmio_write_64(s_pfc_sd_reg_tbl[cnt].iolh.reg, s_pfc_sd_reg_tbl[cnt].iolh.val);
        }

        /* PUPD */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].pupd.flg)
        {
            mmio_write_64(s_pfc_sd_reg_tbl[cnt].pupd.reg, s_pfc_sd_reg_tbl[cnt].pupd.val);
        }

        /* SR */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].sr.flg)
        {
            mmio_write_64(s_pfc_sd_reg_tbl[cnt].sr.reg, s_pfc_sd_reg_tbl[cnt].sr.val);
        }

        /* IEN */
        if (PFC_ON == s_pfc_sd_reg_tbl[cnt].ien.flg)
        {
            mmio_write_64(s_pfc_sd_reg_tbl[cnt].ien.reg, s_pfc_sd_reg_tbl[cnt].ien.val);
        }
    }
}
/**********************************************************************************************************************
 * End of function pfc_sd_setup
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: pfc_setup
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void pfc_setup(void)
{
    pfc_mux_setup();
    pfc_qspi_setup();
    pfc_sd_setup();
}
/**********************************************************************************************************************
 * End of function pfc_setup
 *********************************************************************************************************************/
