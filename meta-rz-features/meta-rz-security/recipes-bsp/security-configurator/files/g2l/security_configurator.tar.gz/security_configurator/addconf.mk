
define add_define
ifeq ($(value $(1)),y)
    DEFINES += -D$(1)$(if $(value $(1)),=$(value $(1)),)
endif
endef

define dep_define
ifeq ($(value $(1)) $(value $(2)),y n)
$$(error If $(1) is set to y, then $(2) must also be set to y)
endif
endef

define add_filedef
ifneq ($(realpath $(value $(1))),)
    DEFINES += -D$(1)=$(value $(1))
endif
endef

define dep_filedef
ifeq ($(realpath $(value $(1))),)
ifeq ($(value $(2)),y)
$$(error If $(2) is set to y, then $(1) must be set to the correct file path.)
endif
endif
endef

# y or n
CFG_OTP_SEC_ID ?= n
$(eval $(call add_define,CFG_OTP_SEC_ID))

# y or n
CFG_OTP_AUTH_ID ?= n
$(eval $(call add_define,CFG_OTP_AUTH_ID))
$(eval $(call dep_define,CFG_OTP_AUTH_ID,CFG_OTP_SEC_ID))

# y or n
CFG_OTP_SECBT_EN ?= n
$(eval $(call add_define,CFG_OTP_SECBT_EN))

# none or secip or reject
CFG_OTP_AUTH_MD ?= none
$(eval CFG_OTP_AUTH_MD_$(CFG_OTP_AUTH_MD)=y)
$(eval $(call add_define,CFG_OTP_AUTH_MD_$(CFG_OTP_AUTH_MD)))

# y or n
CFG_OTP_OTR_EN_0 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_0))
CFG_OTP_OTR_EN_1 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_1))
CFG_OTP_OTR_EN_2 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_2))
CFG_OTP_OTR_EN_3 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_3))
CFG_OTP_OTR_EN_4 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_4))
CFG_OTP_OTR_EN_5 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_5))
CFG_OTP_OTR_EN_6 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_6))
CFG_OTP_OTR_EN_7 ?= n
$(eval $(call add_define,CFG_OTP_OTR_EN_7))

# y or n
CFG_OTP_SB_DIS_SD ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SD))
CFG_OTP_SB_DIS_EMMC18 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_EMMC18))
CFG_OTP_SB_DIS_EMMC33 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_EMMC33))
CFG_OTP_SB_DIS_SPI18 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SPI18))
CFG_OTP_SB_DIS_SPI33 ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SPI33))

# y or n
CFG_OTP_WP_AUTH_ID ?= n
$(eval $(call add_define,CFG_OTP_WP_AUTH_ID))

# y or n
CFG_OTP_WP_FUNC ?= n
$(eval $(call add_define,CFG_OTP_WP_FUNC))

# y or n
CFG_OTP_RAC_DIS ?= n
$(eval $(call add_define,CFG_OTP_RAC_DIS))

# y or n
CFG_OTP_TAC_DIS ?= n
$(eval $(call add_define,CFG_OTP_TAC_DIS))

# y or n
CFG_OTP_ANTI_RB_EN ?= n
$(eval $(call add_define,CFG_OTP_ANTI_RB_EN))

# y or n
CFG_OTP_SB_DIS_SCIF ?= n
$(eval $(call add_define,CFG_OTP_SB_DIS_SCIF))

# y or n
CFG_OTP_FAIL_SAFE_DIS ?= n
$(eval $(call add_define,CFG_OTP_FAIL_SAFE_DIS))

# y or n
CFG_OTP_ENC_USER_KEY ?= n
$(eval $(call add_define,CFG_OTP_ENC_USER_KEY))
$(eval $(call dep_define,CFG_OTP_ENC_USER_KEY,CFG_OTP_SEC_ID))

# filepath or empty
CFG_ROT_PK_HASH_FILE ?=
$(eval $(call add_filedef,CFG_ROT_PK_HASH_FILE))

# filepath or empty
CFG_WRAPPED_UFPK_FILE ?=
$(eval $(call add_filedef,CFG_WRAPPED_UFPK_FILE))
$(eval $(call dep_filedef,CFG_WRAPPED_UFPK_FILE,CFG_OTP_SEC_ID))

# filepath or empty
CFG_UFPK_ENC_IV0_FILE ?=
$(eval $(call add_filedef,CFG_UFPK_ENC_IV0_FILE))
$(eval $(call dep_filedef,CFG_UFPK_ENC_IV0_FILE,CFG_OTP_SEC_ID))

# filepath or empty
CFG_ENC_AUTH_DATA_FILE ?=
$(eval $(call add_filedef,CFG_ENC_AUTH_DATA_FILE))

# filepath or empty
CFG_ENC_USER_KEY0_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY0_FILE))

# filepath or empty
CFG_ENC_USER_KEY1_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY1_FILE))

# filepath or empty
CFG_ENC_USER_KEY2_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY2_FILE))

# filepath or empty
CFG_ENC_USER_KEY3_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KEY3_FILE))

# filepath or empty
CFG_ENC_USER_KUK_FILE ?=
$(eval $(call add_filedef,CFG_ENC_USER_KUK_FILE))

