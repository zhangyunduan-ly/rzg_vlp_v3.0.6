/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : sce_drv.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/incbin.h"
#include "include/drivers/sce_drv.h"

#include "lib/include/r_sce_library.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define SCE_SELF_DIAG_RETRY        (3)                 /* SCE self diagnosis retry count */
#define SCE_DIAG_OK                (1)
#define SCE_DIAG_NG                (0)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
uint32_t S_RAM[R_SCE_CFG_SRAM_SIZE];

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

static uint32_t s_init_vector[4];
static uint32_t s_session_key[9];

static uint32_t s_already_self_diagnosis_sce = SCE_DIAG_NG;

/**********************************************************************************************************************
 * Function Name: self_diagnosis2
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1
 *********************************************************************************************************************/
static int32_t self_diagnosis2(void)
{
    int32_t ret = 0;

    int32_t retry_cnt = SCE_SELF_DIAG_RETRY;

    gp_sce = (uint32_t *) R_SCE_CFG_BASE;

    while ((retry_cnt > 0) && (SCE_DIAG_NG == s_already_self_diagnosis_sce))
    {
        fsp_err_t err = R_SCE_SelfCheck2Sub(); /* TSIP procedure 02 */
        switch (err)
        {
            case FSP_SUCCESS:
                ASSERT((sizeof(s_session_key)) == ((size_t)g_sizeof_session_key));
                memcpy((uint8_t *)s_session_key, (uint8_t *)g_session_key, (size_t)g_sizeof_session_key);

                ASSERT(sizeof(s_init_vector) == (size_t)g_sizeof_init_vector);
                memcpy((uint8_t*)s_init_vector, (uint8_t*)g_init_vector, (size_t)g_sizeof_init_vector);

                s_already_self_diagnosis_sce = SCE_DIAG_OK;
                break;

            case FSP_ERR_CRYPTO_SCE_RETRY:
                retry_cnt--;
                break;

            default: /* FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT */
                retry_cnt = 0;
                break;
        }
    }

    if (SCE_DIAG_OK != s_already_self_diagnosis_sce)
    {
        ret = -1;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function self_diagnosis2
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_set_secid
 * Description  :
 * Arguments    :
 * Return Value : 0 or 1 or -1
 *********************************************************************************************************************/
int32_t sce_set_secid(void)
{
    int32_t ret = 0;

    if (0 != self_diagnosis2())
    {
        ret = -1;
    }
    else
    {
        fsp_err_t err = R_SCE_SetSecurityIdSub();
        switch (err)
        {
            case FSP_SUCCESS:
                break;

            case FSP_ERR_CRYPTO_SCE_FAIL:
                ret = 1;
                break;

            default: /* FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT */
                ret = -1;
                break;
        }
    }
    return ret;
}
/**********************************************************************************************************************
 * End of function sce_set_secid
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_generate_password
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_generate_password(const uint32_t* encauth, uint32_t* password)
{
    int32_t ret = 0;

    if (0 != self_diagnosis2())
    {
        ret = -1;
    }
    else
    {
        uint32_t auth_hash[SCE_AUTH_DATA_HASH_SIZE];

        /* procedure 15 */
        fsp_err_t err = R_SCE_CreateExpJtagPassSub(&s_session_key[0], &s_session_key[1], s_init_vector,
                (uint32_t *)encauth, auth_hash);

        switch (err)
        {
            case FSP_SUCCESS:
                for (int32_t i = SCE_AUTH_DATA_HASH_SIZE; (i > 0); i--)
                {
                    *password = change_endian_long(auth_hash[i - 1]);
                    password++;
                }
                break;

            case FSP_ERR_CRYPTO_SCE_FAIL:
                ret = -2;
                break;

            default: /* FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT */
                ret = -1;
                break;
        }
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_generate_password
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_aes128key
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_install_aes128key(const uint32_t* instkey, uint32_t* keyindex)
{
    int32_t ret = 0;

    if (0 != self_diagnosis2())
    {
        ret = -1;
    }
    else
    {
        fsp_err_t err = R_SCE_InstallAes128UserKeySub(&s_session_key[0], &s_session_key[1], s_init_vector,
                (uint32_t *)instkey, keyindex);

        switch (err)
        {
            case FSP_SUCCESS:
                break;

            case FSP_ERR_CRYPTO_SCE_FAIL:
                ret = -2;
                break;

            default: /* FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT */
                ret = -1;
                break;
        }
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_aes128key
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: sce_install_kuk
 * Description  :
 * Arguments    :
 * Return Value : 0 or -1 or -2
 *********************************************************************************************************************/
int32_t sce_install_kuk(const uint32_t* instkey, uint32_t* keyindex)
{
    int32_t ret = 0;

    if (0 != self_diagnosis2())
    {
        ret = -1;
    }
    else
    {
        fsp_err_t err = R_SCE_InstallKeyringUpdateKeySub(&s_session_key[0], &s_session_key[1], s_init_vector,
                (uint32_t *)instkey, keyindex);

        switch (err)
        {
            case FSP_SUCCESS:
                break;

            case FSP_ERR_CRYPTO_SCE_FAIL:
                ret = -2;
                break;

            default: /* FSP_ERR_CRYPTO_SCE_RESOURCE_CONFLICT */
                ret = -1;
                break;
        }
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function sce_install_kuk
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: change_endian_long
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
uint32_t change_endian_long(volatile uint32_t data)
{
    return ((((data) & 0xFF000000) >> 24) | (((data) & 0x00FF0000) >>  8) | (((data) & 0x0000FF00) << 8) |
            (((data) & 0x000000FF) << 24));
}
/**********************************************************************************************************************
 * End of function change_endian_long
 *********************************************************************************************************************/
