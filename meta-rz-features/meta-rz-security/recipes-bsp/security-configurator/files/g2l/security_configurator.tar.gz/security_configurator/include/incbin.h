/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : incbin.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#ifndef INCBIN_H
#define INCBIN_H

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

#ifndef __ASSEMBLY__
/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

extern const uint32_t g_rotpk_hash[];
extern const uint32_t g_sizeof_rotpk_hash[];

extern const uint32_t g_session_key[];
extern const uint32_t g_sizeof_session_key[];

extern const uint32_t g_init_vector[];
extern const uint32_t g_sizeof_init_vector[];

extern const uint32_t g_enc_auth_data[];
extern const uint32_t g_sizeof_enc_auth_data[];

extern const uint32_t g_enc_inst_key0[];
extern const uint32_t g_sizeof_enc_inst_key0[];

extern const uint32_t g_enc_inst_key1[];
extern const uint32_t g_sizeof_enc_inst_key1[];

extern const uint32_t g_enc_inst_key2[];
extern const uint32_t g_sizeof_enc_inst_key2[];

extern const uint32_t g_enc_inst_key3[];
extern const uint32_t g_sizeof_enc_inst_key3[];

#endif /* __ASSEMBLY__ */

#endif /* INCBIN_H */
