/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : otpsecbtmode.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/setup.h"
#include "include/otp_defs.h"
#include "include/drivers/otp_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_NAME    (OTP_SYM_SECBTMODE)
#define OTP_SIZE    (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_rd_data[OTP_SIZE];
static uint32_t s_wr_data[OTP_SIZE];

static uint32_t s_secbtmode_sd[] =
{
    0, OTP_SB_DIS_SD
};
static char_t * sp_secbtmode_sd_sentence[ARRAY_SIZE(s_secbtmode_sd)] =
{
    "Do not disable", "Disable"
};

static uint32_t s_secbtmode_emmc18[] =
{
    0, OTP_SB_DIS_EMMC18
};
static char_t * sp_secbtmode_emmc18_sentence[ARRAY_SIZE(s_secbtmode_emmc18)] =
{
    "Do not disable", "Disable"
};

static uint32_t s_secbtmode_emmc33[] =
{
    0, OTP_SB_DIS_EMMC33
};
static char_t * sp_secbtmode_emmc33_sentence[ARRAY_SIZE(s_secbtmode_emmc33)] =
{
    "Do not disable", "Disable"
};

static uint32_t s_secbtmode_spi18[] =
{
    0, OTP_SB_DIS_SPI18
};
static char_t * sp_secbtmode_spi18_sentence[ARRAY_SIZE(s_secbtmode_spi18)] =
{
    "Do not disable", "Disable"
};

static uint32_t s_secbtmode_spi33[] =
{
    0, OTP_SB_DIS_SPI33
};
static char_t * sp_secbtmode_spi33_sentence[ARRAY_SIZE(s_secbtmode_spi33)] =
{
    "Do not disable", "Disable"
};

static st_setup_options_t s_opts[] =
{
    { ARRAY_SIZE(s_secbtmode_sd),     s_secbtmode_sd,     sp_secbtmode_sd_sentence,
        "Select whether to disable secure boot from eSD." },
    { ARRAY_SIZE(s_secbtmode_emmc18), s_secbtmode_emmc18, sp_secbtmode_emmc18_sentence,
        "Select whether to disable secure boot from eMMC 1.8V."},
    { ARRAY_SIZE(s_secbtmode_emmc33), s_secbtmode_emmc33, sp_secbtmode_emmc33_sentence,
        "Select whether to disable secure boot from eMMC 3.3V."},
    { ARRAY_SIZE(s_secbtmode_spi18),  s_secbtmode_spi18,  sp_secbtmode_spi18_sentence,
        "Select whether to disable secure boot from SPI 1.8V." },
    { ARRAY_SIZE(s_secbtmode_spi33),  s_secbtmode_spi33,  sp_secbtmode_spi33_sentence,
        "Select whether to disable secure boot from SPI 3.3V." },
};

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    memset((uint8_t *)s_rd_data, 0, sizeof(s_rd_data));
    memset((uint8_t *)s_wr_data, 0, sizeof(s_wr_data));

#if defined(CFG_OTP_SB_DIS_SD)
    s_wr_data[0] |= OTP_SB_DIS_SD;
#endif
#if defined(CFG_OTP_SB_DIS_EMMC18)
    s_wr_data[0] |= OTP_SB_DIS_EMMC18;
#endif
#if defined(CFG_OTP_SB_DIS_EMMC33)
    s_wr_data[0] |= OTP_SB_DIS_EMMC33;
#endif
#if defined(CFG_OTP_SB_DIS_SPI18)
    s_wr_data[0] |= OTP_SB_DIS_SPI18;
#endif
#if defined(CFG_OTP_SB_DIS_SPI33)
    s_wr_data[0] |= OTP_SB_DIS_SPI33;
#endif
    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t save(void)
{
    return (otp_save(OTP_NAME, s_wr_data, ARRAY_SIZE(s_wr_data)));
}
/**********************************************************************************************************************
 * End of function save
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t** data, uint32_t* size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = NULL;

    if (0 == mode)
    {
        ret = otp_load(OTP_NAME, s_rd_data, ARRAY_SIZE(s_rd_data));

        if (SETUP_SUCCESS == ret)
        {
            *data = &s_rd_data[0];
            *size = ARRAY_SIZE(s_rd_data);
        }
    }
    else
    {
        *data = &s_wr_data[0];
        *size = ARRAY_SIZE(s_wr_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t* data, uint32_t size)
{
    uint32_t secbtmode = 0;

    ASSERT(size == ARRAY_SIZE(s_opts));

    ASSERT(data[0] < ARRAY_SIZE(s_secbtmode_sd));
    secbtmode |= s_secbtmode_sd[data[0]];

    ASSERT(data[1] < ARRAY_SIZE(s_secbtmode_emmc18));
    secbtmode |= s_secbtmode_emmc18[data[1]];

    ASSERT(data[2] < ARRAY_SIZE(s_secbtmode_emmc33));
    secbtmode |= s_secbtmode_emmc33[data[2]];

    ASSERT(data[3] < ARRAY_SIZE(s_secbtmode_spi18));
    secbtmode |= s_secbtmode_spi18[data[3]];

    ASSERT(data[4] < ARRAY_SIZE(s_secbtmode_spi33));
    secbtmode |= s_secbtmode_spi33[data[4]];

    s_wr_data[0] = secbtmode;

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t* info)
{
    info->sel.num_of_sels = ARRAY_SIZE(s_opts);

    info->sel.p_opts = s_opts;

    return SEL;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: otpsecbtmode
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void otpsecbtmode(st_setup_exec_t * exec)
{
    exec->p_name = "OTPSECBTMODE";
    exec->p_init = init;
    exec->p_save = save;
    exec->p_ref  = ref;
    exec->p_set  = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function otpsecbtmode
 *********************************************************************************************************************/
