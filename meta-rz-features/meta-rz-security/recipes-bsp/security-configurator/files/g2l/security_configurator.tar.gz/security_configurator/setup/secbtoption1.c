/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : secbtoption1.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/setup.h"
#include "include/otp_defs.h"
#include "include/drivers/otp_drv.h"

#include "setup_entry.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define OTP_NAME    (OTP_SYM_SECBTOPTION1)
#define OTP_SIZE    (1)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint32_t s_rd_data[OTP_SIZE];
static uint32_t s_wr_data[OTP_SIZE];

static uint32_t s_scifbtdis[] =
{
    0, OTP_SB_DIS_SCIF
};
static char_t * sp_scifbtdis_sentence[ARRAY_SIZE(s_scifbtdis)] =
{
    "Do not disable", "Disable"
};

static uint32_t s_failsafe[] =
{
    0, OTP_FAIL_SAFE_DIS
};
static char_t * sp_failsafe_sentence[ARRAY_SIZE(s_failsafe)] =
{
    "Do not disable", "Disable"
};

static st_setup_options_t s_opts[] =
{
    { ARRAY_SIZE(s_scifbtdis), s_scifbtdis, sp_scifbtdis_sentence, "Select whether to disable secure boot from SCIF."},
    { ARRAY_SIZE(s_failsafe),  s_failsafe,  sp_failsafe_sentence,  "Select whether to disable Failsafe Download."}
};

/**********************************************************************************************************************
 * Function Name: init
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init(void)
{
    memset((uint8_t *)s_rd_data, 0, sizeof(s_rd_data));
    memset((uint8_t *)s_wr_data, 0, sizeof(s_wr_data));

#if defined(CFG_OTP_SB_DIS_SCIF)
    s_wr_data[0] |= OTP_SB_DIS_SCIF;
#endif
#if defined(CFG_OTP_FAIL_SAFE_DIS)
    s_wr_data[0] |= OTP_FAIL_SAFE_DIS;
#endif
    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function init
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: save
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t save(void)
{
    return (otp_save(OTP_NAME, s_wr_data, ARRAY_SIZE(s_wr_data)));
}
/**********************************************************************************************************************
 * End of function save
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: ref
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t ref(int8_t mode, uint32_t** data, uint32_t* size)
{
    int32_t ret = SETUP_SUCCESS;

    *data = NULL;

    if (0 == mode)
    {
        ret = otp_load(OTP_NAME, s_rd_data, ARRAY_SIZE(s_rd_data));

        if (SETUP_SUCCESS == ret)
        {
            *data = &s_rd_data[0];
            *size = ARRAY_SIZE(s_rd_data);
        }
    }
    else
    {
        *data = &s_wr_data[0];
        *size = ARRAY_SIZE(s_wr_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function ref
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t set(uint32_t* data, uint32_t size)
{
    uint32_t secbtopt1 = 0;

    ASSERT(size == ARRAY_SIZE(s_opts));

    ASSERT(data[0] < ARRAY_SIZE(s_scifbtdis));
    secbtopt1 |= s_scifbtdis[data[0]];

    ASSERT(data[1] < ARRAY_SIZE(s_failsafe));
    secbtopt1 |= s_failsafe[data[1]];

    s_wr_data[0] = secbtopt1;

    return SETUP_SUCCESS;
}
/**********************************************************************************************************************
 * End of function set
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: type
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t type(u_setup_typeinfo_t* info)
{
    info->sel.num_of_sels = ARRAY_SIZE(s_opts);

    info->sel.p_opts = s_opts;

    return SEL;
}
/**********************************************************************************************************************
 * End of function type
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: secbtoption1
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void secbtoption1(st_setup_exec_t * exec)
{
    exec->p_name = "SECBTOPTION1";
    exec->p_init = init;
    exec->p_save = save;
    exec->p_ref  = ref;
    exec->p_set  = set;
    exec->p_type = type;
    return;
}
/**********************************************************************************************************************
 * End of function secbtoption1
 *********************************************************************************************************************/
