/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : scif_regs.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

#ifndef SCIF_REGS_H
#define SCIF_REGS_H
/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/* SCIF ch0 */
#define SCIF0_SMR       (RZG2L_SCIF0_BASE + 0x0000U)
#define SCIF0_BRR       (RZG2L_SCIF0_BASE + 0x0002U)
#define SCIF0_MDDR      (RZG2L_SCIF0_BASE + 0x0002U)
#define SCIF0_SCR       (RZG2L_SCIF0_BASE + 0x0004U)
#define SCIF0_FTDR      (RZG2L_SCIF0_BASE + 0x0006U)
#define SCIF0_FSR       (RZG2L_SCIF0_BASE + 0x0008U)
#define SCIF0_FRDR      (RZG2L_SCIF0_BASE + 0x000AU)
#define SCIF0_FCR       (RZG2L_SCIF0_BASE + 0x000CU)
#define SCIF0_FDR       (RZG2L_SCIF0_BASE + 0x000EU)
#define SCIF0_SPTR      (RZG2L_SCIF0_BASE + 0x0010U)
#define SCIF0_LSR       (RZG2L_SCIF0_BASE + 0x0012U)
#define SCIF0_SEMR      (RZG2L_SCIF0_BASE + 0x0014U)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif  /* SCIF_REGS_H */
