
ASSEMBLY	+=	./arch/arm/boot_mon.s 	\
				./arch/arm/stack.s		\
				./arch/arm/incbin.s

MKFILE		+=	./arch/arm/sub.mk
