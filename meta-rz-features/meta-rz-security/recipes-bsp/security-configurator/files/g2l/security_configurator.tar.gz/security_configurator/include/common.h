/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : common.h
 * Version      : 1.0
 * Description  : Common functions and macros
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>
#include <stddef.h>

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#ifndef COMMON_H
#define COMMON_H


#ifndef NULL
#define NULL    (0)
#endif

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

#define ARRAY_SIZE(_array)  (sizeof(_array) / sizeof((_array)[0]))

#define INT_CODE        (0x03)  /* CTRL+C */
#define BS_CODE         (0x08)  /* BackSpace */
#define LF_CODE         (0x0a)  /* Line Feed */
#define CR_CODE         (0x0d)  /* Carriage Return */
#define ESC_CODE        (0x1b)  /* Escape */
#define SP_CODE         (0x20)  /* Space */
#define DEL_CODE        (0x7f)  /* Delete */

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/
typedef char char_t;

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
extern int32_t put_char (char_t ch);
extern int32_t get_char (void);
extern int32_t put_str (const char_t * str, int8_t rtn);
extern int32_t get_str (char_t * str, size_t * len);
extern int32_t str_cmp (const char_t * str1, const char_t * str2);
extern int32_t strn_cmp (const char_t * str1, const char_t * str2, size_t len);
extern size_t  str_len (const char_t * str);
extern int32_t hex_to_ascii (uint32_t data, char_t * str, int8_t pad);
extern int32_t ascii_to_hex (char_t * str, uint32_t * data);
extern int32_t int_to_ascii (int32_t data, char_t * str);
extern void    to_upper (char_t * str);
extern void *  memcpy (uint8_t * dst, uint8_t * src, size_t len);
extern void *  memset (uint8_t * mem, int8_t ch, size_t len);
extern void    soft_delay (size_t loop);

#endif /* COMMON_H */
