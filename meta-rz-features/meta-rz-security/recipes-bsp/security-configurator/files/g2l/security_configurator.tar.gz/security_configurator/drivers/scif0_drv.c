/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : scif0_dev.c
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/bit.h"
#include "include/rzg2l_def.h"
#include "include/drivers/scif0_drv.h"
#include "include/drivers/scif_regs.h"
#include "include/drivers/cpg_regs.h"
#include "include/drivers/pfc_regs.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_power_on
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void scif0_power_on(void)
{
    volatile uint32_t dataL;

    dataL = (*(volatile uint32_t *)CPG_CLKMON_SCIF);

    if ((dataL & BIT0) == 0U)
    {
        /* case SCIF ch0 Standby */
        (*(volatile uint32_t *)CPG_CLKON_SCIF) = (BIT0 | BIT16);

        do
        {
            dataL = (*(volatile uint32_t *)CPG_CLKMON_SCIF);
        }
        while ((dataL & BIT0) == 0U); /* wait until bit0=1 */
    }

    dataL =  (*(volatile uint32_t *)CPG_RST_SCIF);
    dataL |= 0x00010001U;

    (*(volatile uint32_t *)CPG_RST_SCIF) = dataL;
    do
    {
        dataL = (*(volatile uint32_t *)CPG_RSTMON_SCIF);
    }
    while ((dataL & BIT0) == 1U); /* wait until bit0=1 */
}
/**********************************************************************************************************************
 * End of function scif0_power_on
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_init_pinfunc
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void scif0_init_pinfunc(void)
{
    uint8_t  dataB;
    uint32_t dataL;

    /* SCIF ch0 */
    dataL =  (*(volatile uint32_t *)CPG_CLKON_GPIO);
    dataL |= 0x00010001U;

    (*(volatile uint32_t *)CPG_CLKON_GPIO) = dataL;
    do
    {
        dataL = (*(volatile uint32_t *)CPG_CLKMON_GPIO);
    }
    while ((dataL & BIT0) == 0U); /* wait until bit0=1 */

    dataL =  (*(volatile uint32_t *)CPG_RST_GPIO);
    dataL |= 0x00070007U;

    (*(volatile uint32_t *)CPG_RST_GPIO) = dataL;
    do
    {
        dataL = (*(volatile uint32_t *)CPG_RSTMON_GPIO);
    }
    while ((dataL & BIT0) == 1U); /* wait until bit0=1 */

    dataL =  (*(volatile uint32_t *)PFC_PWPR);
    dataL &= (~0x00000080U); /* B0WI = 0(Enable) */

    (*(volatile uint32_t *)PFC_PWPR) = dataL;

    dataL |= 0x00000040U; /* PFCWE = 1(Enable) */

    (*(volatile uint32_t *)PFC_PWPR) = dataL;

    dataB =  (*(volatile uint8_t *)PFC_PMC36);
    dataB &= (~0x03U);
    dataB |= 0x03U; /* P38_0(TXD), P38_1(RXD) */

    (*(volatile uint8_t *)PFC_PMC36) = dataB;

    dataL =  (*(volatile uint32_t *)PFC_PFC36);
    dataL &= (~0x00000077U); /* P38_0(TXD), P38_1(RXD) */
    dataL |= 0x00000011U;

    (*(volatile uint32_t *)PFC_PFC36) = dataL;
}
/**********************************************************************************************************************
 * End of function scif0_init_pinfunc
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_put_char
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t scif0_put_char(char_t outChar)
{
    while (!(0x60U & (*(volatile uint16_t *)SCIF0_FSR)))
    {
        ;
    }
    (*(volatile uint8_t *)SCIF0_FTDR) =  outChar;
    (*(volatile uint16_t *)SCIF0_FSR) &= (~0x60U); /* TEND,TDFE clear */
    return (0);
}
/**********************************************************************************************************************
 * End of function scif0_put_char
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_get_char
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t scif0_get_char(char_t *inChar)
{
    do
    {
        if (0x91U & (*(volatile uint16_t *)SCIF0_FSR))
        {
            (*(volatile uint16_t *)SCIF0_FSR) &= (~0x91U);
        }
        if (0x01U & (*(volatile uint16_t *)SCIF0_LSR))
        {
            put_str("ORER", 1);
            (*(volatile uint16_t *)SCIF0_LSR) &= (~0x01U);
        }
    }
    while (!(0x02U & (*(volatile uint16_t *)SCIF0_FSR)));

    *inChar = (*(volatile uint8_t *)SCIF0_FRDR);

    (*(volatile uint16_t *)SCIF0_FSR) &= (~0x02U);

    return (0);
}
/**********************************************************************************************************************
 * End of function scif0_get_char
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_put_wait_end
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void scif0_put_wait_end(void)
{
    volatile uint16_t dataW;

    while (1)
    {
        dataW = (*(volatile uint16_t *)SCIF0_FSR);
        if (dataW & BIT6)
        {
            break;
        }
    }
}
/**********************************************************************************************************************
 * End of function scif0_put_wait_end
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: scif0_init_clock
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
void scif0_init_clock(void)
{
    volatile uint16_t dataW;

    uint32_t prr;

    scif0_power_on();

    scif0_init_pinfunc();

    dataW = (*(volatile uint16_t *)SCIF0_LSR); /* dummy read           */

    (*(volatile uint16_t *)SCIF0_LSR) = 0x0000U; /* clear ORER bit       */
    (*(volatile uint16_t *)SCIF0_FSR) = 0x0000U; /* clear all error bit  */

    (*(volatile uint16_t *)SCIF0_SCR) = 0x0000U; /* clear SCR.TE & SCR.RE*/
    (*(volatile uint16_t *)SCIF0_FCR) = 0x0006U; /* reset tx-fifo, reset rx-fifo. */
    (*(volatile uint16_t *)SCIF0_FSR) = 0x0000U; /* clear ER, TEND, TDFE, BRK, RDF, DR */

    (*(volatile uint16_t *)SCIF0_SCR) = 0x0000U; /* internal clock P1/1 */
    (*(volatile uint16_t *)SCIF0_SMR) = 0x0000U; /* 8bit data, no-parity, 1 stop, Po/1 */
    (*(volatile uint8_t *)SCIF0_SEMR) = 0x00U;
    soft_delay(100);

    (*(volatile uint8_t *)SCIF0_BRR)  = 0x1AU; /* 115200bps */
    (*(volatile uint8_t *)SCIF0_SEMR) = 0x10U;
    soft_delay(100);

    (*(volatile uint16_t *)SCIF0_FCR) = 0x0000U; /* reset-off tx-fifo, rx-fifo. */
    (*(volatile uint16_t *)SCIF0_SCR) = 0x0030U; /* enable TE, RE  */

    soft_delay(100);
}
/**********************************************************************************************************************
 * End of function scif0_init_clock
 *********************************************************************************************************************/
