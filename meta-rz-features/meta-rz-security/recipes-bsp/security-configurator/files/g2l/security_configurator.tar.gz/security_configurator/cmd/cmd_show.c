/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : cmd_show.c
 * Version      : 1.0
 * Description  : show OTP data table
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/command.h"
#include "include/setup.h"

#include "command_private.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define COLUMN_NUM      (3)
#define HRZN_MARGIN     (1)
#define VERT_MARGIN     (0)
#define LEFT_MARGIN     (2)

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/
typedef enum {
    TXT_STR,
    HEX_U32
} e_view_type_t;

typedef struct {
    uint8_t  * p_row;
    uint32_t height;
    uint32_t stride;
    uint32_t columns;
} st_row_area_t;

typedef struct {
    uint8_t  * p_field;
    uint32_t width;
    uint32_t height;
    uint32_t stride;
} st_field_area_t;

typedef struct {
    void     * p_data;
    uint32_t size;
    uint8_t  view_type;
} st_view_item_t;

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static const uint32_t s_column_width[COLUMN_NUM] = {16, 21, 21};
static const int8_t * const sp_tbl_hdr[COLUMN_NUM] = {"Name", "Read", "Write"};

static st_row_area_t s_row_area;
static uint8_t * sp_row_area_buff;

/**********************************************************************************************************************
 * Function Name: new_row_area
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void new_row_area(uint32_t columns)
{
    uint32_t stride = 0;

    uint32_t buffer_length;

    for (int32_t i = 0; (i < COLUMN_NUM); i++)
    {
        stride += (s_column_width[i] + (((HRZN_MARGIN * 2) + 1) + LEFT_MARGIN));
    }

    buffer_length    = sizeof(g_command_work_buf);
    sp_row_area_buff = (uint8_t*) &g_command_work_buf[0];

    s_row_area.p_row   = sp_row_area_buff;
    s_row_area.stride  = stride + 2;
    s_row_area.height  = (buffer_length / s_row_area.stride);
    s_row_area.columns = columns;

    return;
}
/**********************************************************************************************************************
 * End of function new_row_area
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init_cell_field
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void init_cell_field(st_field_area_t *cell_field, int32_t offset)
{
    for (int32_t i = 0; (i < s_row_area.height); i++)
    {
        int8_t * p_top = &s_row_area.p_row[s_row_area.stride * i];

        memset(p_top, ' ', s_row_area.stride - 1);

        *(p_top + (s_row_area.stride - 1)) = '\0';
    }

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        cell_field[i].p_field = s_row_area.p_row + offset + LEFT_MARGIN;
        cell_field[i].width   = s_column_width[i] + (HRZN_MARGIN * 2) + 2;
        cell_field[i].stride  = s_row_area.stride;
        cell_field[i].height  = s_row_area.height;

        offset += (cell_field[i].width - 1);
    }

    return;
}
/**********************************************************************************************************************
 * End of function init_cell_field
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_hex_u32
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t draw_hex_u32(st_field_area_t* field_area, const uint32_t* hex, uint32_t size)
{
    char_t   str[16];
    uint32_t num_cols;
    uint32_t hex_str_len;
    uint32_t prefix_len;

    char_t   * p_prefix = "0x";

    uint32_t count  = 0;
    uint32_t height = 0;

    prefix_len = str_len(p_prefix);

    hex_str_len = prefix_len + 8;

    num_cols = 1 + (uint32_t)((field_area->width - hex_str_len) / (hex_str_len + 1));

    if (NULL != hex)
    {
        height = (size + (num_cols - 1)) / num_cols;

        if (height > field_area->height)
        {
            height = field_area->height;
        }
    }

    for (int32_t y = 0; (y < height); y++)
    {
        char_t * p_ptr = field_area->p_field + (y * field_area->stride);

        int32_t width = field_area->width;

        for (int32_t x = 0; ((x < num_cols) && (count < size)); x++, count++)
        {
            memcpy(str, p_prefix, prefix_len);

            hex_str_len = hex_to_ascii(hex[count], &str[prefix_len], 1) + prefix_len;

            if (hex_str_len > width)
            {
                hex_str_len = width;
            }

            for (int32_t i = 0; (i < hex_str_len); i++)
            {
                *(p_ptr + i) = *(str + i);
            }

            width -= hex_str_len;

            p_ptr += (hex_str_len + 1);
        }
    }

    field_area->height = height;

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_hex_u32
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_txt_str
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int draw_txt_str(st_field_area_t *field_area, const char_t* str)
{
    uint32_t line   = 0;
    uint32_t count  = 0;
    uint32_t strlen = 0;
    uint32_t height = 0;

    if (NULL != str)
    {
        strlen = str_len(str);

        height = field_area->height;
    }

    for (line = count = 0; ((line < height) && (count < strlen)); line++)
    {
        int32_t new_line = 0;

        char_t * p_ptr = field_area->p_field + (line * field_area->stride);

        for (int32_t x = 0; ((x < field_area->width) && (count < strlen) && (0 == new_line)); x++)
        {
            char_t ch = str[count++];

            if ('\n' == ch)
            {
                new_line = 1;
            }
            else
            {
                *p_ptr = ch;
                p_ptr++;
            }

        }
    }

    field_area->height = line;

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_txt_str
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init_item_field
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t init_item_field(st_field_area_t* item_field, st_field_area_t *cell_field)
{
    item_field->p_field = cell_field->p_field + (((VERT_MARGIN * cell_field->stride) + HRZN_MARGIN) + 1);
    item_field->width   = cell_field->width - ((HRZN_MARGIN * 2) + 2);
    item_field->stride  = cell_field->stride;
    item_field->height  = cell_field->height - 1;
    return 0;
}
/**********************************************************************************************************************
 * End of function init_item_field
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_view_hdr
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t draw_view_hdr(st_field_area_t *cell_fields)
{
    uint32_t item_height = 1;

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        st_field_area_t item_field;

        init_item_field(&item_field, &cell_fields[i]);

        draw_txt_str(&item_field, sp_tbl_hdr[i]);

        if (item_height < item_field.height)
        {
            item_height = item_field.height;
        }
    }

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        cell_fields[i].height = item_height + (VERT_MARGIN * 2) + 1;
    }

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_view_hdr
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_view_item
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t draw_view_item(st_field_area_t *cell_fields, st_view_item_t *view_item)
{
    uint32_t item_height = 1;

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        st_field_area_t item_field;

        init_item_field(&item_field, &cell_fields[i]);

        switch (view_item[i].view_type)
        {
            case TXT_STR:
                draw_txt_str(&item_field, (char_t *)view_item[i].p_data);
                break;

            case HEX_U32:
                draw_hex_u32(&item_field, view_item[i].p_data, view_item[i].size);
                break;

            default:
                break;
        }

        if (item_height < item_field.height)
        {
            item_height = item_field.height;
        }
    }

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        cell_fields[i].height = item_height + (VERT_MARGIN * 2) + 1;
    }

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_view_item
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_horizontal_line
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void draw_horizontal_line(uint8_t *ptr, uint32_t width)
{
    for (int32_t i = 0; (i < width); i++)
    {
        *(ptr + i) = 0x2d; /* '-' */
    }

    *ptr = 0x2b; /* '+' */

    *(ptr + (width - 1)) = 0x2b; /* '+' */

    return;
}
/**********************************************************************************************************************
 * End of function draw_horizontal_line
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_vertical_line
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void draw_vertical_line(uint8_t *adr, uint32_t height, uint32_t stride)
{
    for (int32_t i = 0; (i < height); i++)
    {
        *(adr + (i * stride)) = 0x7c; /* '|' */
    }
    return;
}
/**********************************************************************************************************************
 * End of function draw_vertical_line
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_field_line
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void draw_field_line(st_field_area_t *cell_field)
{
    draw_vertical_line(cell_field->p_field, cell_field->height, cell_field->stride);
    draw_vertical_line(cell_field->p_field + (cell_field->width - 1), cell_field->height, cell_field->stride);
    draw_horizontal_line(cell_field->p_field + ((cell_field->height - 1) * cell_field->stride), cell_field->width);
    return;
}
/**********************************************************************************************************************
 * End of function draw_field_line
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_display
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static void draw_display(uint8_t* ptr, uint32_t stride, uint32_t height)
{
    for (int32_t y = 0; (y < height); y++)
    {
        put_str(ptr + (stride * y), 1);
    }
    return;
}
/**********************************************************************************************************************
 * End of function draw_display
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_table_new
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t draw_table_new(void)
{
    st_field_area_t cell_fields[COLUMN_NUM];

    new_row_area(COLUMN_NUM);

    init_cell_field(cell_fields, s_row_area.stride);

    draw_view_hdr(cell_fields);

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        draw_field_line(&cell_fields[i]);

        draw_horizontal_line(cell_fields[i].p_field - cell_fields[i].stride, cell_fields[i].width);
    }

    draw_display(s_row_area.p_row, s_row_area.stride, cell_fields[0].height + 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_table_new
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_table_add
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
static int32_t draw_table_add(st_view_item_t* view_item)
{
    st_field_area_t cell_fields[COLUMN_NUM];

    init_cell_field(cell_fields, 0);

    draw_view_item(cell_fields, view_item);

    for (int32_t i = 0; (i < s_row_area.columns); i++)
    {
        draw_field_line(&cell_fields[i]);
    }

    draw_display(s_row_area.p_row, s_row_area.stride, cell_fields[0].height);

    return 0;
}
/**********************************************************************************************************************
 * End of function draw_table_add
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: cmd_show
 * Description  :
 * Arguments    :
 * Return Value :
 *********************************************************************************************************************/
int32_t cmd_show(void)
{
    int32_t first_call = 0;

    put_str("", 1);
    put_str("<<<< Command to show setup data >>>>", 1);
    put_str("", 1);

    for (int32_t i = 0; (i < gp_setup->num); i++)
    {
        int32_t err;

        st_view_item_t view_item[COLUMN_NUM];

        memset((uint8_t *)&view_item, 0, sizeof(view_item));

        if (NULL != gp_setup->exec[i].p_ref)
        {
            if (0 == first_call)
            {
                draw_table_new();
                first_call = 1;
            }

            view_item[0].view_type = TXT_STR;
            view_item[1].view_type = HEX_U32;
            view_item[2].view_type = HEX_U32;

            view_item[0].p_data    = gp_setup->exec[i].p_name;

            err = gp_setup->exec[i].p_ref(0, (uint32_t * *)&view_item[1].p_data, &view_item[1].size);

            if ((NULL == view_item[1].p_data) && (SETUP_SUCCESS != err))
            {
                view_item[1].p_data    = setup_errstr(err);
                view_item[1].view_type = TXT_STR;
            }

            err = gp_setup->exec[i].p_ref(1, (uint32_t * *)&view_item[2].p_data, &view_item[2].size);

            if ((NULL == view_item[2].p_data) && (SETUP_SUCCESS != err))
            {
                view_item[2].p_data    = setup_errstr(err);
                view_item[2].view_type = TXT_STR;
            }

            draw_table_add(view_item);
        }
    }

    if (0 == first_call)
    {
        put_str(" Warning: The drawing item cannot be found.", 1);
    }

    put_str("", 1);

    return 0;
}
/**********************************************************************************************************************
 * End of function cmd_show
 *********************************************************************************************************************/
