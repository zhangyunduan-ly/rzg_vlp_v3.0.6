/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : message.c
 * Version      : 1.0
 * Description  : Show welcome message
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "include/common.h"
#include "include/debug.h"
#include "include/version.h"
#include "include/message.h"
#include "include/drivers/sysc.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_msg_rzg2l
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
static void show_msg_rzg2l(void)
{
#if   (RZG2L == 1)
    put_str(" Product Code : RZ/G2L", 1);
#elif (RZG2LC == 1)
    put_str(" Product Code : RZ/G2LC", 1);
#else
    ASSERT(FALSE);
#endif
    return;
}
/**********************************************************************************************************************
 * End of function show_msg_rzg2l
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_msg_rzg2ul
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
static void show_msg_rzg2ul(void)
{
    put_str(" Product Code : RZ/G2UL", 1);
    return;
}
/**********************************************************************************************************************
 * End of function show_msg_rzv2l
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_msg_rzv2l
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
static void show_msg_rzv2l(void)
{
    put_str(" Product Code : RZ/V2L", 1);
    return;
}
/**********************************************************************************************************************
 * End of function show_msg_rzv2l
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: show_welcome_msg
 * Description  :
 * Arguments    : none
 * Return Value : none
 *********************************************************************************************************************/
void show_welcome_msg(void)
{
    uint32_t device_id = sysc_get_device_id();

    put_str("", 1);
    put_str(" Security Configurator : " VERSION " " DATE, 1);

    switch (device_id)
    {
        case RZG2L_DEVID:
            show_msg_rzg2l();
            break;

        case RZG2UL_DEVID:
            show_msg_rzg2ul();
            break;

        case RZV2L_DEVID:
            show_msg_rzv2l();
            break;

        default:
            put_str("", 1);
            put_str(" error: Unknown device ID.", 1);
            ASSERT(FALSE);
            break;
    }
    put_str("", 1);

    return;
}
/**********************************************************************************************************************
 * End of function show_welcome_msg
 *********************************************************************************************************************/
