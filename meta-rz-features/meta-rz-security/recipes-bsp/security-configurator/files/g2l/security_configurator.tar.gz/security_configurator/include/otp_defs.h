/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : otp_defs.h
 * Version      : 1.0
 * Description  :
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

#ifndef OTP_DEFS_H
#define OTP_DEFS_H

#define OTP_SECBT_EN        (0x00000001)

#define OTP_AUTH_MD_NONE    (0x00000000)
#define OTP_AUTH_MD_SECIP   (0x00000002)
#define OTP_AUTH_MD_REJECT  (0x00000003)

#define OTP_OTR_EN_0        (0x00000001)
#define OTP_OTR_EN_1        (0x00000002)
#define OTP_OTR_EN_2        (0x00000004)
#define OTP_OTR_EN_3        (0x00000008)
#define OTP_OTR_EN_4        (0x00000010)
#define OTP_OTR_EN_5        (0x00000020)
#define OTP_OTR_EN_6        (0x00000040)
#define OTP_OTR_EN_7        (0x00000080)

#define OTP_SB_DIS_SD       (0x00000001)
#define OTP_SB_DIS_EMMC18   (0x00000002)
#define OTP_SB_DIS_EMMC33   (0x00000004)
#define OTP_SB_DIS_SPI18    (0x00000008)
#define OTP_SB_DIS_SPI33    (0x00000010)

#define OTP_WP_AUTH_ID      (0x00000001)
#define OTP_RP_AUTH_ID      (0x00000001)

#define OTP_WP_FUNC         (0x00000001)

#define OTP_RAC_DIS         (0x00000001)
#define OTP_TAC_DIS         (0x00000001)

#define OTP_ANTI_RB_EN      (0x00010000)
#define OTP_WR_ANTI_VER     (0x01000000)

#define OTP_SB_DIS_SCIF     (0x00000001)
#define OTP_FAIL_SAFE_DIS   (0x00010000)

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* OTP_DEFS_H */
