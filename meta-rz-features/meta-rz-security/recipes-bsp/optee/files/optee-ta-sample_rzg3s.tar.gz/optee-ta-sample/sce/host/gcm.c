// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2024, Renesas Electronics
 */

#include <err.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the TA's h-file(s)) */
#include <pta_rsip_aes.h>

#define AES_BLOCK_SIZE      (16)
#define KEY_BUFFER_SIZE     (RSIP_BYTE_SIZE_WRAPPED_KEY_AES_MAX)
#define DAT_BUFFER_SIZE     (AES_BLOCK_SIZE * 16)

#define GCM_ENC_MODE        (1)
#define GCM_DEC_MODE        (0)

struct gcm_info {
    char *aes_opt;
    uint32_t init;
    uint32_t update;
    uint32_t final;
    uint32_t mode;
};

/* TEE resources */
struct sample_ctx {
    TEEC_Context ctx;
    TEEC_Session sess;
    uint32_t init;
    uint32_t update;
    uint32_t final;
    uint32_t mode;
    char *inp_file;
    char *out_file;
    char *wuk_file;
    char *aad_file;
    char *tag_file;
};

extern int load_file(char *file_name, uint32_t *buf, uint32_t *buf_sz);
extern int save_file(char *file_name, uint32_t *buf, uint32_t buf_sz);

static struct gcm_info gcm_list[] = {
    {"aes128gcm_enc", PTA_CMD_AES128GCM_EncryptInit, PTA_CMD_AES128GCM_EncryptUpdate, PTA_CMD_AES128GCM_EncryptFinal, GCM_ENC_MODE},
    {"aes128gcm_dec", PTA_CMD_AES128GCM_DecryptInit, PTA_CMD_AES128GCM_DecryptUpdate, PTA_CMD_AES128GCM_DecryptFinal, GCM_DEC_MODE},
    {"aes256gcm_enc", PTA_CMD_AES256GCM_EncryptInit, PTA_CMD_AES256GCM_EncryptUpdate, PTA_CMD_AES256GCM_EncryptFinal, GCM_ENC_MODE},
    {"aes256gcm_dec", PTA_CMD_AES256GCM_DecryptInit, PTA_CMD_AES256GCM_DecryptUpdate, PTA_CMD_AES256GCM_DecryptFinal, GCM_DEC_MODE},
    {}
};

static uint32_t inp_buff[DAT_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t out_buff[DAT_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t aad_buff[DAT_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t wuk_buff[KEY_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t iv0_buff[AES_BLOCK_SIZE  / sizeof(uint32_t)];
static uint32_t tag_buff[AES_BLOCK_SIZE / sizeof(uint32_t)];

static void usage(char *program)
{
    fprintf(stderr, "AES Encryption\n");
    fprintf(stderr, "Usage: %s -b [-t <ALGO>] <KEY> <PLAIN> <CIPHER> <AAD>\n", program);
    fprintf(stderr, "\t-t <ALGO>        AES Encryption Algorithm. \n");
    fprintf(stderr, "\t                 Use default \"aes128gcm_enc\" if not set.\n");
    fprintf(stderr, "\t                 - \"aes128gcm_enc\", \"aes256gcm_enc\" \n");
    fprintf(stderr, "\t<KEY>            Specify the file name of the wrapped AES key. \n");
    fprintf(stderr, "\t<PLAIN>          Specify the file name of the plain data to input. \n");
    fprintf(stderr, "\t<CIPHER>         Specify the file name of the cipher data to be output. \n");
    fprintf(stderr, "\t<AAD>            Specify the file name of the aad data to input. \n");
    fprintf(stderr, "\t<TAG>            Specify the file name of the tag data to input. \n");
    fprintf(stderr, "\n");
    fprintf(stderr, "AES Decryption\n");
    fprintf(stderr, "Usage: %s -a [-t <ALGO>] <KEY> <CIPHER> <PLAIN> <AAD> \n", program);
    fprintf(stderr, "\t-t <ALGO>        AES Encryption Algorithm. \n");
    fprintf(stderr, "\t                 - \"aes128gcm_dec\", \"aes256gcm_dec\" \n");
    fprintf(stderr, "\t<KEY>            Specify the file name of the wrapped AES key. \n");
    fprintf(stderr, "\t<CIPHER>         Specify the file name of the cipher data to input. \n");
    fprintf(stderr, "\t<PLAIN>          Specify the file name of the plain data to be output. \n");
    fprintf(stderr, "\t<AAD>            Specify the file name of the aad data to input. \n");
    fprintf(stderr, "\t<TAG>            Specify the file name of the tag data to input. \n");
    fprintf(stderr, "\n");
    exit(1);
}

static void get_args(int argc, char *argv[], struct sample_ctx *ctx)
{
    int opt;
    char *aes_opt = "aes128gcm_enc";
    struct gcm_info *info = NULL;

    while (-1 != (opt = getopt(argc, argv, "t:h"))) {      
        switch (opt) {
        case 't':
            aes_opt = optarg;
            break;
        case 'h' :
            usage(argv[0]);
            break;
        default:
            usage(argv[0]);
            break;
        }
    }

    for (int i = 0; NULL != gcm_list[i].aes_opt; i++) {
        if (!strcasecmp(aes_opt, gcm_list[i].aes_opt)) {
            info = &gcm_list[i];
            break;
        }
    }
    if (NULL == info) {
        fprintf(stderr, "Bad <ALGO> \"%s\" \n", aes_opt);
        usage(argv[0]);
    }
    
    if ((optind + 5) > argc) {
        fprintf(stderr, "Cannot find <KEY>, <PLAIN>, <CIPHER>, <AAD> or <TAG> \n");
        usage(argv[0]);
    }

    ctx->init     = info->init;
    ctx->update   = info->update;
    ctx->final    = info->final;
    ctx->mode     = info->mode;
    ctx->wuk_file = argv[optind];
    ctx->inp_file = argv[optind + 1];
    ctx->out_file = argv[optind + 2];
    ctx->aad_file = argv[optind + 3];
    ctx->tag_file = argv[optind + 4];
}

static int prepare_tee_session(struct sample_ctx *ctx)
{
    TEEC_UUID uuid = PTA_RSIP_AES_UUID;
    uint32_t origin;
    TEEC_Result res;

    /* Initialize a context connecting us to the TEE */
    res = TEEC_InitializeContext(NULL, &ctx->ctx);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InitializeContext failed with code 0x%x\n", res);
        return -1;
    }

    /* Open a session with the TA */
    res = TEEC_OpenSession(&ctx->ctx, &ctx->sess, &uuid,
                   TEEC_LOGIN_PUBLIC, NULL, NULL, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_Opensession failed with code 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static void terminate_tee_session(struct sample_ctx *ctx)
{
    TEEC_CloseSession(&ctx->sess);
    TEEC_FinalizeContext(&ctx->ctx);
}

static int set_init_vec(struct sample_ctx *ctx, uint32_t *iv, uint32_t *iv_sz)
{
    if (AES_BLOCK_SIZE > *iv_sz) {
        fprintf(stderr, "Initial vector length is less than 16 bytes.\n");
        return -1;
    }
    memset(iv, 0xa5, AES_BLOCK_SIZE);
    *iv_sz = AES_BLOCK_SIZE;
    return 0;
}

static int gcm_init(struct sample_ctx *ctx, uint32_t *wuk, uint32_t wuk_sz, uint32_t *iv,
    uint32_t iv_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    if (0 == iv_sz)
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_NONE, 
            TEEC_NONE, TEEC_NONE);
    else
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_INPUT, 
            TEEC_NONE, TEEC_NONE);
    
    op.params[0].tmpref.buffer = wuk;
    op.params[0].tmpref.size = wuk_sz;
    op.params[1].tmpref.buffer = iv;
    op.params[1].tmpref.size = iv_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->init, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(INIT) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static int gcm_update(struct sample_ctx *ctx, uint32_t *in, uint32_t in_sz, uint32_t *out, 
    uint32_t *out_sz, uint32_t *aad, uint32_t aad_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_INOUT, 
        TEEC_MEMREF_TEMP_INPUT, TEEC_NONE);

    op.params[0].tmpref.buffer = in;
    op.params[0].tmpref.size = in_sz;
    op.params[1].tmpref.buffer = out;
    op.params[1].tmpref.size = *out_sz;
    op.params[2].tmpref.buffer = aad;
    op.params[2].tmpref.size = aad_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->update, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(UPDATE) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *out_sz = op.params[1].tmpref.size;
    return 0;
}

static int gcm_final(struct sample_ctx *ctx, uint32_t *fra, uint32_t *fra_sz, uint32_t *tag, uint32_t tag_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    if (GCM_ENC_MODE == ctx->mode)
    {
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INOUT, TEEC_NONE, TEEC_NONE);
    }
    else
    {
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INPUT, TEEC_NONE, TEEC_NONE);
    }

    op.params[0].tmpref.buffer = fra;
    op.params[0].tmpref.size = *fra_sz;
    op.params[1].tmpref.buffer = tag;
    op.params[1].tmpref.size = tag_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->final, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(FINAL) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *fra_sz = op.params[0].tmpref.size;
    return 0;
}

static int cipher_buffer(struct sample_ctx *ctx, uint32_t *wuk, uint32_t wuk_sz, uint32_t *in, uint32_t in_sz, 
    uint32_t *out, uint32_t *out_sz, uint32_t *aad, uint32_t aad_sz, uint32_t *iv, uint32_t iv_sz, uint32_t *tag, uint32_t tag_sz)
{
    int res;
    int err;
    uint32_t out_szwk = *out_sz;
    uint32_t *out_offset;

    res = gcm_init(ctx, wuk, wuk_sz, iv, iv_sz);
    if (res) 
        return res;

    err = gcm_update(ctx, in, in_sz, out, out_sz, aad, aad_sz);
    if (err)
        res = err;

    out_offset = (uint32_t *)(out + (((*out_sz / AES_BLOCK_SIZE) * AES_BLOCK_SIZE) / sizeof(uint32_t)));

    err = gcm_final(ctx, out_offset, &out_szwk, tag, tag_sz);
    if (!res)
        res = err;

    return res;
}

int gcm_main(int argc, char *argv[])
{
    int res;
    struct sample_ctx ctx;

    uint32_t inp_size = sizeof(inp_buff);
    uint32_t out_size = sizeof(out_buff);
    uint32_t aad_size = sizeof(aad_buff);
    uint32_t wuk_size = sizeof(wuk_buff);
    uint32_t iv0_size = sizeof(iv0_buff);
    uint32_t tag_size = sizeof(tag_buff);

    memset(inp_buff, 0, sizeof(inp_buff));
    memset(out_buff, 0, sizeof(out_buff));
    memset(aad_buff, 0, sizeof(aad_buff));
    memset(wuk_buff, 0, sizeof(wuk_buff));
    memset(iv0_buff, 0, sizeof(iv0_buff));
    memset(tag_buff, 0, sizeof(tag_buff));

    printf("Parse command line options\n");
    get_args(argc, argv, &ctx);

    printf("Prepare session with the TA\n");
    res = prepare_tee_session(&ctx);
    if (res)
        goto err;

    printf("Load the wrapped aes key \"%s\"\n", ctx.wuk_file);
    res = load_file(ctx.wuk_file, wuk_buff, &wuk_size);
    if (res)
        goto err;

    printf("Load the input data from file \"%s\"\n", ctx.inp_file);
    res = load_file(ctx.inp_file, inp_buff, &inp_size);
    if (res)
        goto err;

    printf("Load the aad data from file \"%s\"\n", ctx.aad_file);
    res = load_file(ctx.aad_file, aad_buff, &aad_size);
    if (res)
        goto err;
    
    printf("Set the initialization vector\n");
    res = set_init_vec(&ctx, iv0_buff, &iv0_size);
    if (res)
        goto err;

    if (GCM_ENC_MODE == ctx.mode) {
        printf("Encode buffer from TA\n");
        res = cipher_buffer(&ctx, wuk_buff, wuk_size, inp_buff, inp_size, out_buff, &out_size,
            aad_buff, aad_size, iv0_buff, iv0_size, tag_buff, tag_size);
        if (res)
            goto err;

        printf("Save the tag data to file \"%s\"\n", ctx.tag_file);
        res = save_file(ctx.tag_file, tag_buff, tag_size);
        if (res)
            goto err;
    }
    else {
        printf("Load the tag data from file \"%s\"\n", ctx.tag_file);
        res = load_file(ctx.tag_file, tag_buff, &tag_size);
        if (res)
            goto err;

        printf("Decode buffer from TA\n");
        res = cipher_buffer(&ctx, wuk_buff, wuk_size, inp_buff, inp_size, out_buff, &out_size,
            aad_buff, aad_size, iv0_buff, iv0_size, tag_buff, tag_size);
        if (res)
            goto err;
    }

    printf("Save the output data to file \"%s\"\n", ctx.out_file);
    res = save_file(ctx.out_file, out_buff, out_size);
    if (res)
        goto err;

err:
    terminate_tee_session(&ctx);
    return 0;
}
