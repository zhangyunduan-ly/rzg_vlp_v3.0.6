// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2024, Renesas Electronics
 */

#include <err.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the TA's h-file(s)) */
#include <pta_rsip_hmac.h>

#define MAC_BUFFER_SIZE     (32)
#define KEY_BUFFER_SIZE     (512)
#define DAT_BUFFER_SIZE     (1024)

#define MAC_GEN_MODE        (1)
#define MAC_VER_MODE        (0)

struct mac_info {
    char *mac_opt;
    uint32_t init;
    uint32_t update;
    uint32_t final;
    uint32_t mode;
};

/* TEE resources */
struct sample_ctx {
    TEEC_Context ctx;
    TEEC_Session sess;
    rsip_hmac_handle_t hmac;
    uint32_t init;
    uint32_t update;
    uint32_t final;
    uint32_t mode;
    char *msg_file;
    char *mac_file;
    char *wuk_file;
};

extern int load_file(char *file_name, uint32_t *buf, uint32_t *buf_sz);
extern int save_file(char *file_name, uint32_t *buf, uint32_t buf_sz);

static struct mac_info mac_list[] = {
    {"hmacsha1_gen",   PTA_CMD_HMAC_SHA1_GenerateInit,   PTA_CMD_HMAC_SHA1_GenerateUpdate,   PTA_CMD_HMAC_SHA1_GenerateFinal,   MAC_GEN_MODE},
    {"hmacsha1_ver",   PTA_CMD_HMAC_SHA1_VerifyInit,     PTA_CMD_HMAC_SHA1_VerifyUpdate,     PTA_CMD_HMAC_SHA1_VerifyFinal,     MAC_VER_MODE},
    {"hmacsha224_gen", PTA_CMD_HMAC_SHA224_GenerateInit, PTA_CMD_HMAC_SHA224_GenerateUpdate, PTA_CMD_HMAC_SHA224_GenerateFinal, MAC_GEN_MODE},
    {"hmacsha224_ver", PTA_CMD_HMAC_SHA224_VerifyInit,   PTA_CMD_HMAC_SHA224_VerifyUpdate,   PTA_CMD_HMAC_SHA224_VerifyFinal,   MAC_VER_MODE},
    {"hmacsha256_gen", PTA_CMD_HMAC_SHA256_GenerateInit, PTA_CMD_HMAC_SHA256_GenerateUpdate, PTA_CMD_HMAC_SHA256_GenerateFinal, MAC_GEN_MODE},
    {"hmacsha256_ver", PTA_CMD_HMAC_SHA256_VerifyInit,   PTA_CMD_HMAC_SHA256_VerifyUpdate,   PTA_CMD_HMAC_SHA256_VerifyFinal,   MAC_VER_MODE},
    {}
};

static uint32_t msg_buff[DAT_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t mac_buff[MAC_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t wuk_buff[KEY_BUFFER_SIZE / sizeof(uint32_t)];

static void usage(char *program)
{
    fprintf(stderr, "MAC Generation\n");
    fprintf(stderr, "Usage: %s -c [-t <ALGO>] <KEY> <MESSAGE> <MAC> \n", program);
    fprintf(stderr, "\t-t <ALGO>        HMAC Generation Algorithm. \n");
    fprintf(stderr, "\t                 Use default \"hmacsha1_gen\" if not set.\n");
    fprintf(stderr, "\t                 - \"hmacsha1_gen\", \"hmacsha224_gen\", \"hmacsha256_gen\" \n");
    fprintf(stderr, "\t<KEY>            Specify the file name of the wrapped HMAC-SHA key. \n");
    fprintf(stderr, "\t<MESSAGE>        Specify the file name of the message to input. \n");
    fprintf(stderr, "\t<MAC>            Specify the file name of the mac to be output. \n");
    fprintf(stderr, "\n");
    fprintf(stderr, "MAC Verification\n");
    fprintf(stderr, "Usage: %s -m [-t <ALGO>] <KEY> <CIPHER> <PLAIN> \n", program);
    fprintf(stderr, "\t-t <ALGO>        HMAC Verification Algorithm. \n");
    fprintf(stderr, "\t                 - \"hmacsha1_ver\", \"hmacsha224_ver\", \"hmacsha256_ver\" \n");
    fprintf(stderr, "\t<KEY>            Specify the file name of the wrapped HMAC-SHA key. \n");
    fprintf(stderr, "\t<MESSAGE>        Specify the file name of the message to input. \n");
    fprintf(stderr, "\t<MAC>            Specify the file name of the mac to be input. \n");
    fprintf(stderr, "\n");
    exit(1);
}

static void get_args(int argc, char *argv[], struct sample_ctx *ctx)
{
    int opt;
    char *mac_opt = "hmacsha1_gen";
    struct mac_info *info = NULL;
    

    while (-1 != (opt = getopt(argc, argv, "t:h"))) {      
        switch (opt) {
        case 't':
            mac_opt = optarg;
            break;
        case 'h' :
            usage(argv[0]);
            break;
        default:
            usage(argv[0]);
            break;
        }
    }

    for (int i = 0; NULL != mac_list[i].mac_opt; i++) {
        if (!strcasecmp(mac_opt, mac_list[i].mac_opt)) {
            info = &mac_list[i];
            break;
        }
    }
    if (NULL == info) {
        fprintf(stderr, "Bad <ALGO> \"%s\" \n", mac_opt);
        usage(argv[0]);
    }
    
    if ((optind + 3) > argc) {
        fprintf(stderr, "Cannot find <KEY>, <MESSAGE> or <MAC> \n");
        usage(argv[0]);
    }

    ctx->init     = info->init;
    ctx->update   = info->update;
    ctx->final    = info->final;
    ctx->mode     = info->mode;
    ctx->wuk_file = argv[optind];
    ctx->msg_file = argv[optind + 1];
    ctx->mac_file = argv[optind + 2];
}

static int prepare_tee_session(struct sample_ctx *ctx)
{
    TEEC_UUID uuid = PTA_RSIP_HMAC_UUID;
    uint32_t origin;
    TEEC_Result res;

    /* Initialize a context connecting us to the TEE */
    res = TEEC_InitializeContext(NULL, &ctx->ctx);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InitializeContext failed with code 0x%x\n", res);
        return -1;
    }

    /* Open a session with the TA */
    res = TEEC_OpenSession(&ctx->ctx, &ctx->sess, &uuid,
                   TEEC_LOGIN_PUBLIC, NULL, NULL, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_Opensession failed with code 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static void terminate_tee_session(struct sample_ctx *ctx)
{
    TEEC_CloseSession(&ctx->sess);
    TEEC_FinalizeContext(&ctx->ctx);
}

static int mac_init(struct sample_ctx *ctx, uint32_t *wuk, uint32_t wuk_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INPUT, TEEC_NONE, TEEC_NONE);

    op.params[0].tmpref.buffer = &ctx->hmac;
    op.params[0].tmpref.size = sizeof(ctx->hmac);
    op.params[1].tmpref.buffer = wuk;
    op.params[1].tmpref.size = wuk_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->init, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(INIT) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static int mac_update(struct sample_ctx *ctx, uint32_t *msg, uint32_t msg_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INPUT, TEEC_NONE, TEEC_NONE);

    op.params[0].tmpref.buffer = &ctx->hmac;
    op.params[0].tmpref.size = sizeof(ctx->hmac);
    op.params[1].tmpref.buffer = msg;
    op.params[1].tmpref.size = msg_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->update, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(UPDATE) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static int mac_final(struct sample_ctx *ctx, uint32_t *hmac, uint32_t *hmac_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    if (MAC_GEN_MODE == ctx->mode)
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INOUT, TEEC_NONE, TEEC_NONE);
    else
        op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INPUT, TEEC_NONE, TEEC_NONE);

    op.params[0].tmpref.buffer = &ctx->hmac;
    op.params[0].tmpref.size = sizeof(ctx->hmac);
    op.params[1].tmpref.buffer = hmac;
    op.params[1].tmpref.size = *hmac_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->final, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(FINAL) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *hmac_sz = op.params[1].tmpref.size;
    return 0;
}

static int msg_auth_code(struct sample_ctx *ctx, uint32_t *wuk, uint32_t wuk_sz, uint32_t *msg,
    uint32_t msg_sz, uint32_t *hmac, uint32_t *hmac_sz)
{
    int res;
    int err;

    res = mac_init(ctx, wuk, wuk_sz);
    if (res)
        return res;

    err = mac_update(ctx, msg, msg_sz);
    if (err)
        res = err;

    err = mac_final(ctx, hmac, hmac_sz);
    if (!res)
        res = err;

    return res;
}

int hmac_main(int argc, char *argv[])
{
    int res;
    struct sample_ctx ctx;

    uint32_t msg_size = sizeof(msg_buff);
    uint32_t mac_size = sizeof(mac_buff);
    uint32_t wuk_size = sizeof(wuk_buff);

    memset(msg_buff, 0, sizeof(msg_buff));
    memset(mac_buff, 0, sizeof(mac_buff));
    memset(wuk_buff, 0, sizeof(wuk_buff));
    
    printf("Parse command line options\n");
    get_args(argc, argv, &ctx);

    printf("Prepare session with the TA\n");
    res = prepare_tee_session(&ctx);
    if (res)
        goto err;

    printf("Load the wrapped hmac key from file \"%s\"\n", ctx.wuk_file);
    res = load_file(ctx.wuk_file, wuk_buff, &wuk_size);
    if (res)
        goto err;

    printf("Load the message from file \"%s\"\n", ctx.msg_file);
    res = load_file(ctx.msg_file, msg_buff, &msg_size);
    if (res)
        goto err;

    if (MAC_GEN_MODE == ctx.mode) {
        printf("MAC Generation with TA\n");
        res = msg_auth_code(&ctx, wuk_buff, wuk_size, msg_buff, msg_size, mac_buff, &mac_size);
        if (res)
            goto err;

        printf("Save the mac to file \"%s\"\n", ctx.mac_file);
        res = save_file(ctx.mac_file, mac_buff, mac_size);
        if (res)
            goto err;
    }
    else {
        printf("Load the mac from file \"%s\"\n", ctx.mac_file);
        res = load_file(ctx.mac_file, mac_buff, &mac_size);
        if (res)
            goto err;

        printf("MAC Verification with TA\n");
        res = msg_auth_code(&ctx, wuk_buff, wuk_size, msg_buff, msg_size, mac_buff, &mac_size);
        if (res)
            goto err;

        printf("\nMAC Verification Passed.\n\n");
    }

err:
    terminate_tee_session(&ctx);
    return 0;
}
