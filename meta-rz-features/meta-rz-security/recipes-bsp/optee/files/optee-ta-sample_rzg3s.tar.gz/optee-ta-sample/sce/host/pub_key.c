// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2024, Renesas Electronics
 */

#include <err.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the TA's h-file(s)) */
#include <pta_rsip.h>

#define KEY_BUFFER_SIZE             (1024)
#define PUBLIC_KEY_PARAMETER_SIZE   (512)

struct pub_key_info {
    char *pub_key_opt;
    uint32_t cmd;
};

/* TEE resources */
struct sample_ctx {
    TEEC_Context ctx;
    TEEC_Session sess;
    uint32_t cmd;
    char *wuk_file;
    char *out1_file;
    char *out2_file;
};

extern int load_file(char *file_name, uint32_t *buf, uint32_t *buf_sz);
extern int save_file(char *file_name, uint32_t *buf, uint32_t buf_sz);

static struct pub_key_info pub_key_list[] = {
    {"rsa1024",     PTA_CMD_RSA_1024_Public_Key_Export},
    {"rsa2048",     PTA_CMD_RSA_2048_Public_Key_Export},
    {"rsa3072",     PTA_CMD_RSA_3072_Public_Key_Export},
    {"rsa4096",     PTA_CMD_RSA_4096_Public_Key_Export},
    {"nistp192",    PTA_CMD_ECC_secp192r1_Public_Key_Export},
    {"nistp224",    PTA_CMD_ECC_secp224r1_Public_Key_Export},
    {"nistp256",    PTA_CMD_ECC_secp256r1_Public_Key_Export},
    {"bsip256r1",   PTA_CMD_ECC_BrainpoolP256r1_Public_Key_Export},
    {}
};

static uint32_t wuk_buff[KEY_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t out1_buff[PUBLIC_KEY_PARAMETER_SIZE / sizeof(uint32_t)];
static uint32_t out2_buff[PUBLIC_KEY_PARAMETER_SIZE / sizeof(uint32_t)];

static void usage(char *program)
{
    fprintf(stderr, "Public Key Export\n");
    fprintf(stderr, "Usage: %s -x [-t <ALGO>] <KEY> <OUTPUT1> <OUTPUT2> \n", program);
    fprintf(stderr, "\t-t <ALGO>        Public Key Export Algorithm. \n");
    fprintf(stderr, "\t                 Use default \"rsa_1024_pub_key\" if not set.\n");
    fprintf(stderr, "\t                 - \"rsa_1024_pub_key\", \"rsa_2048_pub_key\" \n");
    fprintf(stderr, "\t                 - \"rsa_3072_pub_key\", \"rsa_4096_pub_key\" \n");
    fprintf(stderr, "\t                 - \"ecc_nistp192_pub_key\", \"ecc_nistp224_pub_key\" \n");
    fprintf(stderr, "\t                 - \"ecc_nistp256_pub_key\", \"ecc_bsip256r1_pub_key\" \n");
    fprintf(stderr, "\t<KEY>            Specify the file name of the wrapped public key. \n");
    fprintf(stderr, "\t<OUTPUT1>        ECC : ECC public modulus Qx \n");
    fprintf(stderr, "\t                 RSA : RSA public modulus N \n");
    fprintf(stderr, "\t<OUTPUT2>        ECC : ECC public modulus Qy \n");
    fprintf(stderr, "\t                 RSA : RSA public modulus E \n");
    fprintf(stderr, "\n");
    exit(1);
}

static void get_args(int argc, char *argv[], struct sample_ctx *ctx)
{
    int opt;
    char *pub_key_opt = "rsa1024";
    struct pub_key_info *info = NULL;

    while (-1 != (opt = getopt(argc, argv, "t:h"))) {      
        switch (opt) {
        case 't':
            pub_key_opt = optarg;
            break;
        case 'h' :
            usage(argv[0]);
            break;
        default:
            usage(argv[0]);
            break;
        }
    }

    for (int i = 0; NULL != pub_key_list[i].pub_key_opt; i++) {
        if (!strcasecmp(pub_key_opt, pub_key_list[i].pub_key_opt)) {
            info = &pub_key_list[i];
            break;
        }
    }
    if (NULL == info) {
        fprintf(stderr, "Bad <ALGO> \"%s\" \n", pub_key_opt);
        usage(argv[0]);
    }
    
    if ((optind + 3) > argc) {
        fprintf(stderr, "Cannot find <KEY> , <OUTPUT1> or <OUTPUT2> \n");
        usage(argv[0]);
    }

    ctx->cmd       = info->cmd;
    ctx->wuk_file  = argv[optind];
    ctx->out1_file = argv[optind + 1];
    ctx->out2_file = argv[optind + 2];
}

static int prepare_tee_session(struct sample_ctx *ctx)
{
    TEEC_UUID uuid = PTA_RSIP_UUID;
    uint32_t origin;
    TEEC_Result res;

    /* Initialize a context connecting us to the TEE */
    res = TEEC_InitializeContext(NULL, &ctx->ctx);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InitializeContext failed with code 0x%x\n", res);
        return -1;
    }

    /* Open a session with the TA */
    res = TEEC_OpenSession(&ctx->ctx, &ctx->sess, &uuid,
                   TEEC_LOGIN_PUBLIC, NULL, NULL, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_Opensession failed with code 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static void terminate_tee_session(struct sample_ctx *ctx)
{
    TEEC_CloseSession(&ctx->sess);
    TEEC_FinalizeContext(&ctx->ctx);
}

static int pub_key_export(struct sample_ctx *ctx, uint32_t *wuk, uint32_t wuk_sz,
    uint32_t *out1, uint32_t *out1_sz, uint32_t *out2, uint32_t *out2_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_INOUT, 
        TEEC_MEMREF_TEMP_INOUT, TEEC_NONE);
    
    op.params[0].tmpref.buffer = wuk;
    op.params[0].tmpref.size = wuk_sz;
    op.params[1].tmpref.buffer = out1;
    op.params[1].tmpref.size = *out1_sz;
    op.params[2].tmpref.buffer = out2;
    op.params[2].tmpref.size = *out2_sz;

    res = TEEC_InvokeCommand(&ctx->sess, ctx->cmd, &op, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InvokeCommand(PUBLIC_KEY_EXPORT) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *out1_sz = op.params[1].tmpref.size;
    *out2_sz = op.params[2].tmpref.size;

    return 0;
}

int pub_key_main(int argc, char *argv[])
{
    int res;
    struct sample_ctx ctx;

    uint32_t wuk_size = sizeof(wuk_buff);
    uint32_t out1_size = sizeof(out1_buff);
    uint32_t out2_size = sizeof(out2_buff);

    memset(wuk_buff, 0, sizeof(wuk_buff));
    memset(out1_buff, 0, sizeof(out1_buff));
    memset(out2_buff, 0, sizeof(out2_buff));

    printf("Parse command line options\n");
    get_args(argc, argv, &ctx);

    printf("Prepare session with the TA\n");
    res = prepare_tee_session(&ctx);
    if (res)
        goto err;

    printf("Load the wrapped public key \"%s\"\n", ctx.wuk_file);
    res = load_file(ctx.wuk_file, wuk_buff, &wuk_size);
    if (res)
        goto err;

    printf("Public Key Export Parameters with the TA\n");
    res = pub_key_export(&ctx, wuk_buff, wuk_size, out1_buff, &out1_size, out2_buff, &out2_size);
    if(res)
        goto err;

    printf("Save the public key parameter to file \"%s\"\n", ctx.out1_file);
    res = save_file(ctx.out1_file, out1_buff, out1_size);
    if(res)
        goto err;

    printf("Save the public key parameter to file \"%s\"\n", ctx.out2_file);
    return save_file(ctx.out2_file, out2_buff, out2_size);
    if(res)
        goto err;

err:
    terminate_tee_session(&ctx);
    return 0;
}
