// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2024, Renesas Electronics
 */

#include <err.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the TA's h-file(s)) */
#include <pta_rsip.h>

#define KEY_BUFFER_SIZE     (2000)

#define KEY_GEN_PAIR        (1)
#define KEY_GEN_CMMN        (0)

struct key_info {
    char *key_opt;
    uint32_t cmd;
    uint32_t pair;
};

/* TEE resources */
struct sample_ctx {
    TEEC_Context ctx;
    TEEC_Session sess;
    uint32_t cmd;
    uint32_t pair;
    char *wuk1_file;
    char *wuk2_file;
};

extern int save_file(char *file_name, uint32_t *buf, uint32_t buf_sz);

static struct key_info key_list[] = {
    {"aes128",     PTA_CMD_AES128_WrappedKeyGenerate,                  KEY_GEN_CMMN},
    {"aes256",     PTA_CMD_AES256_WrappedKeyGenerate,                  KEY_GEN_CMMN},
    {"aes128xts",  PTA_CMD_AES128_XTS_WrappedKeyGenerate,              KEY_GEN_CMMN},
    {"aes256xts",  PTA_CMD_AES256_XTS_WrappedKeyGenerate,              KEY_GEN_CMMN},
    {"rsa1024",    PTA_CMD_RSA1024_WrappedKeyPairGenerate,             KEY_GEN_PAIR},
    {"rsa2048",    PTA_CMD_RSA2048_WrappedKeyPairGenerate,             KEY_GEN_PAIR},
    {"rsa3072",    PTA_CMD_RSA3072_WrappedKeyPairGenerate,             KEY_GEN_PAIR},
    {"rsa4096",    PTA_CMD_RSA4096_WrappedKeyPairGenerate,             KEY_GEN_PAIR},
    {"nistp192",   PTA_CMD_ECC_secp192r1_WrappedKeyPairGenerate,       KEY_GEN_PAIR},
    {"nistp224",   PTA_CMD_ECC_secp224r1_WrappedKeyPairGenerate,       KEY_GEN_PAIR},
    {"nistp256",   PTA_CMD_ECC_secp256r1_WrappedKeyPairGenerate,       KEY_GEN_PAIR},
    {"bsip256r1",  PTA_CMD_ECC_BrainpoolP256r1_WrappedKeyPairGenerate, KEY_GEN_PAIR},
    {}
};

static uint32_t wuk1_buff[KEY_BUFFER_SIZE / sizeof(uint32_t)];
static uint32_t wuk2_buff[KEY_BUFFER_SIZE / sizeof(uint32_t)];

static void usage(char *program)
{
    fprintf(stderr, "Common Key Generation\n");
    fprintf(stderr, "Usage: %s -k [-t <Type>] <Key1> \n", program);
    fprintf(stderr, "\t-t <Type>        Generation Key Type. \n");
    fprintf(stderr, "\t                 Use default \"aes128\" if not set.\n");
    fprintf(stderr, "\t                 - \"aes128\", \"aes256\" \n");
    fprintf(stderr, "\t                 - \"aes128xts\", \"aes256xts\" \n");
    fprintf(stderr, "\t<Key1>           File name of the wrapped common key to be output.\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "Pair Key Generation\n");
    fprintf(stderr, "Usage: %s -k [-t <Type>] <Key1> <Key2> \n", program);
    fprintf(stderr, "\t-t <Type>        Generation Key Type. \n");
    fprintf(stderr, "\t                 - \"rsa1024\",  \"rsa2048\" \n");
    fprintf(stderr, "\t                 - \"rsa3072\",  \"rsa4096\" \n");
    fprintf(stderr, "\t                 - \"nistp192\", \"nistp224\", \"nistp256\" \n");
    fprintf(stderr, "\t                 - \"bsip256r1\" \n");
    fprintf(stderr, "\t<Key1>           File name of the wrapped private key to be output.\n");
    fprintf(stderr, "\t<Key2>           File name of the wrapped public key to be output.\n");
    fprintf(stderr, "\n");
    exit(1);
}

static void get_args(int argc, char *argv[], struct sample_ctx *ctx)
{
    int opt;
    char *key_opt = "aes128";
    struct key_info *info = NULL;

    while (-1 != (opt = getopt(argc, argv, "t:h"))) {      
        switch (opt) {
        case 't':
            key_opt = optarg;
            break;
        case 'h':
            usage(argv[0]);
            break;
        default:
            usage(argv[0]);
            break;
        }
    }

    for (int i = 0; NULL != key_list[i].key_opt; i++) {
        if (!strcasecmp(key_opt, key_list[i].key_opt)) {
            info = &key_list[i];
            break;
        }
    }
    if (NULL == info) {
        fprintf(stderr, "Bad <Type> \"%s\" \n", key_opt);
        usage(argv[0]);
    }

    if ((optind + 1) > argc) {
        fprintf(stderr, "Cannot find the <Key1>. \n");
        usage(argv[0]);
    }
    if ((info->pair) && ((optind + 2) > argc)) {
        fprintf(stderr, "Cannot find the <Key2>. \n");
        usage(argv[0]);
    }

    ctx->cmd       = info->cmd;
    ctx->pair      = info->pair;
    ctx->wuk1_file  = argv[optind];
    ctx->wuk2_file = ctx->pair ? argv[optind + 1] : NULL;
}

static int prepare_tee_session(struct sample_ctx *ctx)
{
    TEEC_UUID uuid = PTA_RSIP_UUID;
    uint32_t origin;
    TEEC_Result res;

    /* Initialize a context connecting us to the TEE */
    res = TEEC_InitializeContext(NULL, &ctx->ctx);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_InitializeContext failed with code 0x%x", res);
        return -1;
    }

    /* Open a session with the TA */
    res = TEEC_OpenSession(&ctx->ctx, &ctx->sess, &uuid,
                   TEEC_LOGIN_PUBLIC, NULL, NULL, &origin);
    if (res != TEEC_SUCCESS) {
        fprintf(stderr, "TEEC_Opensession failed with code 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    return 0;
}

static void terminate_tee_session(struct sample_ctx *ctx)
{
    TEEC_CloseSession(&ctx->sess);
    TEEC_FinalizeContext(&ctx->ctx);
}

static int generate_key(struct sample_ctx *ctx, uint32_t *wuk1, uint32_t *wuk1_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_NONE, TEEC_NONE, TEEC_NONE);
 
    op.params[0].tmpref.buffer = wuk1;
    op.params[0].tmpref.size = *wuk1_sz;
 
    res = TEEC_InvokeCommand(&ctx->sess, ctx->cmd, &op, &origin);
    if (res != TEEC_SUCCESS){
        fprintf(stderr, "TEEC_InvokeCommand(GENERATE) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *wuk1_sz = op.params[0].tmpref.size;
    return 0;
}

static int generate_pair_key(struct sample_ctx *ctx, uint32_t *wuk1, uint32_t *wuk1_sz, uint32_t *wuk2, uint32_t *wuk2_sz)
{
    TEEC_Operation op;
    uint32_t origin;
    TEEC_Result res;

    memset(&op, 0, sizeof(op));
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INOUT, TEEC_NONE, TEEC_NONE);
 
    op.params[0].tmpref.buffer = wuk1;
    op.params[0].tmpref.size = *wuk1_sz;
    op.params[1].tmpref.buffer = wuk2;
    op.params[1].tmpref.size = *wuk2_sz;
    
    res = TEEC_InvokeCommand(&ctx->sess, ctx->cmd, &op, &origin);
    if (res != TEEC_SUCCESS){
        fprintf(stderr, "TEEC_InvokeCommand(GENERATE) failed 0x%x origin 0x%x\n", res, origin);
        return -1;
    }
    *wuk1_sz = op.params[0].tmpref.size;
    *wuk2_sz = op.params[1].tmpref.size;
    return 0;
}

int gen_key_main(int argc, char *argv[])
{
    int res;
    struct sample_ctx ctx;
    
    uint32_t wuk1_size = sizeof(wuk1_buff);
    uint32_t wuk2_size = sizeof(wuk2_buff);

    printf("Parse command line options\n");
    get_args(argc, argv, &ctx);

    printf("Prepare session with the TA\n");
    res = prepare_tee_session(&ctx);
    if (res)
        goto err;

    if (ctx.pair == KEY_GEN_CMMN)
    {
        printf("Generate the wrapped key with the TA\n");
        res = generate_key(&ctx, wuk1_buff, &wuk1_size);
        if (res)
            goto err;

        printf("Save the generated key to file \"%s\"\n", ctx.wuk1_file);
        res = save_file(ctx.wuk1_file, wuk1_buff, wuk1_size);
        if (res)
            goto err;
    }
    else
    {
        printf("Generate the wrapped key with the TA\n");
        res = generate_pair_key(&ctx, wuk1_buff, &wuk1_size, wuk2_buff, &wuk2_size);
        if (res)
            goto err;

        printf("Save the generated private key to file \"%s\"\n", ctx.wuk1_file);
        res = save_file(ctx.wuk1_file, wuk1_buff, wuk1_size);
        if (res)
            goto err;
        
        printf("Save the generated public key to file \"%s\"\n", ctx.wuk2_file);
        res = save_file(ctx.wuk2_file, wuk2_buff, wuk2_size);
        if (res)
            goto err;
    }

err:
    terminate_tee_session(&ctx);
    return 0;
}
